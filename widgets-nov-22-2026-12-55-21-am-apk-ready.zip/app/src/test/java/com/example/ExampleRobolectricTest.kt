package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.widget.CrayonFontOption
import com.example.widget.CrayonGlassBalance
import com.example.widget.CrayonIconKind
import com.example.widget.CrayonIconPackRenderer
import com.example.widget.CrayonIconShape
import com.example.widget.CrayonWidgetRenderer
import com.example.widget.GlassThemeOption
import com.example.widget.InstalledAppsHelper
import com.example.widget.InstalledLaunchApp
import com.example.widget.PedometerHelper
import com.example.widget.PedometerSnapshot
import com.example.widget.ToggleTileType
import com.example.widget.WidgetPreferences
import com.example.widget.WidgetSettings
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `app name matches Widgets`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Widgets", appName)
  }

  @Test
  fun `widget preferences toggle page and sync style across all widgets`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val widgetId = 101
    assertEquals(0, WidgetPreferences.getSettingsForWidget(context, widgetId).page)
    assertEquals(1, WidgetPreferences.togglePage(context, widgetId))
    assertEquals(0, WidgetPreferences.togglePage(context, widgetId))

    WidgetPreferences.applyGlobalStyleToAllWidgets(
      context = context,
      appWidgetIds = intArrayOf(101, 202, 303, 404),
      font = CrayonFontOption.SCHOOLBELL,
      theme = GlassThemeOption.MATCHA_PERSIMMON,
      balance = CrayonGlassBalance.CRAYON_90_GLASS_10,
    )
    for (id in listOf(101, 202, 303, 404)) {
      val loaded = WidgetPreferences.getSettingsForWidget(context, id)
      assertEquals(CrayonGlassBalance.CRAYON_90_GLASS_10, loaded.balance)
      assertEquals(CrayonFontOption.SCHOOLBELL, loaded.font)
      assertEquals(GlassThemeOption.MATCHA_PERSIMMON, loaded.theme)
    }
  }

  @Test
  fun `pedometer helper accumulates steps and survives simulated reboot`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val first = PedometerHelper.recordHardwareStepCount(context, 1000L)
    assertEquals(0, first.stepsToday)

    val second = PedometerHelper.recordHardwareStepCount(context, 1450L)
    assertEquals(450, second.stepsToday)

    // After a reboot, sensor reading drops below 1450
    val afterReboot = PedometerHelper.recordHardwareStepCount(context, 120L)
    assertEquals(570, afterReboot.stepsToday)
  }

  @Test
  fun `renderer produces valid bitmaps for calendar, 2x1 pill pedometer, and 1x1 toggle tiles across balances`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val snapshotPermitted = PedometerSnapshot(
      stepsToday = 4280,
      dailyGoal = 8000,
      hasPermission = true,
      isSensorAvailable = true,
    )
    val snapshotUnpermitted = PedometerSnapshot(
      stepsToday = 0,
      dailyGoal = 8000,
      hasPermission = false,
      isSensorAvailable = true,
    )

    for (font in CrayonFontOption.entries) {
      val specimen = CrayonWidgetRenderer.renderFontSpecimen(
        context = context,
        fontOption = font,
        inkArgb = GlassThemeOption.WARM_VERMILION.inkPrimaryArgb,
        accentArgb = GlassThemeOption.WARM_VERMILION.accentArgb,
      )
      assertEquals(144, specimen.width)
      assertTrue(!specimen.isRecycled)

      for (theme in GlassThemeOption.entries) {
        for (balance in CrayonGlassBalance.entries) {
          val settings = WidgetSettings(font = font, theme = theme, balance = balance, page = 0)
          for (page in listOf(0, 1)) {
            val calendarBmp = CrayonWidgetRenderer.render(
              context = context,
              settings = settings.copy(page = page),
              widthPx = 480,
              heightPx = 480,
            )
            assertEquals(480, calendarBmp.width)
            assertEquals(480, calendarBmp.height)
            assertTrue(!calendarBmp.isRecycled)
          }

          for (snap in listOf(snapshotPermitted, snapshotUnpermitted)) {
            val pillBmp = CrayonWidgetRenderer.renderPedometerPill(
              context = context,
              snapshot = snap,
              settings = settings,
              widthPx = 640,
              heightPx = 290,
            )
            assertEquals(640, pillBmp.width)
            assertEquals(290, pillBmp.height)
            assertTrue(!pillBmp.isRecycled)
          }

          for (type in ToggleTileType.entries) {
            for (enabled in listOf(true, false)) {
              val toggleBmp = CrayonWidgetRenderer.renderToggleTile(
                context = context,
                type = type,
                isEnabled = enabled,
                settings = settings,
                widthPx = 360,
                heightPx = 360,
              )
              assertEquals(360, toggleBmp.width)
              assertEquals(360, toggleBmp.height)
              assertTrue(!toggleBmp.isRecycled)
            }
          }
        }
      }
    }
  }

  @Test
  fun `icon pack renders all bespoke icons and auto-themes any installed app across shapes`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    assertEquals(CrayonIconShape.SQUIRCLE, WidgetPreferences.getDefaultIconShape(context))
    WidgetPreferences.saveDefaultIconShape(context, CrayonIconShape.CIRCLE)
    assertEquals(CrayonIconShape.CIRCLE, WidgetPreferences.getDefaultIconShape(context))

    val settings = WidgetSettings(
      theme = GlassThemeOption.OBSIDIAN_AMBER,
      balance = CrayonGlassBalance.CRAYON_90_GLASS_10,
    )

    for (kind in CrayonIconKind.entries) {
      for (shape in CrayonIconShape.entries) {
        val iconBmp = CrayonIconPackRenderer.renderIcon(
          kind = kind,
          shape = shape,
          settings = settings,
          sizePx = 192,
        )
        assertEquals(192, iconBmp.width)
        assertEquals(192, iconBmp.height)
        assertTrue(!iconBmp.isRecycled)
      }
    }

    val requestedApps = listOf(
      InstalledLaunchApp("LinkedIn", "com.linkedin.android", "LaunchActivity") to CrayonIconKind.LINKEDIN,
      InstalledLaunchApp("Gemini", "com.google.android.apps.bard", "BardEntryPointActivity") to CrayonIconKind.GEMINI,
      InstalledLaunchApp("YT Studio", "com.google.android.apps.youtube.creator", "MainActivity") to CrayonIconKind.YT_STUDIO,
      InstalledLaunchApp("Teams", "com.microsoft.teams", "Launcher") to CrayonIconKind.TEAMS,
      InstalledLaunchApp("Outlook", "com.microsoft.office.outlook", "MainActivity") to CrayonIconKind.OUTLOOK,
      InstalledLaunchApp("Excel", "com.microsoft.office.excel", "LaunchActivity") to CrayonIconKind.EXCEL,
      InstalledLaunchApp("Zoom", "us.zoom.videomeetings", "LauncherActivity") to CrayonIconKind.ZOOM,
      InstalledLaunchApp("YouTube", "com.google.android.youtube", "HomeActivity") to CrayonIconKind.YOUTUBE,
      InstalledLaunchApp("Google", "com.google.android.googlequicksearchbox", "SearchActivity") to CrayonIconKind.GOOGLE,
      InstalledLaunchApp("Claude", "com.anthropic.claude", "MainActivity") to CrayonIconKind.CLAUDE,
      InstalledLaunchApp("ChatGPT", "com.openai.chatgpt", "MainActivity") to CrayonIconKind.CHATGPT,
      InstalledLaunchApp("iMobile Pay", "com.csam.icici.bank.imobile", "IMobile") to CrayonIconKind.IMOBILE,
      InstalledLaunchApp("SBI Card", "com.sbicard.android", "MainActivity") to CrayonIconKind.SBI_CARD,
      InstalledLaunchApp("Rapido", "com.rapido.passenger", "DefaultAlias") to CrayonIconKind.RAPIDO,
      InstalledLaunchApp("RailOne", "org.cris.railone", "MainActivity") to CrayonIconKind.RAILONE,
      InstalledLaunchApp("TenMin", "com.zeptoconsumerapp", "MainActivity") to CrayonIconKind.TENMIN,
      InstalledLaunchApp("Unacademy", "com.unacademyapp", "MainActivity") to CrayonIconKind.UNACADEMY,
      InstalledLaunchApp("DeepSeek", "com.deepseek.chat", "MainActivity") to CrayonIconKind.DEEPSEEK,
      InstalledLaunchApp("Minecraft", "com.mojang.minecraftpe", "MainActivity") to CrayonIconKind.MINECRAFT,
      InstalledLaunchApp("BHIM", "in.org.npci.upiapp", "HomeActivity") to CrayonIconKind.BHIM,
      InstalledLaunchApp("Blinkit", "com.grofers.customerapp", "SplashActivity") to CrayonIconKind.BLINKIT,
      InstalledLaunchApp("Axis Mobile", "com.axis.mobile", "MainActivity") to CrayonIconKind.AXIS_MOBILE,
      InstalledLaunchApp("Domino's", "com.Dominos", "SplashActivity") to CrayonIconKind.DOMINOS,
      InstalledLaunchApp("MentiHub", "com.xandylearning.mentihub", "MainActivity") to CrayonIconKind.MENTIHUB,
      InstalledLaunchApp("GPay", "com.google.android.apps.nbu.paisa.user", "LauncherActivity") to CrayonIconKind.GPAY,
      InstalledLaunchApp("Instamart", "in.swiggy.android.instamart", "SplashActivity") to CrayonIconKind.INSTAMART,
      InstalledLaunchApp("Swiggy", "in.swiggy.android", "HomeActivity") to CrayonIconKind.SWIGGY,
      InstalledLaunchApp("Telegram", "org.telegram.messenger", "DefaultIcon") to CrayonIconKind.TELEGRAM,
      InstalledLaunchApp("greytHR", "com.greytip.ghress", "SplashActivity") to CrayonIconKind.GREYTHR,
    )

    for ((app, expectedKind) in requestedApps) {
      assertEquals(expectedKind, InstalledAppsHelper.matchBespokeIcon(app))
      val rendered = CrayonIconPackRenderer.renderInstalledAppIcon(
        context = context,
        app = app,
        shape = CrayonIconShape.SQUIRCLE,
        settings = settings,
        sizePx = 192,
      )
      assertEquals(192, rendered.width)
      assertTrue(!rendered.isRecycled)
    }

    // Any completely custom / unmapped app also renders cleanly via stencil/monogram fallback
    val arbitraryApp = InstalledLaunchApp("Custom Utility App", "com.example.customutil", "MainActivity")
    val fallbackBmp = CrayonIconPackRenderer.renderInstalledAppIcon(
      context = context,
      app = arbitraryApp,
      shape = CrayonIconShape.CIRCLE,
      settings = settings,
      sizePx = 192,
    )
    assertEquals(192, fallbackBmp.width)
    assertEquals(192, fallbackBmp.height)
    assertTrue(!fallbackBmp.isRecycled)
  }

  @Test
  @org.robolectric.annotation.GraphicsMode(org.robolectric.annotation.GraphicsMode.Mode.NATIVE)
  fun `stencil renderer strips bright default badge blue and keeps theme palette`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val testPkg = "com.example.coloredbadge"

    // Register package and a bright #0A66C2 LinkedIn-blue badge + white 'in' drawable in ShadowPackageManager
    val badgeBmp = android.graphics.Bitmap.createBitmap(128, 128, android.graphics.Bitmap.Config.ARGB_8888)
    val badgeCanvas = android.graphics.Canvas(badgeBmp)
    val bluePaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
      color = android.graphics.Color.rgb(10, 102, 194)
      style = android.graphics.Paint.Style.FILL
    }
    badgeCanvas.drawRoundRect(
      android.graphics.RectF(12f, 12f, 116f, 116f),
      26f,
      26f,
      bluePaint,
    )
    val whitePaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
      color = android.graphics.Color.WHITE
      textSize = 64f
      textAlign = android.graphics.Paint.Align.CENTER
      typeface = android.graphics.Typeface.DEFAULT_BOLD
    }
    badgeCanvas.drawText("in", 64f, 84f, whitePaint)

    val shadowPm = org.robolectric.Shadows.shadowOf(context.packageManager)
    val pkgInfo = android.content.pm.PackageInfo().apply {
      packageName = testPkg
      applicationInfo = android.content.pm.ApplicationInfo().apply {
        packageName = testPkg
      }
    }
    shadowPm.installPackage(pkgInfo)
    val syntheticIcon = android.graphics.drawable.BitmapDrawable(context.resources, badgeBmp)
    shadowPm.setApplicationIcon(testPkg, syntheticIcon)
    assertTrue(context.packageManager.getApplicationIcon(testPkg) === syntheticIcon)

    val warmSettings = WidgetSettings(
      theme = GlassThemeOption.WARM_VERMILION,
      balance = CrayonGlassBalance.CRAYON_90_GLASS_10,
    )
    val rendered = CrayonIconPackRenderer.renderInstalledAppIcon(
      context = context,
      app = InstalledLaunchApp("Colored Badge", testPkg, "MainActivity"),
      shape = CrayonIconShape.SQUIRCLE,
      settings = warmSettings,
      sizePx = 192,
    )

    val outPixels = IntArray(rendered.width * rendered.height)
    rendered.getPixels(outPixels, 0, rendered.width, 0, 0, rendered.width, rendered.height)

    // Assert zero raw LinkedIn-blue pixels (B strongly > R and > G) leak into the rendered icon
    var leakedBlueCount = 0
    var darkInkCount = 0
    var accentInkCount = 0
    for (p in outPixels) {
      val a = (p ushr 24) and 0xFF
      if (a > 120) {
        val r = (p ushr 16) and 0xFF
        val g = (p ushr 8) and 0xFF
        val b = p and 0xFF
        if (b - r > 45 && b > 130) leakedBlueCount++
        if (r < 110 && g < 110 && b < 110) darkInkCount++
        if (r > 180 && g < 120 && b < 90) accentInkCount++
      }
    }
    assertEquals("Raw blue badge pixels leaked into crayon stencil", 0, leakedBlueCount)
    assertTrue(
      "Expected extracted dark crayon ink glyph pixels, got darkInkCount=$darkInkCount, accentInkCount=$accentInkCount",
      darkInkCount > 150,
    )
  }

  @Test
  fun `appfilter xml references valid drawables and updated package ids`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val parser = context.resources.getXml(R.xml.appfilter)
    val components = mutableListOf<String>()
    val drawables = mutableSetOf<String>()

    var event = parser.eventType
    while (event != org.xmlpull.v1.XmlPullParser.END_DOCUMENT) {
      if (event == org.xmlpull.v1.XmlPullParser.START_TAG) {
        when (parser.name) {
          "item" -> {
            parser.getAttributeValue(null, "component")?.let { components += it }
            parser.getAttributeValue(null, "drawable")?.let { drawables += it }
          }
          "iconback", "iconmask", "iconupon" -> {
            parser.getAttributeValue(null, "img1")?.let { drawables += it }
          }
        }
      }
      event = parser.next()
    }

    assertTrue(components.any { it.contains("LaunchActivityDefault") })
    assertTrue(components.any { it.contains("org.cris.aikyam") })
    assertTrue(components.any { it.contains("ai.tenmin.app") })
    assertTrue(components.any { it.contains("IMOBILE") })
    assertTrue(components.any { it.contains("com.anthropic.apps.MainActivity") })
    assertTrue(components.any { it.contains("com.rapido.passenger.activities.SplashScreen") })
    assertTrue(components.any { it.contains("com.xandylearning.mentihub") })
    assertTrue(components.any { it.contains("com.google.android.apps.nbu.paisa.user.launcher.LauncherActivity") })
    assertTrue(components.any { it.contains("in.swiggy.android.instamart") })
    assertTrue(components.any { it.contains("in.swiggy.android.activities.DeepLinkActivity") })
    assertTrue(components.any { it.contains("in.swiggy.android.activities.HomeActivity") })
    assertTrue(components.any { it.contains("com.dominoss.activities.SplashActivity") })
    assertTrue(components.any { it.contains("org.telegram.messenger.DefaultIcon") })
    assertTrue(components.any { it.contains("com.greytip.ghress") })
    assertTrue(components.any { it.contains("com.whereismytrain.android") })
    assertTrue(components.any { it.contains("com.cris.utsmobile") })
    assertTrue(components.any { it.contains("com.aistudio.crayoncalendar.xkpzqm/com.example.MainActivity") })
    assertTrue(components.any { it.contains("com.nothing.compass") })
    assertTrue(drawables.contains("ic_pack_compass"))

    val parsedSet = InstalledAppsHelper.loadAppfilterComponents(context)
    assertTrue(parsedSet.contains("com.aistudio.crayoncalendar.xkpzqm/com.example.MainActivity"))
    assertTrue(parsedSet.contains("com.Dominos/com.dominoss.activities.SplashActivity"))
    assertTrue(parsedSet.contains("in.swiggy.android.instamart/in.swiggy.android.activities.DeepLinkActivity"))

    assertEquals(
      CrayonIconKind.COMPASS,
      InstalledAppsHelper.matchBespokeIcon(InstalledLaunchApp("Compass", "com.nothing.compass", "MainActivity")),
    )

    for (name in drawables) {
      val resId = context.resources.getIdentifier(name, "drawable", context.packageName)
      assertTrue("Missing drawable $name referenced by appfilter.xml", resId != 0)
    }
  }

  @Test
  @org.robolectric.annotation.GraphicsMode(org.robolectric.annotation.GraphicsMode.Mode.NATIVE)
  fun `pinned icon records persist and rebuild updated shortcut bitmaps when shape and theme change`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val record = com.example.widget.PinnedIconRecord(
      shortcutId = "crayon_icon_com.linkedin.android_linkedin",
      packageName = "com.linkedin.android",
      activityName = "com.linkedin.android.authenticator.LaunchActivityDefault",
      label = "LinkedIn",
      iconId = "linkedin",
    )
    WidgetPreferences.savePinnedIcon(context, record)

    val tracked = InstalledAppsHelper.getTrackedPinnedIcons(context)
    assertEquals(1, tracked.size)
    assertEquals("LinkedIn", tracked.first().label)

    val lightShortcuts = InstalledAppsHelper.buildUpdatedShortcutList(
      context = context,
      records = tracked,
      shape = CrayonIconShape.SQUIRCLE,
      settings = WidgetSettings(
        theme = GlassThemeOption.WARM_VERMILION,
        balance = CrayonGlassBalance.CRAYON_90_GLASS_10,
      ),
    )
    val darkCircleShortcuts = InstalledAppsHelper.buildUpdatedShortcutList(
      context = context,
      records = tracked,
      shape = CrayonIconShape.CIRCLE,
      settings = WidgetSettings(
        theme = GlassThemeOption.OBSIDIAN_AMBER,
        balance = CrayonGlassBalance.CRAYON_80_GLASS_20,
      ),
    )

    assertEquals(1, lightShortcuts.size)
    assertEquals(1, darkCircleShortcuts.size)
    assertEquals(record.shortcutId, darkCircleShortcuts.first().id)

    val lightBmp = lightShortcuts.first().icon!!.bitmap!!
    val darkBmp = darkCircleShortcuts.first().icon!!.bitmap!!
    assertEquals(256, lightBmp.width)
    assertEquals(256, darkBmp.width)
    // Corner inside squircle vs outside circle differs visually when shape & theme change
    assertTrue(lightBmp.getPixel(36, 36) != darkBmp.getPixel(36, 36))
    assertTrue(lightBmp.getPixel(128, 128) != darkBmp.getPixel(128, 128))
  }

  @Test
  fun `pedometer helper tracks baseline, step detector fallback, and job service lifecycle`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    assertTrue(!PedometerHelper.hasBaselineForToday(context))

    val initial = PedometerHelper.recordHardwareStepCount(context, 4000L)
    assertEquals(0, initial.stepsToday)
    assertTrue(PedometerHelper.hasBaselineForToday(context))

    val walked = PedometerHelper.recordHardwareStepCount(context, 4250L)
    assertEquals(250, walked.stepsToday)

    val fallbackTicked = PedometerHelper.recordStepDetectorSteps(context, 15)
    assertEquals(265, fallbackTicked.stepsToday)

    // Verify PedometerSyncJobService can be cleanly invoked & cancelled without throwing
    PedometerSyncJobService.scheduleIfNeeded(context)
    PedometerSyncJobService.cancel(context)
  }

  @Test
  @org.robolectric.annotation.GraphicsMode(org.robolectric.annotation.GraphicsMode.Mode.NATIVE)
  fun `70-30 balance renders distinctly from 80-20 and 90-10 across widgets`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    assertTrue(CrayonGlassBalance.entries.contains(CrayonGlassBalance.CRAYON_70_GLASS_30))
    assertEquals("70 / 30", CrayonGlassBalance.CRAYON_70_GLASS_30.shortLabel)

    val cal90 = CrayonWidgetRenderer.render(
      context = context,
      settings = WidgetSettings(
        theme = GlassThemeOption.OBSIDIAN_AMBER,
        balance = CrayonGlassBalance.CRAYON_90_GLASS_10,
      ),
      widthPx = 320,
      heightPx = 320,
    )
    val cal80 = CrayonWidgetRenderer.render(
      context = context,
      settings = WidgetSettings(
        theme = GlassThemeOption.OBSIDIAN_AMBER,
        balance = CrayonGlassBalance.CRAYON_80_GLASS_20,
      ),
      widthPx = 320,
      heightPx = 320,
    )
    val cal70 = CrayonWidgetRenderer.render(
      context = context,
      settings = WidgetSettings(
        theme = GlassThemeOption.OBSIDIAN_AMBER,
        balance = CrayonGlassBalance.CRAYON_70_GLASS_30,
      ),
      widthPx = 320,
      heightPx = 320,
    )

    val p90 = IntArray(cal90.width * cal90.height)
    val p80 = IntArray(cal80.width * cal80.height)
    val p70 = IntArray(cal70.width * cal70.height)
    cal90.getPixels(p90, 0, cal90.width, 0, 0, cal90.width, cal90.height)
    cal80.getPixels(p80, 0, cal80.width, 0, 0, cal80.width, cal80.height)
    cal70.getPixels(p70, 0, cal70.width, 0, 0, cal70.width, cal70.height)

    assertTrue(!p70.contentEquals(p80))
    assertTrue(!p70.contentEquals(p90))

    val pill70 = CrayonWidgetRenderer.renderPedometerPill(
      context = context,
      snapshot = PedometerSnapshot(stepsToday = 1234, dailyGoal = 8000, hasPermission = true, isSensorAvailable = true),
      settings = WidgetSettings(theme = GlassThemeOption.OBSIDIAN_AMBER, balance = CrayonGlassBalance.CRAYON_70_GLASS_30),
      widthPx = 480,
      heightPx = 220,
    )
    val tile70 = CrayonWidgetRenderer.renderToggleTile(
      context = context,
      type = ToggleTileType.WIFI,
      isEnabled = true,
      settings = WidgetSettings(theme = GlassThemeOption.OBSIDIAN_AMBER, balance = CrayonGlassBalance.CRAYON_70_GLASS_30),
      widthPx = 240,
      heightPx = 240,
    )
    assertTrue(!pill70.isRecycled && !tile70.isRecycled)
  }

  @Test
  @org.robolectric.annotation.GraphicsMode(org.robolectric.annotation.GraphicsMode.Mode.NATIVE)
  fun `launcher pack drawables resolve distinct light and dark obsidian palettes cleanly`() {
    val baseContext = ApplicationProvider.getApplicationContext<Context>()

    val lightConfig = android.content.res.Configuration(baseContext.resources.configuration).apply {
      uiMode = (uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK.inv()) or
        android.content.res.Configuration.UI_MODE_NIGHT_NO
    }
    val nightConfig = android.content.res.Configuration(baseContext.resources.configuration).apply {
      uiMode = (uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK.inv()) or
        android.content.res.Configuration.UI_MODE_NIGHT_YES
    }
    val lightCtx = baseContext.createConfigurationContext(lightConfig)
    val nightCtx = baseContext.createConfigurationContext(nightConfig)

    assertEquals(0xFFFAF6EE.toInt(), lightCtx.getColor(R.color.crayon_pack_bg))
    assertEquals(0xFFE04626.toInt(), lightCtx.getColor(R.color.crayon_pack_accent))
    assertEquals(0xFF1C1D21.toInt(), nightCtx.getColor(R.color.crayon_pack_bg))
    assertEquals(0xFFF29D16.toInt(), nightCtx.getColor(R.color.crayon_pack_accent))

    val parser = baseContext.resources.getXml(R.xml.appfilter)
    val drawableNames = mutableSetOf("ic_pack_back", "ic_pack_upon", "ic_pack_mask")
    for (kind in CrayonIconKind.entries) {
      drawableNames += "ic_pack_${kind.id}"
    }
    var event = parser.eventType
    while (event != org.xmlpull.v1.XmlPullParser.END_DOCUMENT) {
      if (event == org.xmlpull.v1.XmlPullParser.START_TAG) {
        parser.getAttributeValue(null, "drawable")?.let { drawableNames += it }
        parser.getAttributeValue(null, "img1")?.let { drawableNames += it }
      }
      event = parser.next()
    }

    for (name in drawableNames) {
      val resId = baseContext.resources.getIdentifier(name, "drawable", baseContext.packageName)
      assertTrue("Missing drawable $name", resId != 0)
      val lightDrawable = androidx.core.content.ContextCompat.getDrawable(lightCtx, resId)
      val nightDrawable = androidx.core.content.ContextCompat.getDrawable(nightCtx, resId)
      assertTrue("Failed to inflate light drawable $name", lightDrawable != null)
      assertTrue("Failed to inflate night drawable $name", nightDrawable != null)
    }

    // Verify rendered textured PNG output for LinkedIn switches from bright ivory paper to dark obsidian
    val linkedInId = R.drawable.ic_pack_linkedin
    fun renderTopMarginPixel(ctx: Context): Int {
      val d = androidx.core.content.ContextCompat.getDrawable(ctx, linkedInId)!!
      val bmp = android.graphics.Bitmap.createBitmap(128, 128, android.graphics.Bitmap.Config.ARGB_8888)
      val canvas = android.graphics.Canvas(bmp)
      d.setBounds(0, 0, 128, 128)
      d.draw(canvas)
      return bmp.getPixel(64, 24)
    }
    val lightBgPixel = renderTopMarginPixel(lightCtx)
    val nightBgPixel = renderTopMarginPixel(nightCtx)
    val lightLuma = androidx.core.graphics.ColorUtils.calculateLuminance(lightBgPixel)
    val nightLuma = androidx.core.graphics.ColorUtils.calculateLuminance(nightBgPixel)
    assertTrue("Expected bright light card pixel luminance > 0.70, got $lightLuma", lightLuma > 0.70)
    assertTrue("Expected dark night card pixel luminance < 0.25, got $nightLuma", nightLuma < 0.25)
  }

}
