package com.example

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.RemoteViews
import com.example.widget.CrayonWidgetRenderer
import com.example.widget.WidgetPreferences
import kotlin.math.roundToInt

class CrayonCalendarWidgetProvider : AppWidgetProvider() {

  override fun onUpdate(
    context: Context,
    appWidgetManager: AppWidgetManager,
    appWidgetIds: IntArray,
  ) {
    for (appWidgetId in appWidgetIds) {
      updateWidget(context, appWidgetManager, appWidgetId)
    }
  }

  override fun onAppWidgetOptionsChanged(
    context: Context,
    appWidgetManager: AppWidgetManager,
    appWidgetId: Int,
    newOptions: Bundle,
  ) {
    super.onAppWidgetOptionsChanged(context, appWidgetManager, appWidgetId, newOptions)
    updateWidget(context, appWidgetManager, appWidgetId)
  }

  override fun onDeleted(context: Context, appWidgetIds: IntArray) {
    super.onDeleted(context, appWidgetIds)
    for (appWidgetId in appWidgetIds) {
      WidgetPreferences.deleteWidget(context, appWidgetId)
    }
  }

  override fun onReceive(context: Context, intent: Intent) {
    super.onReceive(context, intent)
    when (intent.action) {
      ACTION_TOGGLE_PAGE -> {
        val appWidgetId = intent.getIntExtra(
          AppWidgetManager.EXTRA_APPWIDGET_ID,
          AppWidgetManager.INVALID_APPWIDGET_ID,
        )
        val appWidgetManager = AppWidgetManager.getInstance(context)
        if (appWidgetId != AppWidgetManager.INVALID_APPWIDGET_ID) {
          WidgetPreferences.togglePage(context, appWidgetId)
          updateWidget(context, appWidgetManager, appWidgetId)
        } else {
          val ids = getActiveWidgetIds(context, appWidgetManager)
          for (id in ids) {
            WidgetPreferences.togglePage(context, id)
            updateWidget(context, appWidgetManager, id)
          }
        }
      }

      Intent.ACTION_DATE_CHANGED,
      Intent.ACTION_TIME_CHANGED,
      Intent.ACTION_TIMEZONE_CHANGED,
      -> {
        updateAllWidgets(context)
      }
    }
  }

  companion object {
    const val ACTION_TOGGLE_PAGE = "com.widgets.crayoncalendar.ACTION_TOGGLE_PAGE"

    fun getActiveWidgetIds(
      context: Context,
      appWidgetManager: AppWidgetManager = AppWidgetManager.getInstance(context),
    ): IntArray {
      val component = ComponentName(context, CrayonCalendarWidgetProvider::class.java)
      return appWidgetManager.getAppWidgetIds(component)
    }

    fun updateAllWidgets(context: Context) {
      val appWidgetManager = AppWidgetManager.getInstance(context)
      val ids = getActiveWidgetIds(context, appWidgetManager)
      for (id in ids) {
        updateWidget(context, appWidgetManager, id)
      }
    }

    fun updateWidget(
      context: Context,
      appWidgetManager: AppWidgetManager,
      appWidgetId: Int,
    ) {
      val options = appWidgetManager.getAppWidgetOptions(appWidgetId)
      val density = context.resources.displayMetrics.density
      val minW = options.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 110)
      val minH = options.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, 110)

      val renderWidth = (minW * density * 1.6f).roundToInt().coerceIn(560, 1080)
      val renderHeight = (minH * density * 1.6f).roundToInt().coerceIn(560, 1080)

      val settings = WidgetPreferences.getSettingsForWidget(context, appWidgetId)
      val bitmap = CrayonWidgetRenderer.render(
        context = context,
        settings = settings,
        widthPx = renderWidth,
        heightPx = renderHeight,
      )

      val toggleIntent = Intent(context, CrayonCalendarWidgetProvider::class.java).apply {
        action = ACTION_TOGGLE_PAGE
        putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetId)
      }
      val pendingIntent = PendingIntent.getBroadcast(
        context,
        appWidgetId,
        toggleIntent,
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
      )

      val views = RemoteViews(context.packageName, R.layout.widget_crayon_calendar).apply {
        setImageViewBitmap(R.id.widget_canvas_image, bitmap)
        setOnClickPendingIntent(R.id.widget_root, pendingIntent)
        setOnClickPendingIntent(R.id.widget_canvas_image, pendingIntent)
      }

      appWidgetManager.updateAppWidget(appWidgetId, views)
    }
  }
}
