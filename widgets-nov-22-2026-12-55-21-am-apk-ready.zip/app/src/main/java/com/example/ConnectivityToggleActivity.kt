package com.example

import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import com.example.widget.ConnectivityHelper
import com.example.widget.ToggleTileType

class ConnectivityToggleActivity : ComponentActivity() {

  private val panelLauncher = registerForActivityResult(
    ActivityResultContracts.StartActivityForResult(),
  ) {
    refreshToggleWidgetsWithDelay()
    finishSilently()
  }

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    suppressTransitions()
    val type = ToggleTileType.fromKey(intent?.getStringExtra(EXTRA_TOGGLE_TYPE))

    when (type) {
      ToggleTileType.WIFI -> handleWifiToggle()
      ToggleTileType.MOBILE_DATA -> handleMobileDataToggle()
    }
  }

  private fun handleWifiToggle() {
    if (ConnectivityHelper.canToggleWifiDirectly()) {
      ConnectivityHelper.toggleWifiLegacy(this)
      refreshToggleWidgetsWithDelay()
      finishSilently()
      return
    }

    val panelIntent = when {
      Build.VERSION.SDK_INT >= Build.VERSION_CODES.S ->
        Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY)
      Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q ->
        Intent(Settings.Panel.ACTION_WIFI)
      else -> Intent(Settings.ACTION_WIFI_SETTINGS)
    }
    launchWithFallback(panelIntent, Intent(Settings.ACTION_WIFI_SETTINGS))
  }

  private fun handleMobileDataToggle() {
    val panelIntent = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
      Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY)
    } else {
      Intent(Settings.ACTION_DATA_ROAMING_SETTINGS)
    }
    launchWithFallback(panelIntent, Intent(Settings.ACTION_WIRELESS_SETTINGS))
  }

  private fun launchWithFallback(primary: Intent, fallback: Intent) {
    try {
      panelLauncher.launch(primary)
    } catch (_: Exception) {
      try {
        panelLauncher.launch(fallback)
      } catch (_: Exception) {
        refreshToggleWidgetsWithDelay()
        finishSilently()
      }
    }
  }

  private fun refreshToggleWidgetsWithDelay() {
    val appCtx = applicationContext
    WifiToggleWidgetProvider.updateAllWidgets(appCtx)
    MobileDataToggleWidgetProvider.updateAllWidgets(appCtx)
    val handler = Handler(Looper.getMainLooper())
    handler.postDelayed({
      WifiToggleWidgetProvider.updateAllWidgets(appCtx)
      MobileDataToggleWidgetProvider.updateAllWidgets(appCtx)
    }, 550L)
    handler.postDelayed({
      WifiToggleWidgetProvider.updateAllWidgets(appCtx)
      MobileDataToggleWidgetProvider.updateAllWidgets(appCtx)
    }, 1250L)
  }

  private fun suppressTransitions() {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
      overrideActivityTransition(OVERRIDE_TRANSITION_OPEN, 0, 0)
      overrideActivityTransition(OVERRIDE_TRANSITION_CLOSE, 0, 0)
    } else {
      @Suppress("DEPRECATION")
      overridePendingTransition(0, 0)
    }
  }

  private fun finishSilently() {
    finish()
    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
      @Suppress("DEPRECATION")
      overridePendingTransition(0, 0)
    }
  }

  companion object {
    const val EXTRA_TOGGLE_TYPE = "extra_toggle_type"

    fun createLaunchIntent(context: Context, type: ToggleTileType): Intent =
      Intent(context, ConnectivityToggleActivity::class.java).apply {
        action = "com.example.ACTION_TOGGLE_${type.extraKey}"
        putExtra(EXTRA_TOGGLE_TYPE, type.extraKey)
        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
      }
  }
}
