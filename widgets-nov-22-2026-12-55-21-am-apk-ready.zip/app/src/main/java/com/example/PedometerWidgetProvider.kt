package com.example

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.RemoteViews
import com.example.widget.CrayonWidgetRenderer
import com.example.widget.PedometerHelper
import com.example.widget.PedometerSnapshot
import com.example.widget.WidgetPreferences
import kotlin.math.roundToInt

class PedometerWidgetProvider : AppWidgetProvider() {

  override fun onEnabled(context: Context) {
    super.onEnabled(context)
    val appContext = context.applicationContext
    PedometerSyncJobService.scheduleIfNeeded(appContext)
    (appContext as? WidgetsApplication)?.ensureStepMonitoring()
  }

  override fun onDisabled(context: Context) {
    super.onDisabled(context)
    val appContext = context.applicationContext
    PedometerSyncJobService.cancel(appContext)
    (appContext as? WidgetsApplication)?.stopStepMonitoringIfNoWidgets()
  }

  override fun onUpdate(
    context: Context,
    appWidgetManager: AppWidgetManager,
    appWidgetIds: IntArray,
  ) {
    val appContext = context.applicationContext
    val cached = PedometerHelper.getStepSnapshot(appContext)
    for (appWidgetId in appWidgetIds) {
      updateWidget(appContext, appWidgetManager, appWidgetId, cached)
    }

    if (cached.hasPermission && cached.isSensorAvailable) {
      PedometerSyncJobService.scheduleIfNeeded(appContext)
      (appContext as? WidgetsApplication)?.ensureStepMonitoring()
      val pendingResult = runCatching { goAsync() }.getOrNull()
      PedometerHelper.refreshStepsFromSensor(appContext, timeoutMs = 2200L) { latest ->
        val manager = AppWidgetManager.getInstance(appContext)
        for (appWidgetId in appWidgetIds) {
          updateWidget(appContext, manager, appWidgetId, latest)
        }
        runCatching { pendingResult?.finish() }
      }
    }
  }

  override fun onAppWidgetOptionsChanged(
    context: Context,
    appWidgetManager: AppWidgetManager,
    appWidgetId: Int,
    newOptions: Bundle,
  ) {
    super.onAppWidgetOptionsChanged(context, appWidgetManager, appWidgetId, newOptions)
    updateWidget(context, appWidgetManager, appWidgetId)
  }

  override fun onDeleted(context: Context, appWidgetIds: IntArray) {
    super.onDeleted(context, appWidgetIds)
    for (appWidgetId in appWidgetIds) {
      WidgetPreferences.deleteWidget(context, appWidgetId)
    }
    val appContext = context.applicationContext
    if (getActiveWidgetIds(appContext).isEmpty()) {
      PedometerSyncJobService.cancel(appContext)
      (appContext as? WidgetsApplication)?.stopStepMonitoringIfNoWidgets()
    }
  }

  override fun onReceive(context: Context, intent: Intent) {
    super.onReceive(context, intent)
    when (intent.action) {
      ACTION_REFRESH_STEPS,
      Intent.ACTION_MY_PACKAGE_REPLACED,
      Intent.ACTION_DATE_CHANGED,
      -> {
        val appContext = context.applicationContext
        val snapshot = PedometerHelper.getStepSnapshot(appContext)
        if (snapshot.hasPermission && snapshot.isSensorAvailable) {
          PedometerSyncJobService.scheduleIfNeeded(appContext)
          (appContext as? WidgetsApplication)?.ensureStepMonitoring()
          val pendingResult = runCatching { goAsync() }.getOrNull()
          PedometerHelper.refreshStepsFromSensor(appContext, timeoutMs = 2200L) { latest ->
            val manager = AppWidgetManager.getInstance(appContext)
            val ids = getActiveWidgetIds(appContext, manager)
            for (id in ids) {
              updateWidget(appContext, manager, id, latest)
            }
            runCatching { pendingResult?.finish() }
          }
        } else {
          updateAllWidgets(appContext, snapshot)
        }
      }
    }
  }

  companion object {
    const val ACTION_REFRESH_STEPS = "com.widgets.crayoncalendar.ACTION_REFRESH_STEPS"

    fun getActiveWidgetIds(
      context: Context,
      appWidgetManager: AppWidgetManager = AppWidgetManager.getInstance(context),
    ): IntArray {
      val component = ComponentName(context, PedometerWidgetProvider::class.java)
      return appWidgetManager.getAppWidgetIds(component)
    }

    fun updateAllWidgets(
      context: Context,
      snapshot: PedometerSnapshot = PedometerHelper.getStepSnapshot(context),
    ) {
      val appWidgetManager = AppWidgetManager.getInstance(context)
      val ids = getActiveWidgetIds(context, appWidgetManager)
      for (id in ids) {
        updateWidget(context, appWidgetManager, id, snapshot)
      }
    }

    fun updateWidget(
      context: Context,
      appWidgetManager: AppWidgetManager,
      appWidgetId: Int,
      snapshot: PedometerSnapshot = PedometerHelper.getStepSnapshot(context),
    ) {
      val options = appWidgetManager.getAppWidgetOptions(appWidgetId)
      val density = context.resources.displayMetrics.density
      val minW = options.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 140)
      val minH = options.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, 64)

      val renderWidth = (minW * density * 1.8f).roundToInt().coerceIn(560, 1080)
      val rawHeight = (minH * density * 1.8f).roundToInt().coerceIn(240, 520)
      val renderHeight = rawHeight.coerceAtMost((renderWidth * 0.56f).roundToInt())

      val settings = WidgetPreferences.getSettingsForWidget(context, appWidgetId)
      val bitmap = CrayonWidgetRenderer.renderPedometerPill(
        context = context,
        snapshot = snapshot,
        settings = settings,
        widthPx = renderWidth,
        heightPx = renderHeight,
      )

      val pendingIntent = if (!snapshot.hasPermission) {
        val activityIntent = Intent(context, MainActivity::class.java).apply {
          putExtra(MainActivity.EXTRA_REQUEST_STEP_PERMISSION, true)
          addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        }
        PendingIntent.getActivity(
          context,
          30_000 + appWidgetId,
          activityIntent,
          PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
      } else {
        val refreshIntent = Intent(context, PedometerWidgetProvider::class.java).apply {
          action = ACTION_REFRESH_STEPS
          putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetId)
        }
        PendingIntent.getBroadcast(
          context,
          30_000 + appWidgetId,
          refreshIntent,
          PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
      }

      val views = RemoteViews(context.packageName, R.layout.widget_crayon_calendar).apply {
        setImageViewBitmap(R.id.widget_canvas_image, bitmap)
        setOnClickPendingIntent(R.id.widget_root, pendingIntent)
        setOnClickPendingIntent(R.id.widget_canvas_image, pendingIntent)
      }

      appWidgetManager.updateAppWidget(appWidgetId, views)
    }
  }
}
