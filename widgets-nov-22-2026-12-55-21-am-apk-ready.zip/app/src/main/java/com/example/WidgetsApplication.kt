package com.example

import android.app.Application
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener2
import android.hardware.SensorManager
import android.net.ConnectivityManager
import android.net.Network
import android.net.wifi.WifiManager
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import com.example.widget.PedometerHelper
import com.example.widget.PedometerSnapshot

class WidgetsApplication : Application() {

  private val mainHandler = Handler(Looper.getMainLooper())
  private var stepListenerRegistered = false
  private var lastWidgetStepPushMs = 0L

  private val wifiStateReceiver = object : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
      if (intent.action == WifiManager.WIFI_STATE_CHANGED_ACTION) {
        WifiToggleWidgetProvider.updateAllWidgets(context)
        MobileDataToggleWidgetProvider.updateAllWidgets(context)
      }
    }
  }

  private val userWakeReceiver = object : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
      when (intent.action) {
        Intent.ACTION_USER_PRESENT,
        Intent.ACTION_SCREEN_ON,
        -> {
          if (PedometerWidgetProvider.getActiveWidgetIds(this@WidgetsApplication).isNotEmpty() &&
            PedometerHelper.hasActivityPermission(this@WidgetsApplication)
          ) {
            ensureStepMonitoring()
            val pendingResult = runCatching { goAsync() }.getOrNull()
            PedometerHelper.refreshStepsFromSensor(
              context = this@WidgetsApplication,
              timeoutMs = 1800L,
            ) { latest ->
              PedometerWidgetProvider.updateAllWidgets(this@WidgetsApplication, latest)
              runCatching { pendingResult?.finish() }
            }
          }
        }
      }
    }
  }

  private val passiveStepListener = object : SensorEventListener2 {
    override fun onSensorChanged(event: SensorEvent?) {
      val sensorType = event?.sensor?.type ?: return
      val snapshot = when (sensorType) {
        Sensor.TYPE_STEP_COUNTER -> {
          val stepsSinceBoot = event.values.firstOrNull()?.toLong() ?: return
          PedometerHelper.recordHardwareStepCount(this@WidgetsApplication, stepsSinceBoot)
        }

        Sensor.TYPE_STEP_DETECTOR -> {
          val ticks = event.values.size.coerceAtLeast(1)
          PedometerHelper.recordStepDetectorSteps(this@WidgetsApplication, ticks)
        }

        else -> return
      }
      val now = SystemClock.elapsedRealtime()
      if (now - lastWidgetStepPushMs >= 8_000L) {
        lastWidgetStepPushMs = now
        pushPedometerWidgetUpdate(snapshot)
      }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit

    override fun onFlushCompleted(sensor: Sensor?) = Unit
  }

  private val networkCallback = object : ConnectivityManager.NetworkCallback() {
    override fun onAvailable(network: Network) {
      scheduleToggleRefresh()
    }

    override fun onLost(network: Network) {
      scheduleToggleRefresh()
    }
  }

  override fun onCreate() {
    super.onCreate()
    runCatching {
      registerReceiver(
        wifiStateReceiver,
        IntentFilter(WifiManager.WIFI_STATE_CHANGED_ACTION),
      )
    }
    runCatching {
      registerReceiver(
        userWakeReceiver,
        IntentFilter().apply {
          addAction(Intent.ACTION_USER_PRESENT)
          addAction(Intent.ACTION_SCREEN_ON)
        },
      )
    }
    val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
    runCatching {
      cm?.registerDefaultNetworkCallback(networkCallback)
    }
    PedometerSyncJobService.scheduleIfNeeded(this)
    ensureStepMonitoring()
  }

  fun ensureStepMonitoring() {
    if (stepListenerRegistered) return
    if (!PedometerHelper.hasActivityPermission(this)) return
    if (PedometerWidgetProvider.getActiveWidgetIds(this).isEmpty()) return

    val sensorManager = getSystemService(Context.SENSOR_SERVICE) as? SensorManager ?: return
    val sensor = sensorManager.getDefaultSensor(Sensor.TYPE_STEP_COUNTER)
      ?: sensorManager.getDefaultSensor(Sensor.TYPE_STEP_DETECTOR)
      ?: return

    stepListenerRegistered = runCatching {
      sensorManager.registerListener(
        passiveStepListener,
        sensor,
        SensorManager.SENSOR_DELAY_NORMAL,
        30_000_000,
        mainHandler,
      )
    }.getOrDefault(false)

    if (stepListenerRegistered) {
      runCatching { sensorManager.flush(passiveStepListener) }
    }
  }

  fun stopStepMonitoringIfNoWidgets() {
    if (!stepListenerRegistered) return
    if (PedometerWidgetProvider.getActiveWidgetIds(this).isNotEmpty()) return
    val sensorManager = getSystemService(Context.SENSOR_SERVICE) as? SensorManager ?: return
    runCatching { sensorManager.unregisterListener(passiveStepListener) }
    stepListenerRegistered = false
  }

  private fun pushPedometerWidgetUpdate(snapshot: PedometerSnapshot) {
    mainHandler.post {
      PedometerWidgetProvider.updateAllWidgets(this, snapshot)
    }
  }

  private fun scheduleToggleRefresh() {
    mainHandler.post {
      WifiToggleWidgetProvider.updateAllWidgets(this)
      MobileDataToggleWidgetProvider.updateAllWidgets(this)
    }
  }
}
