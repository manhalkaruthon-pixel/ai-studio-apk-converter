package com.example

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.RemoteViews
import com.example.widget.ConnectivityHelper
import com.example.widget.CrayonWidgetRenderer
import com.example.widget.ToggleTileType
import com.example.widget.WidgetPreferences
import kotlin.math.roundToInt

class MobileDataToggleWidgetProvider : AppWidgetProvider() {

  override fun onUpdate(
    context: Context,
    appWidgetManager: AppWidgetManager,
    appWidgetIds: IntArray,
  ) {
    for (appWidgetId in appWidgetIds) {
      updateWidget(context, appWidgetManager, appWidgetId)
    }
  }

  override fun onAppWidgetOptionsChanged(
    context: Context,
    appWidgetManager: AppWidgetManager,
    appWidgetId: Int,
    newOptions: Bundle,
  ) {
    super.onAppWidgetOptionsChanged(context, appWidgetManager, appWidgetId, newOptions)
    updateWidget(context, appWidgetManager, appWidgetId)
  }

  override fun onDeleted(context: Context, appWidgetIds: IntArray) {
    super.onDeleted(context, appWidgetIds)
    for (appWidgetId in appWidgetIds) {
      WidgetPreferences.deleteWidget(context, appWidgetId)
    }
  }

  companion object {
    fun getActiveWidgetIds(
      context: Context,
      appWidgetManager: AppWidgetManager = AppWidgetManager.getInstance(context),
    ): IntArray {
      val component = ComponentName(context, MobileDataToggleWidgetProvider::class.java)
      return appWidgetManager.getAppWidgetIds(component)
    }

    fun updateAllWidgets(context: Context) {
      val appWidgetManager = AppWidgetManager.getInstance(context)
      val ids = getActiveWidgetIds(context, appWidgetManager)
      for (id in ids) {
        updateWidget(context, appWidgetManager, id)
      }
    }

    fun updateWidget(
      context: Context,
      appWidgetManager: AppWidgetManager,
      appWidgetId: Int,
    ) {
      val options = appWidgetManager.getAppWidgetOptions(appWidgetId)
      val density = context.resources.displayMetrics.density
      val minW = options.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 60)
      val minH = options.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, 60)

      val renderWidth = (minW * density * 2.0f).roundToInt().coerceIn(360, 720)
      val renderHeight = (minH * density * 2.0f).roundToInt().coerceIn(360, 720)

      val settings = WidgetPreferences.getSettingsForWidget(context, appWidgetId)
      val dataOn = ConnectivityHelper.isMobileDataEnabled(context)
      val bitmap = CrayonWidgetRenderer.renderToggleTile(
        context = context,
        type = ToggleTileType.MOBILE_DATA,
        isEnabled = dataOn,
        settings = settings,
        widthPx = renderWidth,
        heightPx = renderHeight,
      )

      val launchIntent = ConnectivityToggleActivity.createLaunchIntent(
        context,
        ToggleTileType.MOBILE_DATA,
      )
      val pendingIntent = PendingIntent.getActivity(
        context,
        20_000 + appWidgetId,
        launchIntent,
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
      )

      val views = RemoteViews(context.packageName, R.layout.widget_crayon_calendar).apply {
        setImageViewBitmap(R.id.widget_canvas_image, bitmap)
        setOnClickPendingIntent(R.id.widget_root, pendingIntent)
        setOnClickPendingIntent(R.id.widget_canvas_image, pendingIntent)
      }

      appWidgetManager.updateAppWidget(appWidgetId, views)
    }
  }
}
