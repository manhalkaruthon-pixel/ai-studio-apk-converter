package com.example

import android.app.job.JobInfo
import android.app.job.JobParameters
import android.app.job.JobScheduler
import android.app.job.JobService
import android.content.ComponentName
import android.content.Context
import com.example.widget.PedometerHelper

class PedometerSyncJobService : JobService() {

  override fun onStartJob(params: JobParameters): Boolean {
    val appContext = applicationContext
    if (PedometerWidgetProvider.getActiveWidgetIds(appContext).isEmpty() ||
      !PedometerHelper.hasActivityPermission(appContext) ||
      !PedometerHelper.isStepSensorAvailable(appContext)
    ) {
      cancel(appContext)
      return false
    }

    (appContext as? WidgetsApplication)?.ensureStepMonitoring()

    PedometerHelper.refreshStepsFromSensor(appContext, timeoutMs = 2400L) { latest ->
      PedometerWidgetProvider.updateAllWidgets(appContext, latest)
      jobFinished(params, false)
    }
    return true
  }

  override fun onStopJob(params: JobParameters): Boolean = true

  companion object {
    private const val JOB_ID = 7021
    private const val PERIODIC_INTERVAL_MS = 15L * 60_000L

    fun scheduleIfNeeded(context: Context) {
      val appContext = context.applicationContext
      if (PedometerWidgetProvider.getActiveWidgetIds(appContext).isEmpty() ||
        !PedometerHelper.hasActivityPermission(appContext) ||
        !PedometerHelper.isStepSensorAvailable(appContext)
      ) {
        return
      }
      val scheduler = appContext.getSystemService(Context.JOB_SCHEDULER_SERVICE) as? JobScheduler
        ?: return
      if (scheduler.getPendingJob(JOB_ID) != null) return

      val component = ComponentName(appContext, PedometerSyncJobService::class.java)
      val jobInfo = JobInfo.Builder(JOB_ID, component)
        .setPeriodic(PERIODIC_INTERVAL_MS)
        .setRequiresBatteryNotLow(false)
        .setRequiresCharging(false)
        .build()

      runCatching { scheduler.schedule(jobInfo) }
    }

    fun cancel(context: Context) {
      val scheduler = context.applicationContext
        .getSystemService(Context.JOB_SCHEDULER_SERVICE) as? JobScheduler ?: return
      runCatching { scheduler.cancel(JOB_ID) }
    }
  }
}
