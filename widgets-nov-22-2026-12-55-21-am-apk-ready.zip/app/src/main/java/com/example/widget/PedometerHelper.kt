package com.example.widget

import android.Manifest
import android.content.Context
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener2
import android.hardware.SensorManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean

data class PedometerSnapshot(
  val stepsToday: Int = 0,
  val dailyGoal: Int = 8000,
  val hasPermission: Boolean = false,
  val isSensorAvailable: Boolean = true,
) {
  val progressFraction: Float
    get() = if (dailyGoal > 0) (stepsToday.toFloat() / dailyGoal.toFloat()).coerceIn(0f, 1f) else 0f
}

object PedometerHelper {
  private const val PREFS_NAME = "crayon_pedometer_prefs"
  private const val KEY_DAY = "step_day_key"
  private const val KEY_BASELINE = "step_day_baseline"
  private const val KEY_OFFSET = "step_day_offset"
  private const val KEY_LAST_SENSOR = "step_last_sensor"
  private const val KEY_TODAY_STEPS = "step_today_count"
  private const val KEY_DAILY_GOAL = "step_daily_goal"
  private const val DEFAULT_GOAL = 8000

  private fun prefs(context: Context): SharedPreferences =
    context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

  private fun todayKey(): String =
    SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())

  fun hasActivityPermission(context: Context): Boolean {
    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return true
    return ContextCompat.checkSelfPermission(
      context,
      Manifest.permission.ACTIVITY_RECOGNITION,
    ) == PackageManager.PERMISSION_GRANTED
  }

  fun isStepSensorAvailable(context: Context): Boolean {
    val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as? SensorManager
    return sensorManager?.getDefaultSensor(Sensor.TYPE_STEP_COUNTER) != null ||
      sensorManager?.getDefaultSensor(Sensor.TYPE_STEP_DETECTOR) != null
  }

  fun hasBaselineForToday(context: Context): Boolean {
    val p = prefs(context)
    return p.getString(KEY_DAY, null) == todayKey() && p.getLong(KEY_BASELINE, -1L) >= 0L
  }

  fun getStepSnapshot(context: Context): PedometerSnapshot {
    val p = prefs(context)
    val today = todayKey()
    val storedDay = p.getString(KEY_DAY, null)
    val goal = p.getInt(KEY_DAILY_GOAL, DEFAULT_GOAL).coerceAtLeast(1000)

    val steps = if (storedDay == today) {
      p.getInt(KEY_TODAY_STEPS, 0).coerceAtLeast(0)
    } else {
      0
    }

    return PedometerSnapshot(
      stepsToday = steps,
      dailyGoal = goal,
      hasPermission = hasActivityPermission(context),
      isSensorAvailable = isStepSensorAvailable(context),
    )
  }

  @Synchronized
  fun recordHardwareStepCount(context: Context, stepsSinceBoot: Long): PedometerSnapshot {
    val safeReading = stepsSinceBoot.coerceAtLeast(0L)
    val p = prefs(context)
    val today = todayKey()
    val storedDay = p.getString(KEY_DAY, null)
    val goal = p.getInt(KEY_DAILY_GOAL, DEFAULT_GOAL).coerceAtLeast(1000)

    val newBaseline: Long
    val newOffset: Long
    val newLastSensor: Long
    val todaySteps: Int

    if (storedDay != today) {
      newBaseline = safeReading
      newOffset = 0L
      newLastSensor = safeReading
      todaySteps = 0
    } else {
      val prevBaseline = p.getLong(KEY_BASELINE, -1L)
      val prevOffset = p.getLong(KEY_OFFSET, 0L)
      val prevLastSensor = p.getLong(KEY_LAST_SENSOR, safeReading)

      if (prevBaseline < 0L) {
        newBaseline = safeReading
        newOffset = prevOffset
        newLastSensor = safeReading
        todaySteps = prevOffset.toInt().coerceAtLeast(0)
      } else if (safeReading < prevLastSensor) {
        // Device rebooted today: preserve pre-reboot steps in offset and reset baseline to 0.
        val accumulatedBeforeReboot = (prevLastSensor - prevBaseline).coerceAtLeast(0L)
        newOffset = prevOffset + accumulatedBeforeReboot
        newBaseline = 0L
        newLastSensor = safeReading
        todaySteps = (newOffset + safeReading).toInt().coerceAtLeast(0)
      } else {
        newBaseline = prevBaseline
        newOffset = prevOffset
        newLastSensor = safeReading
        todaySteps = (prevOffset + (safeReading - prevBaseline).coerceAtLeast(0L))
          .toInt()
          .coerceAtLeast(0)
      }
    }

    p.edit()
      .putString(KEY_DAY, today)
      .putLong(KEY_BASELINE, newBaseline)
      .putLong(KEY_OFFSET, newOffset)
      .putLong(KEY_LAST_SENSOR, newLastSensor)
      .putInt(KEY_TODAY_STEPS, todaySteps)
      .apply()

    return PedometerSnapshot(
      stepsToday = todaySteps,
      dailyGoal = goal,
      hasPermission = hasActivityPermission(context),
      isSensorAvailable = isStepSensorAvailable(context),
    )
  }

  /**
   * Fallback incremental step counter for devices exposing TYPE_STEP_DETECTOR without TYPE_STEP_COUNTER.
   */
  @Synchronized
  fun recordStepDetectorSteps(context: Context, deltaSteps: Int): PedometerSnapshot {
    val safeDelta = deltaSteps.coerceAtLeast(0)
    val p = prefs(context)
    val today = todayKey()
    val storedDay = p.getString(KEY_DAY, null)
    val goal = p.getInt(KEY_DAILY_GOAL, DEFAULT_GOAL).coerceAtLeast(1000)

    val updatedSteps = if (storedDay != today) {
      safeDelta
    } else {
      (p.getInt(KEY_TODAY_STEPS, 0) + safeDelta).coerceAtLeast(0)
    }

    p.edit()
      .putString(KEY_DAY, today)
      .putInt(KEY_TODAY_STEPS, updatedSteps)
      .apply()

    return PedometerSnapshot(
      stepsToday = updatedSteps,
      dailyGoal = goal,
      hasPermission = hasActivityPermission(context),
      isSensorAvailable = isStepSensorAvailable(context),
    )
  }

  /**
   * Performs a flushed hardware step counter read with zero batching latency
   * so widget refreshes, unlocks, and background jobs read real steps reliably.
   */
  fun refreshStepsFromSensor(
    context: Context,
    timeoutMs: Long = 2200L,
    onComplete: (PedometerSnapshot) -> Unit,
  ) {
    val appContext = context.applicationContext
    val mainHandler = Handler(Looper.getMainLooper())
    if (!hasActivityPermission(appContext)) {
      mainHandler.post { onComplete(getStepSnapshot(appContext)) }
      return
    }

    val sensorManager = appContext.getSystemService(Context.SENSOR_SERVICE) as? SensorManager
    val stepCounter = sensorManager?.getDefaultSensor(Sensor.TYPE_STEP_COUNTER)
    val stepDetector = sensorManager?.getDefaultSensor(Sensor.TYPE_STEP_DETECTOR)
    val activeSensor = stepCounter ?: stepDetector
    if (sensorManager == null || activeSensor == null) {
      mainHandler.post { onComplete(getStepSnapshot(appContext)) }
      return
    }

    val finished = AtomicBoolean(false)
    var listenerRef: SensorEventListener2? = null

    val timeoutRunnable = Runnable {
      if (finished.compareAndSet(false, true)) {
        listenerRef?.let { runCatching { sensorManager.unregisterListener(it) } }
        onComplete(getStepSnapshot(appContext))
      }
    }

    val listener = object : SensorEventListener2 {
      override fun onSensorChanged(event: SensorEvent?) {
        val sensorType = event?.sensor?.type ?: return
        if (sensorType == Sensor.TYPE_STEP_COUNTER) {
          val value = event.values.firstOrNull()?.toLong() ?: return
          if (finished.compareAndSet(false, true)) {
            mainHandler.removeCallbacks(timeoutRunnable)
            runCatching { sensorManager.unregisterListener(this) }
            val snapshot = recordHardwareStepCount(appContext, value)
            onComplete(snapshot)
          }
        } else if (sensorType == Sensor.TYPE_STEP_DETECTOR) {
          val ticks = event.values.size.coerceAtLeast(1)
          recordStepDetectorSteps(appContext, ticks)
        }
      }

      override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit

      override fun onFlushCompleted(sensor: Sensor?) = Unit
    }
    listenerRef = listener

    val registered = runCatching {
      sensorManager.registerListener(
        listener,
        activeSensor,
        SensorManager.SENSOR_DELAY_FASTEST,
        0,
        mainHandler,
      )
    }.getOrDefault(false)

    if (!registered) {
      if (finished.compareAndSet(false, true)) {
        mainHandler.post { onComplete(getStepSnapshot(appContext)) }
      }
      return
    }

    runCatching { sensorManager.flush(listener) }
    mainHandler.postDelayed(timeoutRunnable, timeoutMs)
  }
}
