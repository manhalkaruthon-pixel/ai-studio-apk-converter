package com.example.widget

enum class CrayonIconShape(
  val id: String,
  val displayName: String,
) {
  SQUIRCLE(
    id = "squircle",
    displayName = "Squircle",
  ),
  CIRCLE(
    id = "circle",
    displayName = "Circle",
  );

  companion object {
    fun fromId(id: String?): CrayonIconShape =
      entries.firstOrNull { it.id == id } ?: SQUIRCLE
  }
}

enum class CrayonIconCategory(
  val displayName: String,
) {
  ALL("All"),
  ESSENTIALS("Essentials"),
  AI_WORK("AI & Work"),
  FINANCE_DAILY("Pay & Daily"),
  SOCIAL("Social"),
  MEDIA("Media"),
  UTILITIES("Utilities"),
}

enum class IconPackBrowseMode(
  val displayName: String,
) {
  INSTALLED_APPS("Your Apps"),
  ICON_LIBRARY("Icon Library"),
}

enum class CrayonIconKind(
  val id: String,
  val label: String,
  val category: CrayonIconCategory,
  val packageKeywords: List<String>,
) {
  // Specific multi-word / sub-app matches ordered carefully before generic ones
  YT_STUDIO(
    id = "yt_studio",
    label = "YT Studio",
    category = CrayonIconCategory.MEDIA,
    packageKeywords = listOf("youtube.creator", "yt studio", "ytstudio"),
  ),
  GEMINI(
    id = "gemini",
    label = "Gemini",
    category = CrayonIconCategory.AI_WORK,
    packageKeywords = listOf("apps.bard", "gemini"),
  ),
  CHATGPT(
    id = "chatgpt",
    label = "ChatGPT",
    category = CrayonIconCategory.AI_WORK,
    packageKeywords = listOf("openai.chatgpt", "chatgpt"),
  ),
  CLAUDE(
    id = "claude",
    label = "Claude",
    category = CrayonIconCategory.AI_WORK,
    packageKeywords = listOf("anthropic.claude", "claude", "cluade"),
  ),
  DEEPSEEK(
    id = "deepseek",
    label = "DeepSeek",
    category = CrayonIconCategory.AI_WORK,
    packageKeywords = listOf("deepseek"),
  ),
  LINKEDIN(
    id = "linkedin",
    label = "LinkedIn",
    category = CrayonIconCategory.AI_WORK,
    packageKeywords = listOf("linkedin"),
  ),
  TEAMS(
    id = "teams",
    label = "Teams",
    category = CrayonIconCategory.AI_WORK,
    packageKeywords = listOf("microsoft.teams", "teams"),
  ),
  OUTLOOK(
    id = "outlook",
    label = "Outlook",
    category = CrayonIconCategory.AI_WORK,
    packageKeywords = listOf("microsoft.office.outlook", "outlook"),
  ),
  EXCEL(
    id = "excel",
    label = "Excel",
    category = CrayonIconCategory.AI_WORK,
    packageKeywords = listOf("microsoft.office.excel", "excel"),
  ),
  ZOOM(
    id = "zoom",
    label = "Zoom",
    category = CrayonIconCategory.AI_WORK,
    packageKeywords = listOf("zoom.videomeetings", "zoom"),
  ),
  DOCS(
    id = "docs",
    label = "Docs",
    category = CrayonIconCategory.AI_WORK,
    packageKeywords = listOf("editors.docs", "google docs"),
  ),
  DRIVE(
    id = "drive",
    label = "Drive",
    category = CrayonIconCategory.AI_WORK,
    packageKeywords = listOf("apps.docs", "google drive", "drive"),
  ),
  UNACADEMY(
    id = "unacademy",
    label = "Unacademy",
    category = CrayonIconCategory.AI_WORK,
    packageKeywords = listOf("unacademy"),
  ),
  MENTIHUB(
    id = "mentihub",
    label = "MentiHub",
    category = CrayonIconCategory.AI_WORK,
    packageKeywords = listOf("xandylearning", "mentihub", "menti"),
  ),
  GREYTHR(
    id = "greythr",
    label = "greytHR",
    category = CrayonIconCategory.AI_WORK,
    packageKeywords = listOf("greytip", "ghress", "greythr"),
  ),
  INDEED(
    id = "indeed",
    label = "Indeed",
    category = CrayonIconCategory.AI_WORK,
    packageKeywords = listOf("indeed.android", "indeed"),
  ),
  AUTHENTICATOR(
    id = "authenticator",
    label = "Authenticator",
    category = CrayonIconCategory.UTILITIES,
    packageKeywords = listOf("authenticator2", "authenticator"),
  ),
  DIGILOCKER(
    id = "digilocker",
    label = "DigiLocker",
    category = CrayonIconCategory.UTILITIES,
    packageKeywords = listOf("digilocker"),
  ),
  WELLBEING(
    id = "wellbeing",
    label = "Wellbeing",
    category = CrayonIconCategory.UTILITIES,
    packageKeywords = listOf("apps.wellbeing", "digital wellbeing", "wellbeing"),
  ),
  IMOBILE(
    id = "imobile",
    label = "iMobile",
    category = CrayonIconCategory.FINANCE_DAILY,
    packageKeywords = listOf("imobile", "icici", "imbole"),
  ),
  YONO_SBI(
    id = "yono_sbi",
    label = "YONO SBI",
    category = CrayonIconCategory.FINANCE_DAILY,
    packageKeywords = listOf("lotusintouch", "yono sbi", "yono"),
  ),
  SBI_CARD(
    id = "sbi_card",
    label = "SBI Card",
    category = CrayonIconCategory.FINANCE_DAILY,
    packageKeywords = listOf("sbicard", "sbi card"),
  ),
  AXIS_MOBILE(
    id = "axis_mobile",
    label = "Axis Mobile",
    category = CrayonIconCategory.FINANCE_DAILY,
    packageKeywords = listOf("axis.mobile", "axis mobile", "axismobile"),
  ),
  KOTAK_NEO(
    id = "kotak_neo",
    label = "Kotak Neo",
    category = CrayonIconCategory.FINANCE_DAILY,
    packageKeywords = listOf("kotak.neo", "kotak neo", "kotak"),
  ),
  BHIM(
    id = "bhim",
    label = "BHIM",
    category = CrayonIconCategory.FINANCE_DAILY,
    packageKeywords = listOf("npci.upiapp", "bhim"),
  ),
  CRED(
    id = "cred",
    label = "CRED",
    category = CrayonIconCategory.FINANCE_DAILY,
    packageKeywords = listOf("dreamplug.androidapp", "cred"),
  ),
  COINDCX(
    id = "coindcx",
    label = "CoinDCX",
    category = CrayonIconCategory.FINANCE_DAILY,
    packageKeywords = listOf("coindcx"),
  ),
  RAPIDO(
    id = "rapido",
    label = "Rapido",
    category = CrayonIconCategory.FINANCE_DAILY,
    packageKeywords = listOf("rapido"),
  ),
  CHALO(
    id = "chalo",
    label = "Chalo",
    category = CrayonIconCategory.FINANCE_DAILY,
    packageKeywords = listOf("app.zophop", "chalo", "zophop"),
  ),
  UBER(
    id = "uber",
    label = "Uber",
    category = CrayonIconCategory.FINANCE_DAILY,
    packageKeywords = listOf("com.ubercab", "uber"),
  ),
  RAILONE(
    id = "railone",
    label = "RailOne",
    category = CrayonIconCategory.FINANCE_DAILY,
    packageKeywords = listOf("railone", "railonr", "aikyam", "cris.org", "irctc"),
  ),
  TENMIN(
    id = "tenmin",
    label = "10Min",
    category = CrayonIconCategory.FINANCE_DAILY,
    packageKeywords = listOf("tenmin", "ai.tenmin", "10min", "zepto"),
  ),
  BLINKIT(
    id = "blinkit",
    label = "Blinkit",
    category = CrayonIconCategory.FINANCE_DAILY,
    packageKeywords = listOf("grofers", "blinkit"),
  ),
  INSTAMART(
    id = "instamart",
    label = "Instamart",
    category = CrayonIconCategory.FINANCE_DAILY,
    packageKeywords = listOf("android.instamart", "instamart", "insta mart"),
  ),
  SWIGGY(
    id = "swiggy",
    label = "Swiggy",
    category = CrayonIconCategory.FINANCE_DAILY,
    packageKeywords = listOf("in.swiggy.android", "swiggy"),
  ),
  FLIPKART(
    id = "flipkart",
    label = "Flipkart",
    category = CrayonIconCategory.FINANCE_DAILY,
    packageKeywords = listOf("flipkart"),
  ),
  DOMINOS(
    id = "dominos",
    label = "Domino's",
    category = CrayonIconCategory.FINANCE_DAILY,
    packageKeywords = listOf("dominos"),
  ),
  JIOHOTSTAR(
    id = "jiohotstar",
    label = "JioHotstar",
    category = CrayonIconCategory.MEDIA,
    packageKeywords = listOf("hotstar", "jiohotstar"),
  ),
  VLC(
    id = "vlc",
    label = "VLC",
    category = CrayonIconCategory.MEDIA,
    packageKeywords = listOf("videolan.vlc", "vlc"),
  ),
  MINECRAFT(
    id = "minecraft",
    label = "Minecraft",
    category = CrayonIconCategory.MEDIA,
    packageKeywords = listOf("minecraft"),
  ),
  COMERA(
    id = "comera",
    label = "Comera",
    category = CrayonIconCategory.SOCIAL,
    packageKeywords = listOf("is.core.app", "comera"),
  ),
  GOOGLE(
    id = "google",
    label = "Google",
    category = CrayonIconCategory.ESSENTIALS,
    packageKeywords = listOf("googlequicksearchbox"),
  ),
  PHONE(
    id = "phone",
    label = "Phone",
    category = CrayonIconCategory.ESSENTIALS,
    packageKeywords = listOf("dialer", "phone", "telecom"),
  ),
  MESSAGES(
    id = "messages",
    label = "Messages",
    category = CrayonIconCategory.SOCIAL,
    packageKeywords = listOf("messaging", "mms", "sms", "messages"),
  ),
  CAMERA(
    id = "camera",
    label = "Camera",
    category = CrayonIconCategory.ESSENTIALS,
    packageKeywords = listOf("camera"),
  ),
  BROWSER(
    id = "browser",
    label = "Browser",
    category = CrayonIconCategory.ESSENTIALS,
    packageKeywords = listOf("chrome", "firefox", "browser", "brave", "opera", "edge", "duckduckgo"),
  ),
  PHOTOS(
    id = "photos",
    label = "Photos",
    category = CrayonIconCategory.MEDIA,
    packageKeywords = listOf("photos", "gallery"),
  ),
  SETTINGS(
    id = "settings",
    label = "Settings",
    category = CrayonIconCategory.UTILITIES,
    packageKeywords = listOf("com.android.settings", "settings"),
  ),
  CLOCK(
    id = "clock",
    label = "Clock",
    category = CrayonIconCategory.UTILITIES,
    packageKeywords = listOf("deskclock", "clock", "alarm"),
  ),
  CALENDAR(
    id = "calendar",
    label = "Calendar",
    category = CrayonIconCategory.ESSENTIALS,
    packageKeywords = listOf("calendar"),
  ),
  CALCULATOR(
    id = "calculator",
    label = "Calculator",
    category = CrayonIconCategory.UTILITIES,
    packageKeywords = listOf("calculator", "ntcalculator"),
  ),
  WEATHER(
    id = "weather",
    label = "Weather",
    category = CrayonIconCategory.UTILITIES,
    packageKeywords = listOf("weather"),
  ),
  NOTES(
    id = "notes",
    label = "Notes",
    category = CrayonIconCategory.UTILITIES,
    packageKeywords = listOf("google.android.keep", "notes", "obsidian", "notion"),
  ),
  FILES(
    id = "files",
    label = "Files",
    category = CrayonIconCategory.UTILITIES,
    packageKeywords = listOf("documentsui", "nbu.files", "files", "filemanager"),
  ),
  CONTACTS(
    id = "contacts",
    label = "Contacts",
    category = CrayonIconCategory.ESSENTIALS,
    packageKeywords = listOf("contacts"),
  ),
  MAIL(
    id = "mail",
    label = "Mail",
    category = CrayonIconCategory.SOCIAL,
    packageKeywords = listOf("android.gm", "gmail", "mail", "proton"),
  ),
  COMPASS(
    id = "compass",
    label = "Compass",
    category = CrayonIconCategory.UTILITIES,
    packageKeywords = listOf("compass", "hearthstone"),
  ),
  MAPS(
    id = "maps",
    label = "Maps",
    category = CrayonIconCategory.ESSENTIALS,
    packageKeywords = listOf("apps.maps", "maps", "apps.adm", "find hub", "waze", "osmand"),
  ),
  MUSIC(
    id = "music",
    label = "Music",
    category = CrayonIconCategory.MEDIA,
    packageKeywords = listOf("youtube.music", "music"),
  ),
  SPOTIFY(
    id = "spotify",
    label = "Spotify",
    category = CrayonIconCategory.MEDIA,
    packageKeywords = listOf("spotify"),
  ),
  YOUTUBE(
    id = "youtube",
    label = "YouTube",
    category = CrayonIconCategory.MEDIA,
    packageKeywords = listOf("android.youtube", "youtube"),
  ),
  WHATSAPP(
    id = "whatsapp",
    label = "WhatsApp",
    category = CrayonIconCategory.SOCIAL,
    packageKeywords = listOf("whatsapp"),
  ),
  INSTAGRAM(
    id = "instagram",
    label = "Instagram",
    category = CrayonIconCategory.SOCIAL,
    packageKeywords = listOf("instagram"),
  ),
  TELEGRAM(
    id = "telegram",
    label = "Telegram",
    category = CrayonIconCategory.SOCIAL,
    packageKeywords = listOf("telegram"),
  ),
  DISCORD(
    id = "discord",
    label = "Discord",
    category = CrayonIconCategory.SOCIAL,
    packageKeywords = listOf("discord"),
  ),
  PLAY_STORE(
    id = "play_store",
    label = "Store",
    category = CrayonIconCategory.ESSENTIALS,
    packageKeywords = listOf("android.vending", "play store", "aurora", "fdroid"),
  ),
  GPAY(
    id = "gpay",
    label = "GPay",
    category = CrayonIconCategory.FINANCE_DAILY,
    packageKeywords = listOf("nbu.paisa", "gpay", "google pay", "tez"),
  ),
  WALLET(
    id = "wallet",
    label = "Wallet",
    category = CrayonIconCategory.FINANCE_DAILY,
    packageKeywords = listOf("wallet", "phonepe", "paytm"),
  ),
  RECORDER(
    id = "recorder",
    label = "Recorder",
    category = CrayonIconCategory.MEDIA,
    packageKeywords = listOf("recorder", "soundrecorder"),
  ),
  PODCASTS(
    id = "podcasts",
    label = "Podcasts",
    category = CrayonIconCategory.MEDIA,
    packageKeywords = listOf("podcast", "pocketcasts", "antennapod"),
  ),
  FITNESS(
    id = "fitness",
    label = "Fitness",
    category = CrayonIconCategory.UTILITIES,
    packageKeywords = listOf("apps.fitness", "fitness", "health", "strava", "nothingx"),
  ),
  SHOPPING(
    id = "shopping",
    label = "Shop",
    category = CrayonIconCategory.FINANCE_DAILY,
    packageKeywords = listOf("amazon", "myntra", "shop"),
  ),
  GAMES(
    id = "games",
    label = "Games",
    category = CrayonIconCategory.MEDIA,
    packageKeywords = listOf("playgames", "steam", "games"),
  ),
  TERMINAL(
    id = "terminal",
    label = "Terminal",
    category = CrayonIconCategory.UTILITIES,
    packageKeywords = listOf("termux", "terminal", "shell"),
  );

  companion object {
    fun fromId(id: String?): CrayonIconKind =
      entries.firstOrNull { it.id == id } ?: PHONE
  }
}
