package com.example.widget

import androidx.annotation.FontRes
import androidx.compose.ui.graphics.Color
import com.example.R

enum class CrayonFontOption(
  val id: String,
  val displayName: String,
  val subtitle: String,
  @param:FontRes val fontResId: Int,
  val heroScaleMultiplier: Float = 1.0f,
  val waxRoughness: Float = 1.0f,
) {
  FINGER_PAINT(
    id = "finger_paint",
    displayName = "Finger Wax",
    subtitle = "Thick Oil Crayon",
    fontResId = R.font.finger_paint,
    heroScaleMultiplier = 0.92f,
    waxRoughness = 1.22f,
  ),
  WALTER_TURNCOAT(
    id = "walter_turncoat",
    displayName = "Chunky Stick",
    subtitle = "Bold Wax Print",
    fontResId = R.font.walter_turncoat,
    heroScaleMultiplier = 0.96f,
    waxRoughness = 1.12f,
  ),
  SCHOOLBELL(
    id = "schoolbell",
    displayName = "School Crayon",
    subtitle = "Playful Sketch",
    fontResId = R.font.schoolbell,
    heroScaleMultiplier = 1.06f,
    waxRoughness = 1.08f,
  ),
  BARRIECITO(
    id = "barriecito",
    displayName = "Block Pastel",
    subtitle = "Artisan Cutout",
    fontResId = R.font.barriecito,
    heroScaleMultiplier = 0.98f,
    waxRoughness = 1.16f,
  ),
  GOCHI_HAND(
    id = "gochi_hand",
    displayName = "Soft Wax",
    subtitle = "Rounded Script",
    fontResId = R.font.gochi_hand,
    heroScaleMultiplier = 1.08f,
    waxRoughness = 1.04f,
  ),
  FREDERICKA(
    id = "fredericka",
    displayName = "Chalk Sketch",
    subtitle = "Textured Etch",
    fontResId = R.font.fredericka_the_great,
    heroScaleMultiplier = 0.94f,
    waxRoughness = 0.95f,
  );

  companion object {
    fun fromId(id: String?): CrayonFontOption =
      entries.firstOrNull { it.id == id } ?: FINGER_PAINT
  }
}

enum class GlassThemeOption(
  val id: String,
  val displayName: String,
  val subtitle: String,
  val glassTopArgb: Int,
  val glassMidArgb: Int,
  val glassBottomArgb: Int,
  val inkPrimaryArgb: Int,
  val inkSecondaryArgb: Int,
  val accentArgb: Int,
  val rimHighlightArgb: Int,
  val rimPrismaticArgb: Int,
  val rimBounceArgb: Int,
  val isDarkGlass: Boolean,
  val studioBackdropTop: Color,
  val studioBackdropBottom: Color,
) {
  WARM_VERMILION(
    id = "warm_vermilion",
    displayName = "Ivory & Vermilion",
    subtitle = "Bauhaus Split",
    glassTopArgb = 0xEAFAF6EE.toInt(),
    glassMidArgb = 0xE2F3EDE1.toInt(),
    glassBottomArgb = 0xE6EAE1D2.toInt(),
    inkPrimaryArgb = 0xFF1E1C1A.toInt(),
    inkSecondaryArgb = 0xE0685F54.toInt(),
    accentArgb = 0xFFE04626.toInt(),
    rimHighlightArgb = 0xB8FFFFFF.toInt(),
    rimPrismaticArgb = 0x44F3D4C8,
    rimBounceArgb = 0x66FFFDF8,
    isDarkGlass = false,
    studioBackdropTop = Color(0xFF1C1917),
    studioBackdropBottom = Color(0xFF2C2623),
  ),
  MATCHA_PERSIMMON(
    id = "matcha_persimmon",
    displayName = "Matcha & Persimmon",
    subtitle = "Complementary Earth",
    glassTopArgb = 0xEAF2F6ED.toInt(),
    glassMidArgb = 0xE2E6ECE0.toInt(),
    glassBottomArgb = 0xE6DAE3D1.toInt(),
    inkPrimaryArgb = 0xFF1B362A.toInt(),
    inkSecondaryArgb = 0xE0496959.toInt(),
    accentArgb = 0xFFE35B2B.toInt(),
    rimHighlightArgb = 0xB8F9FFF6.toInt(),
    rimPrismaticArgb = 0x44B4DEC4,
    rimBounceArgb = 0x66EEF7EA,
    isDarkGlass = false,
    studioBackdropTop = Color(0xFF101D17),
    studioBackdropBottom = Color(0xFF1B3027),
  ),
  OBSIDIAN_AMBER(
    id = "obsidian_amber",
    displayName = "Obsidian & Amber",
    subtitle = "Monochrome + Gold",
    glassTopArgb = 0xEC1C1D21.toInt(),
    glassMidArgb = 0xE616171B.toInt(),
    glassBottomArgb = 0xEA111216.toInt(),
    inkPrimaryArgb = 0xFFF3F0EA.toInt(),
    inkSecondaryArgb = 0xDCA4A099.toInt(),
    accentArgb = 0xFFF29D16.toInt(),
    rimHighlightArgb = 0x6EF5EFE4,
    rimPrismaticArgb = 0x38F29D16,
    rimBounceArgb = 0x4898948D,
    isDarkGlass = true,
    studioBackdropTop = Color(0xFF0B0C0E),
    studioBackdropBottom = Color(0xFF1A1C21),
  ),
  MIDNIGHT_CORAL(
    id = "midnight_coral",
    displayName = "Midnight & Coral",
    subtitle = "Complementary Night",
    glassTopArgb = 0xEC141B2E.toInt(),
    glassMidArgb = 0xE60F1524.toInt(),
    glassBottomArgb = 0xEA0B101C.toInt(),
    inkPrimaryArgb = 0xFFEEF3FF.toInt(),
    inkSecondaryArgb = 0xDC96A8CE.toInt(),
    accentArgb = 0xFFFF6B57.toInt(),
    rimHighlightArgb = 0x6EDBE7FF,
    rimPrismaticArgb = 0x3896A8CE,
    rimBounceArgb = 0x486680B8,
    isDarkGlass = true,
    studioBackdropTop = Color(0xFF080C16),
    studioBackdropBottom = Color(0xFF131D33),
  ),
  SANDSTONE_ULTRAMARINE(
    id = "sandstone_ultramarine",
    displayName = "Linen & Ultramarine",
    subtitle = "Triadic Studio",
    glassTopArgb = 0xEAFBF6EE.toInt(),
    glassMidArgb = 0xE2F4EDE0.toInt(),
    glassBottomArgb = 0xE6EBE0CD.toInt(),
    inkPrimaryArgb = 0xFF1D44B8.toInt(),
    inkSecondaryArgb = 0xE07A593E.toInt(),
    accentArgb = 0xFFE08600.toInt(),
    rimHighlightArgb = 0xB8FFFDF8.toInt(),
    rimPrismaticArgb = 0x4493C5FD,
    rimBounceArgb = 0x66FFF4E2,
    isDarkGlass = false,
    studioBackdropTop = Color(0xFF111A33),
    studioBackdropBottom = Color(0xFF1D2C54),
  ),
  ESPRESSO_PISTACHIO(
    id = "espresso_pistachio",
    displayName = "Espresso & Pistachio",
    subtitle = "Botanical Analogous",
    glassTopArgb = 0xEC221B19.toInt(),
    glassMidArgb = 0xE61B1513.toInt(),
    glassBottomArgb = 0xEA140F0E.toInt(),
    inkPrimaryArgb = 0xFFC5E8A8.toInt(),
    inkSecondaryArgb = 0xDCC0AA9C.toInt(),
    accentArgb = 0xFFEE764B.toInt(),
    rimHighlightArgb = 0x6EF5EAD8,
    rimPrismaticArgb = 0x38C5E8A8,
    rimBounceArgb = 0x489A8274,
    isDarkGlass = true,
    studioBackdropTop = Color(0xFF120E0D),
    studioBackdropBottom = Color(0xFF261D1A),
  );

  companion object {
    fun fromId(id: String?): GlassThemeOption =
      entries.firstOrNull { it.id == id } ?: WARM_VERMILION
  }
}

enum class CrayonGlassBalance(
  val id: String,
  val displayName: String,
  val shortLabel: String,
  val subtitle: String,
  val crayonPercent: Int,
  val glassPercent: Int,
  val glassWeight: Float,
) {
  CRAYON_90_GLASS_10(
    id = "crayon_90_glass_10",
    displayName = "90% Crayon · 10% Glass",
    shortLabel = "90 / 10",
    subtitle = "Dense wax grain & matte paper",
    crayonPercent = 90,
    glassPercent = 10,
    glassWeight = 0f,
  ),
  CRAYON_80_GLASS_20(
    id = "crayon_80_glass_20",
    displayName = "80% Crayon · 20% Glass",
    shortLabel = "80 / 20",
    subtitle = "Crayon texture + frosted sheen",
    crayonPercent = 80,
    glassPercent = 20,
    glassWeight = 0.5f,
  ),
  CRAYON_70_GLASS_30(
    id = "crayon_70_glass_30",
    displayName = "70% Crayon · 30% Glass",
    shortLabel = "70 / 30",
    subtitle = "Silk wax + luminous glass",
    crayonPercent = 70,
    glassPercent = 30,
    glassWeight = 1f,
  );

  val isUltraCrayon: Boolean
    get() = this == CRAYON_90_GLASS_10

  companion object {
    fun fromId(id: String?): CrayonGlassBalance =
      entries.firstOrNull { it.id == id } ?: CRAYON_80_GLASS_20
  }
}

data class WidgetSettings(
  val font: CrayonFontOption = CrayonFontOption.FINGER_PAINT,
  val theme: GlassThemeOption = GlassThemeOption.WARM_VERMILION,
  val balance: CrayonGlassBalance = CrayonGlassBalance.CRAYON_80_GLASS_20,
  val page: Int = 0,
)
