package com.example.widget

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager
import android.os.Build
import android.provider.Settings
import android.telephony.SubscriptionManager
import android.telephony.TelephonyManager

enum class ToggleTileType(val extraKey: String) {
  WIFI("wifi"),
  MOBILE_DATA("mobile_data");

  companion object {
    fun fromKey(value: String?): ToggleTileType =
      entries.firstOrNull { it.extraKey == value } ?: WIFI
  }
}

object ConnectivityHelper {

  fun isWifiEnabled(context: Context): Boolean {
    val wifiManager = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
    if (wifiManager != null) {
      val state = runCatching { wifiManager.wifiState }.getOrDefault(WifiManager.WIFI_STATE_UNKNOWN)
      if (state == WifiManager.WIFI_STATE_ENABLED || state == WifiManager.WIFI_STATE_ENABLING) {
        return true
      }
      if (state == WifiManager.WIFI_STATE_DISABLED || state == WifiManager.WIFI_STATE_DISABLING) {
        return false
      }
      val enabled = runCatching { wifiManager.isWifiEnabled }.getOrNull()
      if (enabled != null) return enabled
    }

    val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
    val active = cm?.activeNetwork ?: return false
    val caps = cm.getNetworkCapabilities(active) ?: return false
    return caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)
  }

  fun isMobileDataEnabled(context: Context): Boolean {
    val defaultSubId = runCatching { SubscriptionManager.getDefaultDataSubscriptionId() }
      .getOrDefault(SubscriptionManager.INVALID_SUBSCRIPTION_ID)

    // 1. Authoritative TelephonyManager check on Android 8+ (handles dual-SIM & Quick Settings)
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
      val tm = context.getSystemService(Context.TELEPHONY_SERVICE) as? TelephonyManager
      if (tm != null) {
        val scopedTm = if (defaultSubId != SubscriptionManager.INVALID_SUBSCRIPTION_ID) {
          runCatching { tm.createForSubscriptionId(defaultSubId) }.getOrDefault(tm)
        } else {
          tm
        }
        val apiResult = runCatching { scopedTm.isDataEnabled }.getOrNull()
        if (apiResult != null) return apiResult
      }
    }

    // 2. Per-subscription Global setting (e.g. mobile_data1 / mobile_data2 on dual-SIM devices)
    if (defaultSubId != SubscriptionManager.INVALID_SUBSCRIPTION_ID) {
      val subSetting = runCatching {
        Settings.Global.getInt(context.contentResolver, "mobile_data$defaultSubId", -1)
      }.getOrDefault(-1)
      if (subSetting == 1) return true
      if (subSetting == 0) return false
    }

    // 3. Active cellular transport fallback + standard global setting
    val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
    val active = cm?.activeNetwork
    val caps = if (active != null) cm.getNetworkCapabilities(active) else null
    if (caps?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true) {
      return true
    }

    val globalSetting = runCatching {
      Settings.Global.getInt(context.contentResolver, "mobile_data", -1)
    }.getOrDefault(-1)
    return globalSetting == 1
  }

  fun canToggleWifiDirectly(): Boolean = Build.VERSION.SDK_INT < Build.VERSION_CODES.Q

  @Suppress("DEPRECATION")
  fun toggleWifiLegacy(context: Context): Boolean {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) return false
    val wifiManager = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
      ?: return false
    return runCatching {
      val targetState = !wifiManager.isWifiEnabled
      wifiManager.setWifiEnabled(targetState)
    }.getOrDefault(false)
  }
}
