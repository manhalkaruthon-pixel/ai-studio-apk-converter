package com.example.widget

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ComposePathEffect
import android.graphics.ComposeShader
import android.graphics.CornerPathEffect
import android.graphics.DiscretePathEffect
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import androidx.core.content.res.ResourcesCompat
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.random.Random

object CrayonWidgetRenderer {

  private val chunkyWaxGrainBitmap: Bitmap by lazy { buildWaxGrainBitmap(heavy = false) }
  private val denseWaxGrainBitmap: Bitmap by lazy { buildWaxGrainBitmap(heavy = true) }

  /**
   * Generates a coarse, visibly tactile 220x220 wax-crayon grain mask so wax streaks
   * and paper-tooth gaps remain clearly visible even when scaled down in previews.
   */
  private fun buildWaxGrainBitmap(heavy: Boolean): Bitmap {
    val size = 220
    val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
    val c = Canvas(bmp)
    val p = Paint(Paint.ANTI_ALIAS_FLAG)
    val rng = Random(if (heavy) 9011 else 4409)

    // Base wax coverage leaving room for bold paper-tooth voids
    c.drawColor(Color.argb(if (heavy) 215 else 170, 255, 255, 255))

    // Coarse diagonal wax-stick drag streaks & paper-tooth voids
    val streakCount = if (heavy) 480 else 650
    repeat(streakCount) {
      val x = rng.nextFloat() * size
      val y = rng.nextFloat() * size
      val len = rng.nextFloat() * 20f + 6f
      val dy = (rng.nextFloat() - 0.5f) * 6f
      val isVoid = rng.nextFloat() < (if (heavy) 0.32f else 0.46f)
      p.strokeWidth = rng.nextFloat() * 4.2f + 2.0f
      p.strokeCap = Paint.Cap.ROUND
      if (isVoid) {
        p.color = Color.argb(rng.nextInt(80, 175), 255, 255, 255)
        p.xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_OUT)
      } else {
        p.color = Color.argb(rng.nextInt(225, 255), 255, 255, 255)
        p.xfermode = null
      }
      c.drawLine(x, y, x + len, y + dy, p)
    }

    // Coarse wax stipple chunks
    p.xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_OUT)
    repeat(if (heavy) 240 else 360) {
      val cx = rng.nextFloat() * size
      val cy = rng.nextFloat() * size
      val r = rng.nextFloat() * 3.0f + 1.2f
      p.color = Color.argb(rng.nextInt(60, 145), 255, 255, 255)
      c.drawCircle(cx, cy, r, p)
    }

    return bmp
  }

  internal fun createWaxPaint(
    colorArgb: Int,
    heavy: Boolean,
    style: Paint.Style = Paint.Style.FILL,
    strokeWidth: Float = 0f,
    pathEffect: android.graphics.PathEffect? = null,
  ): Paint {
    val grainBmp = if (heavy) denseWaxGrainBitmap else chunkyWaxGrainBitmap
    val maskShader = BitmapShader(grainBmp, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT)
    val colorShader = LinearGradient(
      0f,
      0f,
      1f,
      1f,
      colorArgb,
      colorArgb,
      Shader.TileMode.CLAMP,
    )
    return Paint(Paint.ANTI_ALIAS_FLAG).apply {
      this.style = style
      this.strokeWidth = strokeWidth
      this.strokeCap = Paint.Cap.ROUND
      this.strokeJoin = Paint.Join.ROUND
      this.pathEffect = pathEffect
      this.shader = ComposeShader(colorShader, maskShader, PorterDuff.Mode.DST_IN)
    }
  }

  internal fun applyWaxGrainMask(target: Bitmap, heavy: Boolean = false) {
    val grainBmp = if (heavy) denseWaxGrainBitmap else chunkyWaxGrainBitmap
    val maskPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
      shader = BitmapShader(grainBmp, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT)
      xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN)
    }
    Canvas(target).drawRect(
      0f,
      0f,
      target.width.toFloat(),
      target.height.toFloat(),
      maskPaint,
    )
  }

  fun render(
    context: Context,
    settings: WidgetSettings,
    widthPx: Int = 720,
    heightPx: Int = 720,
    calendar: Calendar = Calendar.getInstance(),
  ): Bitmap {
    val safeW = widthPx.coerceIn(360, 1200)
    val safeH = heightPx.coerceIn(360, 1200)
    val bitmap = Bitmap.createBitmap(safeW, safeH, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(bitmap)

    val minDim = min(safeW, safeH).toFloat()
    val outerMargin = minDim * 0.032f
    val cardRect = RectF(
      outerMargin,
      outerMargin,
      safeW - outerMargin,
      safeH - outerMargin,
    )
    val cornerRadius = minDim * 0.165f

    drawCrayonGlassCardSurface(
      canvas = canvas,
      rect = cardRect,
      cornerRadius = cornerRadius,
      minDim = minDim,
      theme = settings.theme,
      balance = settings.balance,
    )

    val typeface = ResourcesCompat.getFont(context, settings.font.fontResId)
      ?: Typeface.DEFAULT_BOLD

    if (settings.page == 0) {
      drawPageOneHero(canvas, cardRect, minDim, typeface, settings, calendar)
    } else {
      drawPageTwoMonthGrid(canvas, cardRect, minDim, typeface, settings, calendar)
    }

    return bitmap
  }

  fun renderFontSpecimen(
    context: Context,
    fontOption: CrayonFontOption,
    inkArgb: Int,
    accentArgb: Int,
    sizePx: Int = 144,
  ): Bitmap {
    val bitmap = Bitmap.createBitmap(sizePx, sizePx, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(bitmap)
    val typeface = ResourcesCompat.getFont(context, fontOption.fontResId)
      ?: Typeface.DEFAULT_BOLD

    val textSize = sizePx * 0.58f * fontOption.heroScaleMultiplier
    drawCrayonText(
      canvas = canvas,
      text = "18",
      x = sizePx * 0.5f,
      yCenter = sizePx * 0.45f,
      textSize = textSize,
      typeface = typeface,
      colorArgb = inkArgb,
      align = Paint.Align.CENTER,
      minDim = sizePx.toFloat(),
      roughness = fontOption.waxRoughness,
      heavyGrain = false,
      accentSmudgeArgb = accentArgb,
    )

    drawCrayonUnderline(
      canvas = canvas,
      startX = sizePx * 0.18f,
      endX = sizePx * 0.82f,
      y = sizePx * 0.82f,
      strokeWidth = sizePx * 0.070f,
      color = accentArgb,
      minDim = sizePx.toFloat(),
    )

    return bitmap
  }

  fun renderToggleTile(
    context: Context,
    type: ToggleTileType,
    isEnabled: Boolean,
    settings: WidgetSettings,
    widthPx: Int = 440,
    heightPx: Int = 440,
  ): Bitmap {
    val safeW = widthPx.coerceIn(280, 960)
    val safeH = heightPx.coerceIn(280, 960)
    val bitmap = Bitmap.createBitmap(safeW, safeH, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(bitmap)

    val minDim = min(safeW, safeH).toFloat()
    val outerMargin = minDim * 0.045f
    val diameter = minDim - outerMargin * 2f
    val left = (safeW - diameter) / 2f
    val top = (safeH - diameter) / 2f
    val circleRect = RectF(left, top, left + diameter, top + diameter)
    val radius = diameter / 2f
    val theme = settings.theme
    val balance = settings.balance
    val isUltraCrayon = balance.isUltraCrayon
    val isBalancedGlass = balance == CrayonGlassBalance.CRAYON_70_GLASS_30

    drawCircularCrayonGlassSurface(
      canvas = canvas,
      rect = circleRect,
      minDim = minDim,
      theme = theme,
      balance = balance,
      isActive = isEnabled,
    )

    val centerX = circleRect.centerX()
    val centerY = circleRect.centerY()
    val iconCenterY = centerY - radius * 0.13f

    // Hand-scribbled wax highlight behind active icon
    if (isEnabled) {
      drawCrayonScribbleWash(
        canvas = canvas,
        cx = centerX,
        cy = iconCenterY,
        spanW = radius * 0.84f,
        spanH = radius * 0.58f,
        strokeWidth = (minDim * when (balance) {
          CrayonGlassBalance.CRAYON_90_GLASS_10 -> 0.055f
          CrayonGlassBalance.CRAYON_80_GLASS_20 -> 0.044f
          CrayonGlassBalance.CRAYON_70_GLASS_30 -> 0.036f
        }).coerceAtLeast(9f),
        colorArgb = withAlpha(
          theme.accentArgb,
          when (balance) {
            CrayonGlassBalance.CRAYON_90_GLASS_10 -> 72
            CrayonGlassBalance.CRAYON_80_GLASS_20 -> 48
            CrayonGlassBalance.CRAYON_70_GLASS_30 -> 34
          },
        ),
        minDim = minDim,
      )
    }

    val iconColor = if (isEnabled) theme.accentArgb else withAlpha(theme.inkSecondaryArgb, 130)
    val labelColor = if (isEnabled) theme.inkPrimaryArgb else withAlpha(theme.inkSecondaryArgb, 145)

    when (type) {
      ToggleTileType.WIFI -> drawCrayonWifiIcon(
        canvas = canvas,
        cx = centerX,
        cy = iconCenterY + radius * 0.15f,
        minDim = minDim,
        colorArgb = iconColor,
        isEnabled = isEnabled,
      )
      ToggleTileType.MOBILE_DATA -> drawCrayonDataArrowsIcon(
        canvas = canvas,
        cx = centerX,
        cy = iconCenterY,
        minDim = minDim,
        colorArgb = iconColor,
        isEnabled = isEnabled,
      )
    }

    val typeface = ResourcesCompat.getFont(context, settings.font.fontResId)
      ?: Typeface.DEFAULT_BOLD
    val label = if (type == ToggleTileType.WIFI) "Wi-Fi" else "Data"
    val roughnessBoost = when (balance) {
      CrayonGlassBalance.CRAYON_90_GLASS_10 -> 1.24f
      CrayonGlassBalance.CRAYON_80_GLASS_20 -> 0.90f
      CrayonGlassBalance.CRAYON_70_GLASS_30 -> 0.72f
    }
    drawCrayonText(
      canvas = canvas,
      text = label,
      x = centerX,
      yBaseline = centerY + radius * 0.49f,
      textSize = minDim * 0.138f,
      typeface = typeface,
      colorArgb = labelColor,
      align = Paint.Align.CENTER,
      minDim = minDim,
      roughness = settings.font.waxRoughness * roughnessBoost,
      heavyGrain = false,
      isBold = isEnabled,
    )

    val dotRadius = (minDim * 0.022f).coerceAtLeast(4f)
    val dotY = centerY + radius * 0.70f
    val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
      style = if (isEnabled) Paint.Style.FILL else Paint.Style.STROKE
      strokeWidth = (minDim * 0.010f).coerceAtLeast(2.2f)
      color = if (isEnabled) theme.accentArgb else withAlpha(theme.inkSecondaryArgb, 145)
    }
    canvas.drawCircle(centerX, dotY, dotRadius, dotPaint)

    return bitmap
  }

  /**
   * 2x1 Pill-Shaped Pedometer Widget (90/10 or 80/20 Crayon x Liquid Glass)
   */
  fun renderPedometerPill(
    context: Context,
    snapshot: PedometerSnapshot,
    settings: WidgetSettings,
    widthPx: Int = 840,
    heightPx: Int = 380,
  ): Bitmap {
    val safeW = widthPx.coerceIn(480, 1200)
    val safeH = heightPx.coerceIn(200, 600)
    val bitmap = Bitmap.createBitmap(safeW, safeH, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(bitmap)

    val minDim = min(safeW, safeH).toFloat()
    val outerMargin = minDim * 0.048f
    val pillRect = RectF(
      outerMargin,
      outerMargin,
      safeW - outerMargin,
      safeH - outerMargin,
    )
    val cornerRadius = pillRect.height() / 2f
    val theme = settings.theme
    val balance = settings.balance
    val isUltraCrayon = balance.isUltraCrayon
    val roughnessBoost = when (balance) {
      CrayonGlassBalance.CRAYON_90_GLASS_10 -> 1.25f
      CrayonGlassBalance.CRAYON_80_GLASS_20 -> 0.95f
      CrayonGlassBalance.CRAYON_70_GLASS_30 -> 0.76f
    }

    drawCrayonGlassCardSurface(
      canvas = canvas,
      rect = pillRect,
      cornerRadius = cornerRadius,
      minDim = minDim,
      theme = theme,
      balance = balance,
    )

    // Left circular crayon progress dial + footprints
    val badgeRadius = pillRect.height() * 0.34f
    val badgeCx = pillRect.left + pillRect.height() * 0.50f
    val badgeCy = pillRect.centerY()

    drawCrayonScribbleWash(
      canvas = canvas,
      cx = badgeCx,
      cy = badgeCy,
      spanW = badgeRadius * 1.45f,
      spanH = badgeRadius * 1.15f,
      strokeWidth = (minDim * when (balance) {
        CrayonGlassBalance.CRAYON_90_GLASS_10 -> 0.056f
        CrayonGlassBalance.CRAYON_80_GLASS_20 -> 0.044f
        CrayonGlassBalance.CRAYON_70_GLASS_30 -> 0.036f
      }).coerceAtLeast(8f),
      colorArgb = withAlpha(
        theme.accentArgb,
        when (balance) {
          CrayonGlassBalance.CRAYON_90_GLASS_10 -> 68
          CrayonGlassBalance.CRAYON_80_GLASS_20 -> 42
          CrayonGlassBalance.CRAYON_70_GLASS_30 -> 30
        },
      ),
      minDim = minDim,
    )

    // Track ring
    val trackStroke = (minDim * 0.022f).coerceAtLeast(4f)
    val trackPaint = createWaxPaint(
      colorArgb = withAlpha(theme.inkSecondaryArgb, 68),
      heavy = false,
      style = Paint.Style.STROKE,
      strokeWidth = trackStroke,
      pathEffect = ComposePathEffect(
        CornerPathEffect(minDim * 0.014f),
        DiscretePathEffect(minDim * 0.018f, minDim * 0.0042f),
      ),
    )
    canvas.drawCircle(badgeCx, badgeCy, badgeRadius, trackPaint)

    // Progress arc
    val sweepAngle = if (snapshot.hasPermission && snapshot.isSensorAvailable) {
      (snapshot.progressFraction * 360f).coerceIn(14f, 360f)
    } else {
      0f
    }
    if (sweepAngle > 0f) {
      val progressRect = RectF(
        badgeCx - badgeRadius,
        badgeCy - badgeRadius,
        badgeCx + badgeRadius,
        badgeCy + badgeRadius,
      )
      val arcPath = Path().apply {
        addArc(progressRect, -90f, sweepAngle)
      }
      val arcPaint = createWaxPaint(
        colorArgb = theme.accentArgb,
        heavy = false,
        style = Paint.Style.STROKE,
        strokeWidth = trackStroke * 1.28f,
        pathEffect = ComposePathEffect(
          CornerPathEffect(minDim * 0.016f),
          DiscretePathEffect(minDim * 0.016f, minDim * 0.0040f),
        ),
      )
      canvas.drawPath(arcPath, arcPaint)
    }

    drawCrayonFootprintsIcon(
      canvas = canvas,
      cx = badgeCx,
      cy = badgeCy,
      radius = badgeRadius * 0.56f,
      colorArgb = if (snapshot.hasPermission && snapshot.isSensorAvailable) {
        theme.accentArgb
      } else {
        withAlpha(theme.inkSecondaryArgb, 155)
      },
      minDim = minDim,
    )

    // Right-side typography inside the pill
    val typeface = ResourcesCompat.getFont(context, settings.font.fontResId)
      ?: Typeface.DEFAULT_BOLD
    val textLeft = badgeCx + badgeRadius + minDim * 0.13f
    val textRight = pillRect.right - pillRect.height() * 0.24f
    val maxTextW = (textRight - textLeft).coerceAtLeast(minDim * 0.6f)

    val mainValueText = when {
      !snapshot.hasPermission -> "Steps"
      !snapshot.isSensorAvailable -> "0"
      else -> NumberFormat.getIntegerInstance().format(snapshot.stepsToday)
    }

    // Subtle scribble highlight behind the step number
    drawCrayonScribbleWash(
      canvas = canvas,
      cx = textLeft + maxTextW * 0.36f,
      cy = pillRect.centerY() - minDim * 0.07f,
      spanW = maxTextW * 0.68f,
      spanH = minDim * 0.22f,
      strokeWidth = (minDim * when (balance) {
        CrayonGlassBalance.CRAYON_90_GLASS_10 -> 0.052f
        CrayonGlassBalance.CRAYON_80_GLASS_20 -> 0.040f
        CrayonGlassBalance.CRAYON_70_GLASS_30 -> 0.032f
      }).coerceAtLeast(8f),
      colorArgb = withAlpha(
        theme.accentArgb,
        when (balance) {
          CrayonGlassBalance.CRAYON_90_GLASS_10 -> 56
          CrayonGlassBalance.CRAYON_80_GLASS_20 -> 34
          CrayonGlassBalance.CRAYON_70_GLASS_30 -> 24
        },
      ),
      minDim = minDim,
    )

    val mainSize = fitTextSize(
      text = mainValueText,
      targetSize = minDim * 0.32f * settings.font.heroScaleMultiplier,
      maxWidth = maxTextW,
      typeface = typeface,
    )
    drawCrayonText(
      canvas = canvas,
      text = mainValueText,
      x = textLeft,
      yCenter = pillRect.centerY() - minDim * 0.095f,
      textSize = mainSize,
      typeface = typeface,
      colorArgb = theme.inkPrimaryArgb,
      align = Paint.Align.LEFT,
      minDim = minDim,
      roughness = settings.font.waxRoughness * roughnessBoost,
      heavyGrain = false,
      isBold = true,
      accentSmudgeArgb = theme.accentArgb,
    )

    val underlineY = pillRect.centerY() + minDim * 0.125f
    drawCrayonUnderline(
      canvas = canvas,
      startX = textLeft,
      endX = (textLeft + maxTextW * 0.62f).coerceAtMost(textRight),
      y = underlineY,
      strokeWidth = (minDim * 0.018f).coerceAtLeast(3f),
      color = theme.accentArgb,
      minDim = minDim,
      wobbleScale = 0.65f,
    )

    val subtitleText = when {
      !snapshot.hasPermission -> "TAP TO ALLOW"
      !snapshot.isSensorAvailable -> "NO SENSOR"
      else -> {
        val pct = (snapshot.progressFraction * 100f).roundToInt()
        val goalK = snapshot.dailyGoal / 1000
        "STEPS · $pct% OF ${goalK}K"
      }
    }
    val subtitleSize = fitTextSize(
      text = subtitleText,
      targetSize = minDim * 0.115f,
      maxWidth = maxTextW,
      typeface = typeface,
      letterSpacing = 0.06f,
    )
    drawCrayonText(
      canvas = canvas,
      text = subtitleText,
      x = textLeft,
      yBaseline = pillRect.centerY() + minDim * 0.275f,
      textSize = subtitleSize,
      typeface = typeface,
      colorArgb = theme.inkSecondaryArgb,
      align = Paint.Align.LEFT,
      minDim = minDim,
      roughness = settings.font.waxRoughness * roughnessBoost * 0.85f,
      heavyGrain = false,
      letterSpacing = 0.06f,
    )

    return bitmap
  }

  private fun drawCrayonFootprintsIcon(
    canvas: Canvas,
    cx: Float,
    cy: Float,
    radius: Float,
    colorArgb: Int,
    minDim: Float,
  ) {
    val fillPaint = createWaxPaint(
      colorArgb = withAlpha(colorArgb, 235),
      heavy = false,
      style = Paint.Style.FILL,
    )
    val outlinePaint = createWaxPaint(
      colorArgb = colorArgb,
      heavy = false,
      style = Paint.Style.STROKE,
      strokeWidth = (minDim * 0.012f).coerceAtLeast(2.2f),
      pathEffect = ComposePathEffect(
        CornerPathEffect(minDim * 0.010f),
        DiscretePathEffect(minDim * 0.012f, minDim * 0.003f),
      ),
    )

    // Left footprint (higher)
    canvas.save()
    canvas.translate(cx - radius * 0.34f, cy - radius * 0.14f)
    canvas.rotate(-12f)
    val leftSole = RectF(-radius * 0.24f, -radius * 0.42f, radius * 0.24f, radius * 0.18f)
    val leftHeel = RectF(-radius * 0.18f, radius * 0.25f, radius * 0.18f, radius * 0.56f)
    canvas.drawOval(leftSole, fillPaint)
    canvas.drawOval(leftSole, outlinePaint)
    canvas.drawOval(leftHeel, fillPaint)
    canvas.restore()

    // Right footprint (lower)
    canvas.save()
    canvas.translate(cx + radius * 0.34f, cy + radius * 0.16f)
    canvas.rotate(10f)
    val rightSole = RectF(-radius * 0.24f, -radius * 0.42f, radius * 0.24f, radius * 0.18f)
    val rightHeel = RectF(-radius * 0.18f, radius * 0.25f, radius * 0.18f, radius * 0.56f)
    canvas.drawOval(rightSole, fillPaint)
    canvas.drawOval(rightSole, outlinePaint)
    canvas.drawOval(rightHeel, fillPaint)
    canvas.restore()
  }

  private fun drawCrayonWifiIcon(
    canvas: Canvas,
    cx: Float,
    cy: Float,
    minDim: Float,
    colorArgb: Int,
    isEnabled: Boolean,
  ) {
    val strokeW = (minDim * 0.052f).coerceAtLeast(5f)
    val paint = createWaxPaint(
      colorArgb = colorArgb,
      heavy = false,
      style = Paint.Style.STROKE,
      strokeWidth = strokeW,
      pathEffect = ComposePathEffect(
        CornerPathEffect(minDim * 0.018f),
        DiscretePathEffect(minDim * 0.018f, minDim * 0.0065f),
      ),
    )

    val radii = floatArrayOf(minDim * 0.255f, minDim * 0.168f, minDim * 0.086f)
    for (r in radii) {
      val arcRect = RectF(cx - r, cy - r, cx + r, cy + r)
      val arcPath = Path().apply {
        addArc(arcRect, -138f, 96f)
      }
      canvas.drawPath(arcPath, paint)
    }

    val dotPaint = createWaxPaint(
      colorArgb = colorArgb,
      heavy = false,
      style = Paint.Style.FILL,
    )
    canvas.drawCircle(cx, cy + minDim * 0.016f, minDim * 0.030f, dotPaint)

    if (!isEnabled) {
      drawCrayonSlash(
        canvas = canvas,
        cx = cx,
        cy = cy - minDim * 0.08f,
        halfSpan = minDim * 0.20f,
        strokeWidth = strokeW * 0.95f,
        colorArgb = colorArgb,
        minDim = minDim,
      )
    }
  }

  private fun drawCrayonDataArrowsIcon(
    canvas: Canvas,
    cx: Float,
    cy: Float,
    minDim: Float,
    colorArgb: Int,
    isEnabled: Boolean,
  ) {
    val strokeW = (minDim * 0.050f).coerceAtLeast(5f)
    val paint = createWaxPaint(
      colorArgb = colorArgb,
      heavy = false,
      style = Paint.Style.STROKE,
      strokeWidth = strokeW,
      pathEffect = ComposePathEffect(
        CornerPathEffect(minDim * 0.016f),
        DiscretePathEffect(minDim * 0.018f, minDim * 0.0060f),
      ),
    )

    val offsetX = minDim * 0.088f
    val halfHeight = minDim * 0.148f
    val head = minDim * 0.072f

    val upPath = Path().apply {
      val lx = cx - offsetX
      moveTo(lx, cy + halfHeight)
      lineTo(lx, cy - halfHeight)
      moveTo(lx - head, cy - halfHeight + head)
      lineTo(lx, cy - halfHeight)
      lineTo(lx + head, cy - halfHeight + head)
    }
    canvas.drawPath(upPath, paint)

    val downPath = Path().apply {
      val rx = cx + offsetX
      moveTo(rx, cy - halfHeight)
      lineTo(rx, cy + halfHeight)
      moveTo(rx - head, cy + halfHeight - head)
      lineTo(rx, cy + halfHeight)
      lineTo(rx + head, cy + halfHeight - head)
    }
    canvas.drawPath(downPath, paint)

    if (!isEnabled) {
      drawCrayonSlash(
        canvas = canvas,
        cx = cx,
        cy = cy,
        halfSpan = minDim * 0.20f,
        strokeWidth = strokeW * 0.95f,
        colorArgb = colorArgb,
        minDim = minDim,
      )
    }
  }

  private fun drawCrayonSlash(
    canvas: Canvas,
    cx: Float,
    cy: Float,
    halfSpan: Float,
    strokeWidth: Float,
    colorArgb: Int,
    minDim: Float,
  ) {
    val slashPath = Path().apply {
      moveTo(cx - halfSpan, cy + halfSpan * 0.85f)
      lineTo(cx + halfSpan, cy - halfSpan * 0.85f)
    }
    val slashPaint = createWaxPaint(
      colorArgb = withAlpha(colorArgb, 240),
      heavy = false,
      style = Paint.Style.STROKE,
      strokeWidth = strokeWidth,
      pathEffect = ComposePathEffect(
        CornerPathEffect(minDim * 0.012f),
        DiscretePathEffect(minDim * 0.016f, minDim * 0.0052f),
      ),
    )
    canvas.drawPath(slashPath, slashPaint)
  }

  /**
   * Crayon Sketchbook Paper + Hand-Drawn Wax Frame / Frosted Liquid Glass Rim
   * Adapts dynamically between 90% Crayon / 10% Glass and 80% Crayon / 20% Glass.
   */
  internal fun drawCrayonGlassCardSurface(
    canvas: Canvas,
    rect: RectF,
    cornerRadius: Float,
    minDim: Float,
    theme: GlassThemeOption,
    balance: CrayonGlassBalance = CrayonGlassBalance.CRAYON_80_GLASS_20,
  ) {
    val isUltra = balance.isUltraCrayon
    val isGlass30 = balance == CrayonGlassBalance.CRAYON_70_GLASS_30
    val shadowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
      style = Paint.Style.FILL
      color = if (theme.isDarkGlass) 0x44000000 else 0x1E0A142E
    }
    val shadowRect = RectF(rect).apply { offset(0f, minDim * 0.011f) }
    canvas.drawRoundRect(shadowRect, cornerRadius, cornerRadius, shadowPaint)

    val topColor = when (balance) {
      CrayonGlassBalance.CRAYON_90_GLASS_10 -> withAlpha(theme.glassTopArgb, 245)
      CrayonGlassBalance.CRAYON_80_GLASS_20 -> theme.glassTopArgb
      CrayonGlassBalance.CRAYON_70_GLASS_30 -> withAlpha(theme.glassTopArgb, 206)
    }
    val midColor = when (balance) {
      CrayonGlassBalance.CRAYON_90_GLASS_10 -> withAlpha(theme.glassMidArgb, 242)
      CrayonGlassBalance.CRAYON_80_GLASS_20 -> theme.glassMidArgb
      CrayonGlassBalance.CRAYON_70_GLASS_30 -> withAlpha(theme.glassMidArgb, 198)
    }
    val botColor = when (balance) {
      CrayonGlassBalance.CRAYON_90_GLASS_10 -> withAlpha(theme.glassBottomArgb, 245)
      CrayonGlassBalance.CRAYON_80_GLASS_20 -> theme.glassBottomArgb
      CrayonGlassBalance.CRAYON_70_GLASS_30 -> withAlpha(theme.glassBottomArgb, 212)
    }

    val basePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
      style = Paint.Style.FILL
      shader = LinearGradient(
        rect.left,
        rect.top,
        rect.right,
        rect.bottom,
        intArrayOf(topColor, midColor, botColor),
        floatArrayOf(0f, 0.5f, 1f),
        Shader.TileMode.CLAMP,
      )
    }
    canvas.drawRoundRect(rect, cornerRadius, cornerRadius, basePaint)

    val cardPath = Path().apply {
      addRoundRect(rect, cornerRadius, cornerRadius, Path.Direction.CW)
    }
    canvas.save()
    canvas.clipPath(cardPath)

    // 10% vs 20% vs 30% Liquid Glass top-left specular sheen
    val sheenAlpha = when {
      isUltra && theme.isDarkGlass -> 0x09FFFFFF
      isUltra -> 0x12FFFFFF
      isGlass30 && theme.isDarkGlass -> 0x2AFFFFFF
      isGlass30 -> 0x42FFFFFF
      theme.isDarkGlass -> 0x16FFFFFF
      else -> 0x28FFFFFF
    }
    val sheenPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
      shader = RadialGradient(
        rect.left + rect.width() * 0.16f,
        rect.top + rect.height() * 0.12f,
        minDim * (if (isGlass30) 0.72f else 0.55f),
        intArrayOf(sheenAlpha, 0x00FFFFFF),
        floatArrayOf(0f, 1f),
        Shader.TileMode.CLAMP,
      )
    }
    canvas.drawRect(rect, sheenPaint)

    if (isGlass30) {
      val bouncePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        shader = LinearGradient(
          rect.left,
          rect.top,
          rect.right,
          rect.bottom,
          intArrayOf(0x00FFFFFF, if (theme.isDarkGlass) 0x16FFFFFF else 0x22FFFFFF, 0x00FFFFFF),
          floatArrayOf(0.18f, 0.48f, 0.78f),
          Shader.TileMode.CLAMP,
        )
      }
      canvas.drawRect(rect, bouncePaint)
    }

    // Sketchbook paper grain & diagonal wax hatching (strongest in 90/10, lighter in 70/30)
    val fiberPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
      style = Paint.Style.STROKE
      strokeWidth = (minDim * when (balance) {
        CrayonGlassBalance.CRAYON_90_GLASS_10 -> 0.0034f
        CrayonGlassBalance.CRAYON_80_GLASS_20 -> 0.0028f
        CrayonGlassBalance.CRAYON_70_GLASS_30 -> 0.0022f
      }).coerceAtLeast(1.3f)
      color = if (theme.isDarkGlass) Color.WHITE else theme.inkSecondaryArgb
    }
    val rng = Random(7719)
    val fiberCount = when (balance) {
      CrayonGlassBalance.CRAYON_90_GLASS_10 -> 320
      CrayonGlassBalance.CRAYON_80_GLASS_20 -> 180
      CrayonGlassBalance.CRAYON_70_GLASS_30 -> 105
    }
    repeat(fiberCount) {
      val sx = rect.left + rng.nextFloat() * rect.width()
      val sy = rect.top + rng.nextFloat() * rect.height()
      val len = minDim * (0.025f + rng.nextFloat() * 0.048f)
      fiberPaint.alpha = when (balance) {
        CrayonGlassBalance.CRAYON_90_GLASS_10 -> rng.nextInt(15, 34)
        CrayonGlassBalance.CRAYON_80_GLASS_20 -> rng.nextInt(8, 22)
        CrayonGlassBalance.CRAYON_70_GLASS_30 -> rng.nextInt(5, 15)
      }
      canvas.drawLine(sx, sy, sx + len, sy - len * 0.35f, fiberPaint)
    }

    canvas.restore()

    // 10% vs 20% vs 30% Liquid Glass crisp outer rim
    val rimTop = when (balance) {
      CrayonGlassBalance.CRAYON_90_GLASS_10 -> withAlpha(theme.rimHighlightArgb, 75)
      CrayonGlassBalance.CRAYON_80_GLASS_20 -> theme.rimHighlightArgb
      CrayonGlassBalance.CRAYON_70_GLASS_30 -> withAlpha(theme.rimHighlightArgb, 235)
    }
    val rimBot = when (balance) {
      CrayonGlassBalance.CRAYON_90_GLASS_10 -> withAlpha(theme.rimBounceArgb, 55)
      CrayonGlassBalance.CRAYON_80_GLASS_20 -> theme.rimBounceArgb
      CrayonGlassBalance.CRAYON_70_GLASS_30 -> withAlpha(theme.rimBounceArgb, 185)
    }
    val glassRimPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
      style = Paint.Style.STROKE
      strokeWidth = (minDim * when (balance) {
        CrayonGlassBalance.CRAYON_90_GLASS_10 -> 0.0036f
        CrayonGlassBalance.CRAYON_80_GLASS_20 -> 0.0055f
        CrayonGlassBalance.CRAYON_70_GLASS_30 -> 0.0080f
      }).coerceAtLeast(1.4f)
      shader = LinearGradient(
        rect.left,
        rect.top,
        rect.right,
        rect.bottom,
        intArrayOf(
          rimTop,
          when (balance) {
            CrayonGlassBalance.CRAYON_90_GLASS_10 -> 0x0CFFFFFF
            CrayonGlassBalance.CRAYON_80_GLASS_20 -> 0x18FFFFFF
            CrayonGlassBalance.CRAYON_70_GLASS_30 -> theme.rimPrismaticArgb
          },
          rimBot,
        ),
        floatArrayOf(0f, 0.5f, 1f),
        Shader.TileMode.CLAMP,
      )
    }
    canvas.drawRoundRect(rect, cornerRadius, cornerRadius, glassRimPaint)

    // Bold Crayon hand-drawn inner frame (heaviest in 90/10, sleekest in 70/30)
    val crayonInset = minDim * 0.028f
    val crayonFrameRect = RectF(rect).apply { inset(crayonInset, crayonInset) }
    val innerCorner = (cornerRadius - crayonInset).coerceAtLeast(8f)
    val framePathEffect = ComposePathEffect(
      CornerPathEffect(innerCorner * 0.85f),
      DiscretePathEffect(
        minDim * 0.020f,
        minDim * when (balance) {
          CrayonGlassBalance.CRAYON_90_GLASS_10 -> 0.0070f
          CrayonGlassBalance.CRAYON_80_GLASS_20 -> 0.0055f
          CrayonGlassBalance.CRAYON_70_GLASS_30 -> 0.0042f
        },
      ),
    )
    val primaryFramePaint = createWaxPaint(
      colorArgb = withAlpha(
        theme.inkSecondaryArgb,
        when (balance) {
          CrayonGlassBalance.CRAYON_90_GLASS_10 -> 205
          CrayonGlassBalance.CRAYON_80_GLASS_20 -> 165
          CrayonGlassBalance.CRAYON_70_GLASS_30 -> 132
        },
      ),
      heavy = false,
      style = Paint.Style.STROKE,
      strokeWidth = (minDim * when (balance) {
        CrayonGlassBalance.CRAYON_90_GLASS_10 -> 0.0170f
        CrayonGlassBalance.CRAYON_80_GLASS_20 -> 0.0125f
        CrayonGlassBalance.CRAYON_70_GLASS_30 -> 0.0095f
      }).coerceAtLeast(2.8f),
      pathEffect = framePathEffect,
    )
    canvas.drawRoundRect(crayonFrameRect, innerCorner, innerCorner, primaryFramePaint)

    // Second slightly shifted accent crayon border pass for hand-sketched character
    val accentFrameRect = RectF(crayonFrameRect).apply { inset(minDim * 0.0065f, minDim * 0.0065f) }
    val accentFramePaint = createWaxPaint(
      colorArgb = withAlpha(
        theme.accentArgb,
        when (balance) {
          CrayonGlassBalance.CRAYON_90_GLASS_10 -> 165
          CrayonGlassBalance.CRAYON_80_GLASS_20 -> 120
          CrayonGlassBalance.CRAYON_70_GLASS_30 -> 92
        },
      ),
      heavy = false,
      style = Paint.Style.STROKE,
      strokeWidth = (minDim * when (balance) {
        CrayonGlassBalance.CRAYON_90_GLASS_10 -> 0.0105f
        CrayonGlassBalance.CRAYON_80_GLASS_20 -> 0.0075f
        CrayonGlassBalance.CRAYON_70_GLASS_30 -> 0.0060f
      }).coerceAtLeast(2.0f),
      pathEffect = framePathEffect,
    )
    canvas.drawRoundRect(accentFrameRect, innerCorner, innerCorner, accentFramePaint)
  }

  /**
   * Circular Crayon Badge + 10% or 20% Frosted Glass Rim
   */
  internal fun drawCircularCrayonGlassSurface(
    canvas: Canvas,
    rect: RectF,
    minDim: Float,
    theme: GlassThemeOption,
    balance: CrayonGlassBalance,
    isActive: Boolean,
  ) {
    val isUltra = balance.isUltraCrayon
    val isGlass30 = balance == CrayonGlassBalance.CRAYON_70_GLASS_30
    val cx = rect.centerX()
    val cy = rect.centerY()
    val radius = rect.width() / 2f

    val shadowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
      style = Paint.Style.FILL
      color = if (theme.isDarkGlass) 0x44000000 else 0x1E0A142E
    }
    canvas.drawCircle(cx, cy + minDim * 0.012f, radius, shadowPaint)

    val topColor = when (balance) {
      CrayonGlassBalance.CRAYON_90_GLASS_10 -> withAlpha(theme.glassTopArgb, 245)
      CrayonGlassBalance.CRAYON_80_GLASS_20 -> theme.glassTopArgb
      CrayonGlassBalance.CRAYON_70_GLASS_30 -> withAlpha(theme.glassTopArgb, 206)
    }
    val midColor = when (balance) {
      CrayonGlassBalance.CRAYON_90_GLASS_10 -> withAlpha(theme.glassMidArgb, 242)
      CrayonGlassBalance.CRAYON_80_GLASS_20 -> theme.glassMidArgb
      CrayonGlassBalance.CRAYON_70_GLASS_30 -> withAlpha(theme.glassMidArgb, 198)
    }
    val botColor = when (balance) {
      CrayonGlassBalance.CRAYON_90_GLASS_10 -> withAlpha(theme.glassBottomArgb, 245)
      CrayonGlassBalance.CRAYON_80_GLASS_20 -> theme.glassBottomArgb
      CrayonGlassBalance.CRAYON_70_GLASS_30 -> withAlpha(theme.glassBottomArgb, 212)
    }

    val basePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
      style = Paint.Style.FILL
      shader = LinearGradient(
        rect.left,
        rect.top,
        rect.right,
        rect.bottom,
        intArrayOf(topColor, midColor, botColor),
        floatArrayOf(0f, 0.5f, 1f),
        Shader.TileMode.CLAMP,
      )
    }
    canvas.drawCircle(cx, cy, radius, basePaint)

    val circlePath = Path().apply {
      addOval(rect, Path.Direction.CW)
    }
    canvas.save()
    canvas.clipPath(circlePath)

    // 10% vs 20% vs 30% glass sheen
    val sheenAlpha = when {
      isUltra && theme.isDarkGlass -> 0x09FFFFFF
      isUltra -> 0x12FFFFFF
      isGlass30 && theme.isDarkGlass -> 0x2AFFFFFF
      isGlass30 -> 0x3EFFFFFF
      theme.isDarkGlass -> 0x16FFFFFF
      else -> 0x26FFFFFF
    }
    val sheenPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
      shader = RadialGradient(
        rect.left + rect.width() * 0.25f,
        rect.top + rect.height() * 0.20f,
        radius * (if (isGlass30) 1.15f else 0.95f),
        intArrayOf(sheenAlpha, 0x00FFFFFF),
        floatArrayOf(0f, 1f),
        Shader.TileMode.CLAMP,
      )
    }
    canvas.drawCircle(cx, cy, radius, sheenPaint)

    // Sketchbook paper hatching
    val fiberPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
      style = Paint.Style.STROKE
      strokeWidth = (minDim * when (balance) {
        CrayonGlassBalance.CRAYON_90_GLASS_10 -> 0.0038f
        CrayonGlassBalance.CRAYON_80_GLASS_20 -> 0.0032f
        CrayonGlassBalance.CRAYON_70_GLASS_30 -> 0.0024f
      }).coerceAtLeast(1.3f)
      color = if (theme.isDarkGlass) Color.WHITE else theme.inkSecondaryArgb
    }
    val rng = Random(5309)
    val circleFibers = when (balance) {
      CrayonGlassBalance.CRAYON_90_GLASS_10 -> 160
      CrayonGlassBalance.CRAYON_80_GLASS_20 -> 90
      CrayonGlassBalance.CRAYON_70_GLASS_30 -> 50
    }
    repeat(circleFibers) {
      val sx = rect.left + rng.nextFloat() * rect.width()
      val sy = rect.top + rng.nextFloat() * rect.height()
      val len = minDim * (0.03f + rng.nextFloat() * 0.05f)
      fiberPaint.alpha = when (balance) {
        CrayonGlassBalance.CRAYON_90_GLASS_10 -> rng.nextInt(16, 36)
        CrayonGlassBalance.CRAYON_80_GLASS_20 -> rng.nextInt(9, 24)
        CrayonGlassBalance.CRAYON_70_GLASS_30 -> rng.nextInt(5, 14)
      }
      canvas.drawLine(sx, sy, sx + len, sy - len * 0.35f, fiberPaint)
    }

    canvas.restore()

    // 10% vs 20% vs 30% glass outer rim
    val rimTop = when (balance) {
      CrayonGlassBalance.CRAYON_90_GLASS_10 -> withAlpha(theme.rimHighlightArgb, 75)
      CrayonGlassBalance.CRAYON_80_GLASS_20 -> theme.rimHighlightArgb
      CrayonGlassBalance.CRAYON_70_GLASS_30 -> withAlpha(theme.rimHighlightArgb, 235)
    }
    val rimBot = when (balance) {
      CrayonGlassBalance.CRAYON_90_GLASS_10 -> withAlpha(theme.rimBounceArgb, 55)
      CrayonGlassBalance.CRAYON_80_GLASS_20 -> theme.rimBounceArgb
      CrayonGlassBalance.CRAYON_70_GLASS_30 -> withAlpha(theme.rimBounceArgb, 185)
    }
    val glassRimPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
      style = Paint.Style.STROKE
      strokeWidth = (minDim * when (balance) {
        CrayonGlassBalance.CRAYON_90_GLASS_10 -> 0.0038f
        CrayonGlassBalance.CRAYON_80_GLASS_20 -> 0.0060f
        CrayonGlassBalance.CRAYON_70_GLASS_30 -> 0.0086f
      }).coerceAtLeast(1.4f)
      shader = LinearGradient(
        rect.left,
        rect.top,
        rect.right,
        rect.bottom,
        intArrayOf(
          rimTop,
          when (balance) {
            CrayonGlassBalance.CRAYON_90_GLASS_10 -> 0x0CFFFFFF
            CrayonGlassBalance.CRAYON_80_GLASS_20 -> 0x18FFFFFF
            CrayonGlassBalance.CRAYON_70_GLASS_30 -> theme.rimPrismaticArgb
          },
          rimBot,
        ),
        floatArrayOf(0f, 0.5f, 1f),
        Shader.TileMode.CLAMP,
      )
    }
    canvas.drawCircle(cx, cy, radius, glassRimPaint)

    // Bold Crayon circular ring inside badge
    val ringColor = if (isActive) {
      withAlpha(
        theme.accentArgb,
        when (balance) {
          CrayonGlassBalance.CRAYON_90_GLASS_10 -> 245
          CrayonGlassBalance.CRAYON_80_GLASS_20 -> 220
          CrayonGlassBalance.CRAYON_70_GLASS_30 -> 196
        },
      )
    } else {
      withAlpha(
        theme.inkSecondaryArgb,
        when (balance) {
          CrayonGlassBalance.CRAYON_90_GLASS_10 -> 145
          CrayonGlassBalance.CRAYON_80_GLASS_20 -> 115
          CrayonGlassBalance.CRAYON_70_GLASS_30 -> 96
        },
      )
    }
    drawCrayonCircle(
      canvas = canvas,
      cx = cx,
      cy = cy,
      radius = radius - minDim * 0.036f,
      strokeWidth = (minDim * when (balance) {
        CrayonGlassBalance.CRAYON_90_GLASS_10 -> 0.024f
        CrayonGlassBalance.CRAYON_80_GLASS_20 -> 0.018f
        CrayonGlassBalance.CRAYON_70_GLASS_30 -> 0.0145f
      }).coerceAtLeast(3.0f),
      color = ringColor,
      minDim = minDim,
    )
  }

  private fun drawPageOneHero(
    canvas: Canvas,
    rect: RectF,
    minDim: Float,
    typeface: Typeface,
    settings: WidgetSettings,
    calendar: Calendar,
  ) {
    val theme = settings.theme
    val balance = settings.balance
    val roughnessBoost = when (balance) {
      CrayonGlassBalance.CRAYON_90_GLASS_10 -> 1.25f
      CrayonGlassBalance.CRAYON_80_GLASS_20 -> 1.00f
      CrayonGlassBalance.CRAYON_70_GLASS_30 -> 0.78f
    }
    val centerX = rect.centerX()
    val maxTextWidth = rect.width() * 0.78f

    val monthName = SimpleDateFormat("MMM yyyy", Locale.getDefault())
      .format(calendar.time)
      .uppercase(Locale.getDefault())
    val dayNumber = calendar.get(Calendar.DAY_OF_MONTH).toString()
    val dayOfWeek = SimpleDateFormat("EEEE", Locale.getDefault()).format(calendar.time)

    val monthSize = fitTextSize(
      text = monthName,
      targetSize = minDim * 0.080f,
      maxWidth = maxTextWidth,
      typeface = typeface,
      letterSpacing = 0.09f,
    )
    drawCrayonText(
      canvas = canvas,
      text = monthName,
      x = centerX,
      yBaseline = rect.top + rect.height() * 0.21f,
      textSize = monthSize,
      typeface = typeface,
      colorArgb = theme.inkSecondaryArgb,
      align = Paint.Align.CENTER,
      minDim = minDim,
      roughness = settings.font.waxRoughness * roughnessBoost,
      heavyGrain = false,
      letterSpacing = 0.09f,
    )

    // Hand-scribbled pastel wax crayon highlight behind hero numeral
    drawCrayonScribbleWash(
      canvas = canvas,
      cx = centerX,
      cy = rect.top + rect.height() * 0.49f,
      spanW = minDim * 0.38f,
      spanH = minDim * 0.25f,
      strokeWidth = (minDim * when (balance) {
        CrayonGlassBalance.CRAYON_90_GLASS_10 -> 0.042f
        CrayonGlassBalance.CRAYON_80_GLASS_20 -> 0.034f
        CrayonGlassBalance.CRAYON_70_GLASS_30 -> 0.026f
      }).coerceAtLeast(9f),
      colorArgb = withAlpha(
        theme.accentArgb,
        when (balance) {
          CrayonGlassBalance.CRAYON_90_GLASS_10 -> 74
          CrayonGlassBalance.CRAYON_80_GLASS_20 -> 48
          CrayonGlassBalance.CRAYON_70_GLASS_30 -> 34
        },
      ),
      minDim = minDim,
    )

    val heroSize = minDim * 0.42f * settings.font.heroScaleMultiplier
    drawCrayonText(
      canvas = canvas,
      text = dayNumber,
      x = centerX,
      yCenter = rect.top + rect.height() * 0.485f,
      textSize = heroSize,
      typeface = typeface,
      colorArgb = theme.inkPrimaryArgb,
      align = Paint.Align.CENTER,
      minDim = minDim,
      roughness = settings.font.waxRoughness * roughnessBoost,
      heavyGrain = false,
      accentSmudgeArgb = theme.accentArgb,
    )

    val underlineY = rect.top + rect.height() * 0.715f
    val halfSpan = minDim * 0.20f
    drawCrayonUnderline(
      canvas = canvas,
      startX = centerX - halfSpan,
      endX = centerX + halfSpan,
      y = underlineY,
      strokeWidth = minDim * when (balance) {
        CrayonGlassBalance.CRAYON_90_GLASS_10 -> 0.029f
        CrayonGlassBalance.CRAYON_80_GLASS_20 -> 0.024f
        CrayonGlassBalance.CRAYON_70_GLASS_30 -> 0.020f
      },
      color = theme.accentArgb,
      minDim = minDim,
    )

    val daySize = fitTextSize(
      text = dayOfWeek,
      targetSize = minDim * 0.100f,
      maxWidth = maxTextWidth,
      typeface = typeface,
    )
    drawCrayonText(
      canvas = canvas,
      text = dayOfWeek,
      x = centerX,
      yBaseline = rect.top + rect.height() * 0.84f,
      textSize = daySize,
      typeface = typeface,
      colorArgb = theme.inkPrimaryArgb,
      align = Paint.Align.CENTER,
      minDim = minDim,
      roughness = settings.font.waxRoughness * roughnessBoost,
      heavyGrain = false,
    )

    drawPageDots(
      canvas = canvas,
      centerX = centerX,
      y = rect.bottom - rect.height() * 0.068f,
      activePage = 0,
      minDim = minDim,
      theme = theme,
    )
  }

  private fun drawPageTwoMonthGrid(
    canvas: Canvas,
    rect: RectF,
    minDim: Float,
    typeface: Typeface,
    settings: WidgetSettings,
    calendar: Calendar,
  ) {
    val theme = settings.theme
    val padX = rect.width() * 0.086f
    val padTop = rect.height() * 0.084f
    val contentLeft = rect.left + padX
    val contentRight = rect.right - padX
    val contentWidth = contentRight - contentLeft

    val monthTitle = SimpleDateFormat("MMMM", Locale.getDefault()).format(calendar.time)
    val yearTitle = SimpleDateFormat("yyyy", Locale.getDefault()).format(calendar.time)
    val headerY = rect.top + padTop + minDim * 0.066f

    val monthHeaderSize = fitTextSize(
      text = monthTitle,
      targetSize = minDim * 0.086f,
      maxWidth = contentWidth * 0.68f,
      typeface = typeface,
    )
    drawCrayonText(
      canvas = canvas,
      text = monthTitle,
      x = contentLeft,
      yBaseline = headerY,
      textSize = monthHeaderSize,
      typeface = typeface,
      colorArgb = theme.inkPrimaryArgb,
      align = Paint.Align.LEFT,
      minDim = minDim,
      roughness = settings.font.waxRoughness * 0.9f,
      heavyGrain = false,
    )

    drawCrayonText(
      canvas = canvas,
      text = yearTitle,
      x = contentRight,
      yBaseline = headerY,
      textSize = minDim * 0.064f,
      typeface = typeface,
      colorArgb = theme.inkSecondaryArgb,
      align = Paint.Align.RIGHT,
      minDim = minDim,
      roughness = settings.font.waxRoughness * 0.9f,
      heavyGrain = false,
    )

    val dividerY = headerY + minDim * 0.032f
    drawCrayonUnderline(
      canvas = canvas,
      startX = contentLeft,
      endX = contentRight,
      y = dividerY,
      strokeWidth = (minDim * 0.0085f).coerceAtLeast(2.6f),
      color = withAlpha(theme.accentArgb, 175),
      minDim = minDim,
      wobbleScale = 0.4f,
    )

    val weekdays = arrayOf("S", "M", "T", "W", "T", "F", "S")
    val colWidth = contentWidth / 7f
    val weekdayY = dividerY + minDim * 0.068f
    for (col in 0 until 7) {
      val cx = contentLeft + colWidth * (col + 0.5f)
      drawCrayonText(
        canvas = canvas,
        text = weekdays[col],
        x = cx,
        yBaseline = weekdayY,
        textSize = minDim * 0.052f,
        typeface = typeface,
        colorArgb = theme.inkSecondaryArgb,
        align = Paint.Align.CENTER,
        minDim = minDim,
        roughness = settings.font.waxRoughness * 0.7f,
        heavyGrain = true,
      )
    }

    val firstOfMonth = (calendar.clone() as Calendar).apply {
      set(Calendar.DAY_OF_MONTH, 1)
    }
    val startOffset = firstOfMonth.get(Calendar.DAY_OF_WEEK) - Calendar.SUNDAY
    val daysInMonth = calendar.getActualMaximum(Calendar.DAY_OF_MONTH)
    val todayDay = calendar.get(Calendar.DAY_OF_MONTH)
    val totalRows = ((startOffset + daysInMonth + 6) / 7).coerceIn(4, 6)

    val gridTop = weekdayY + minDim * 0.026f
    val gridBottom = rect.bottom - rect.height() * 0.105f
    val rowHeight = (gridBottom - gridTop) / totalRows
    val dayTextSize = min(colWidth * 0.52f, rowHeight * 0.58f)

    for (day in 1..daysInMonth) {
      val cellIndex = startOffset + (day - 1)
      val row = cellIndex / 7
      val col = cellIndex % 7

      val cx = contentLeft + colWidth * (col + 0.5f)
      val cy = gridTop + rowHeight * (row + 0.5f)
      val isToday = day == todayDay
      val isWeekend = (col == 0 || col == 6)

      if (isToday) {
        val circleRadius = min(colWidth, rowHeight) * 0.45f
        val fillPaint = createWaxPaint(
          colorArgb = withAlpha(theme.accentArgb, 58),
          heavy = false,
          style = Paint.Style.FILL,
        )
        canvas.drawCircle(cx, cy, circleRadius, fillPaint)

        drawCrayonCircle(
          canvas = canvas,
          cx = cx,
          cy = cy,
          radius = circleRadius,
          strokeWidth = (minDim * 0.012f).coerceAtLeast(3.0f),
          color = theme.accentArgb,
          minDim = minDim,
        )
      }

      val dayColor = when {
        isToday -> theme.accentArgb
        isWeekend -> theme.inkSecondaryArgb
        else -> theme.inkPrimaryArgb
      }

      drawCrayonText(
        canvas = canvas,
        text = day.toString(),
        x = cx,
        yCenter = cy,
        textSize = dayTextSize,
        typeface = typeface,
        colorArgb = dayColor,
        align = Paint.Align.CENTER,
        minDim = minDim,
        roughness = settings.font.waxRoughness * 0.6f,
        heavyGrain = true,
        isBold = isToday,
      )
    }

    drawPageDots(
      canvas = canvas,
      centerX = rect.centerX(),
      y = rect.bottom - rect.height() * 0.058f,
      activePage = 1,
      minDim = minDim,
      theme = theme,
    )
  }

  internal fun drawCrayonScribbleWash(
    canvas: Canvas,
    cx: Float,
    cy: Float,
    spanW: Float,
    spanH: Float,
    strokeWidth: Float,
    colorArgb: Int,
    minDim: Float,
  ) {
    val path = Path().apply {
      val left = cx - spanW * 0.5f
      val right = cx + spanW * 0.5f
      val top = cy - spanH * 0.5f
      val bottom = cy + spanH * 0.5f
      moveTo(left, top + spanH * 0.25f)
      lineTo(right - spanW * 0.1f, top)
      lineTo(left + spanW * 0.05f, cy)
      lineTo(right, cy - spanH * 0.12f)
      lineTo(left + spanW * 0.1f, bottom - spanH * 0.08f)
      lineTo(right - spanW * 0.05f, bottom)
    }
    val paint = createWaxPaint(
      colorArgb = colorArgb,
      heavy = false,
      style = Paint.Style.STROKE,
      strokeWidth = strokeWidth,
      pathEffect = ComposePathEffect(
        CornerPathEffect(minDim * 0.03f),
        DiscretePathEffect(minDim * 0.020f, minDim * 0.005f),
      ),
    )
    canvas.drawPath(path, paint)
  }

  private fun fitTextSize(
    text: String,
    targetSize: Float,
    maxWidth: Float,
    typeface: Typeface,
    letterSpacing: Float = 0f,
  ): Float {
    val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
      this.typeface = typeface
      this.textSize = targetSize
      this.letterSpacing = letterSpacing
    }
    val measured = paint.measureText(text)
    return if (measured > maxWidth && measured > 0f) {
      targetSize * (maxWidth / measured)
    } else {
      targetSize
    }
  }

  internal fun drawCrayonText(
    canvas: Canvas,
    text: String,
    x: Float,
    yBaseline: Float? = null,
    yCenter: Float? = null,
    textSize: Float,
    typeface: Typeface,
    colorArgb: Int,
    align: Paint.Align,
    minDim: Float,
    roughness: Float,
    heavyGrain: Boolean,
    letterSpacing: Float = 0f,
    isBold: Boolean = false,
    accentSmudgeArgb: Int? = null,
  ) {
    val measurePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
      this.typeface = typeface
      this.textSize = textSize
      this.letterSpacing = letterSpacing
      this.isFakeBoldText = isBold
    }

    val baselineY = when {
      yBaseline != null -> yBaseline
      yCenter != null -> {
        val fm = measurePaint.fontMetrics
        yCenter - (fm.ascent + fm.descent) / 2f
      }
      else -> 0f
    }

    val width = measurePaint.measureText(text)
    val startX = when (align) {
      Paint.Align.LEFT -> x
      Paint.Align.CENTER -> x - width / 2f
      Paint.Align.RIGHT -> x - width
    }

    val textPath = Path()
    measurePaint.getTextPath(text, 0, text.length, startX, baselineY, textPath)

    if (accentSmudgeArgb != null) {
      val smudgePaint = createWaxPaint(
        colorArgb = withAlpha(accentSmudgeArgb, 95),
        heavy = false,
        style = Paint.Style.FILL,
      )
      canvas.save()
      canvas.translate(minDim * 0.015f, minDim * 0.014f)
      canvas.drawPath(textPath, smudgePaint)
      canvas.restore()
    }

    val waxFillPaint = createWaxPaint(
      colorArgb = colorArgb,
      heavy = heavyGrain,
      style = Paint.Style.FILL,
    )
    canvas.drawPath(textPath, waxFillPaint)

    val edgeStrokeWidth = (textSize * 0.042f * roughness).coerceAtLeast(1.2f)
    val segLen = (textSize * 0.052f).coerceIn(2.6f, 11f)
    val deviation = (textSize * 0.018f * roughness).coerceIn(0.65f, 4.5f)
    val roughEdgePaint = createWaxPaint(
      colorArgb = withAlpha(colorArgb, 215),
      heavy = false,
      style = Paint.Style.STROKE,
      strokeWidth = edgeStrokeWidth,
      pathEffect = ComposePathEffect(
        CornerPathEffect(edgeStrokeWidth),
        DiscretePathEffect(segLen, deviation),
      ),
    )
    canvas.drawPath(textPath, roughEdgePaint)
  }

  private fun drawCrayonUnderline(
    canvas: Canvas,
    startX: Float,
    endX: Float,
    y: Float,
    strokeWidth: Float,
    color: Int,
    minDim: Float,
    wobbleScale: Float = 1f,
  ) {
    val path = Path().apply {
      val midX = (startX + endX) * 0.5f
      moveTo(startX, y + minDim * 0.005f * wobbleScale)
      quadTo(
        midX,
        y - minDim * 0.010f * wobbleScale,
        endX,
        y + minDim * 0.002f * wobbleScale,
      )
    }
    val paint = createWaxPaint(
      colorArgb = withAlpha(color, 245),
      heavy = false,
      style = Paint.Style.STROKE,
      strokeWidth = strokeWidth,
      pathEffect = ComposePathEffect(
        CornerPathEffect(minDim * 0.012f),
        DiscretePathEffect(minDim * 0.016f, minDim * 0.0042f * wobbleScale),
      ),
    )
    canvas.drawPath(path, paint)

    val secondPaint = createWaxPaint(
      colorArgb = withAlpha(color, 175),
      heavy = false,
      style = Paint.Style.STROKE,
      strokeWidth = strokeWidth * 0.72f,
      pathEffect = paint.pathEffect,
    )
    canvas.save()
    canvas.translate(0f, strokeWidth * 0.35f)
    canvas.drawPath(path, secondPaint)
    canvas.restore()
  }

  private fun drawCrayonCircle(
    canvas: Canvas,
    cx: Float,
    cy: Float,
    radius: Float,
    strokeWidth: Float,
    color: Int,
    minDim: Float,
  ) {
    val path = Path()
    val steps = 28
    for (i in 0..steps) {
      val t = (i.toFloat() / steps) * (Math.PI * 2.0)
      val rx = radius * (1.0 + 0.048 * cos(t * 2.0 + 0.6))
      val ry = radius * (1.0 + 0.040 * sin(t * 3.0 - 0.3))
      val px = (cx + rx * cos(t)).toFloat()
      val py = (cy + ry * sin(t)).toFloat()
      if (i == 0) path.moveTo(px, py) else path.lineTo(px, py)
    }
    path.close()

    val paint = createWaxPaint(
      colorArgb = withAlpha(color, 240),
      heavy = false,
      style = Paint.Style.STROKE,
      strokeWidth = strokeWidth,
      pathEffect = ComposePathEffect(
        CornerPathEffect(radius * 0.25f),
        DiscretePathEffect(minDim * 0.015f, minDim * 0.0036f),
      ),
    )
    canvas.drawPath(path, paint)

    val secondPaint = createWaxPaint(
      colorArgb = withAlpha(color, 160),
      heavy = false,
      style = Paint.Style.STROKE,
      strokeWidth = strokeWidth * 0.70f,
      pathEffect = paint.pathEffect,
    )
    canvas.save()
    canvas.rotate(14f, cx, cy)
    canvas.drawPath(path, secondPaint)
    canvas.restore()
  }

  private fun drawPageDots(
    canvas: Canvas,
    centerX: Float,
    y: Float,
    activePage: Int,
    minDim: Float,
    theme: GlassThemeOption,
  ) {
    val dotRadius = (minDim * 0.011f).coerceAtLeast(3.2f)
    val gap = dotRadius * 3.6f
    val activePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
      style = Paint.Style.FILL
      color = theme.accentArgb
    }
    val inactivePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
      style = Paint.Style.FILL
      color = withAlpha(theme.inkSecondaryArgb, 105)
    }

    canvas.drawCircle(
      centerX - gap * 0.5f,
      y,
      if (activePage == 0) dotRadius * 1.15f else dotRadius * 0.85f,
      if (activePage == 0) activePaint else inactivePaint,
    )
    canvas.drawCircle(
      centerX + gap * 0.5f,
      y,
      if (activePage == 1) dotRadius * 1.15f else dotRadius * 0.85f,
      if (activePage == 1) activePaint else inactivePaint,
    )
  }

  internal fun withAlpha(argb: Int, alpha: Int): Int =
    (argb and 0x00FFFFFF) or ((alpha.coerceIn(0, 255)) shl 24)
}
