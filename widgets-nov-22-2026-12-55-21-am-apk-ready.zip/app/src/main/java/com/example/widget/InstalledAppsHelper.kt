package com.example.widget

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.drawable.Drawable
import android.os.Build
import androidx.core.content.pm.ShortcutInfoCompat
import androidx.core.content.pm.ShortcutManagerCompat
import androidx.core.graphics.drawable.IconCompat
import com.example.R
import org.xmlpull.v1.XmlPullParser
import java.util.Locale

data class InstalledLaunchApp(
  val label: String,
  val packageName: String,
  val activityName: String,
)

object InstalledAppsHelper {
  private const val SHORTCUT_ID_PREFIX = "crayon_icon_"

  fun loadLaunchableApps(context: Context): List<InstalledLaunchApp> {
    val pm = context.packageManager
    val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    val resolveInfos = runCatching {
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        pm.queryIntentActivities(intent, PackageManager.ResolveInfoFlags.of(0L))
      } else {
        @Suppress("DEPRECATION")
        pm.queryIntentActivities(intent, 0)
      }
    }.getOrDefault(emptyList())

    val seen = HashSet<String>()
    return resolveInfos.mapNotNull { info ->
      val activityInfo = info.activityInfo ?: return@mapNotNull null
      val pkg = activityInfo.packageName ?: return@mapNotNull null
      val cls = activityInfo.name ?: return@mapNotNull null
      val key = "$pkg/$cls"
      if (!seen.add(key)) return@mapNotNull null
      val rawLabel = info.loadLabel(pm).toString().trim()
      val displayLabel = rawLabel.ifEmpty { pkg.substringAfterLast('.') }
      InstalledLaunchApp(
        label = displayLabel,
        packageName = pkg,
        activityName = cls,
      )
    }.sortedWith(
      compareBy<InstalledLaunchApp> { it.label.lowercase(Locale.getDefault()) }
        .thenBy { it.packageName },
    )
  }

  /**
   * Matches an installed app to a bespoke CrayonIconKind if available,
   * checking most-specific entries first (e.g. YT Studio & YT Music before YouTube).
   */
  fun matchBespokeIcon(app: InstalledLaunchApp): CrayonIconKind? {
    val pkg = app.packageName.lowercase(Locale.getDefault())
    val lbl = app.label.lowercase(Locale.getDefault())
    if (pkg == "com.google.android.googlequicksearchbox" || lbl == "google") {
      return CrayonIconKind.GOOGLE
    }
    for (kind in CrayonIconKind.entries) {
      if (kind.packageKeywords.any { kw ->
          lbl == kw || pkg.contains(kw) || lbl.contains(kw)
        }
      ) {
        return kind
      }
    }
    return null
  }

  fun findBestMatch(
    icon: CrayonIconKind,
    apps: List<InstalledLaunchApp>,
  ): InstalledLaunchApp? {
    if (apps.isEmpty()) return null
    val keywords = icon.packageKeywords
    for (keyword in keywords) {
      val exactLabel = apps.firstOrNull {
        it.label.equals(keyword, ignoreCase = true)
      }
      if (exactLabel != null) return exactLabel

      val pkgMatch = apps.firstOrNull {
        it.packageName.lowercase(Locale.getDefault()).contains(keyword)
      }
      if (pkgMatch != null) return pkgMatch

      val labelContains = apps.firstOrNull {
        it.label.lowercase(Locale.getDefault()).contains(keyword)
      }
      if (labelContains != null) return labelContains
    }
    return null
  }

  fun loadAppIconDrawable(context: Context, packageName: String): Drawable? =
    runCatching {
      context.packageManager.getApplicationIcon(packageName)
    }.getOrNull()

  fun isRequestPinShortcutSupported(context: Context): Boolean =
    runCatching {
      ShortcutManagerCompat.isRequestPinShortcutSupported(context)
    }.getOrDefault(false)

  fun pinAppIconShortcut(
    context: Context,
    app: InstalledLaunchApp,
    customLabel: String,
    iconBitmap: Bitmap,
    iconId: String,
  ): Boolean {
    if (!isRequestPinShortcutSupported(context)) return false
    val safeLabel = customLabel.trim().ifEmpty { app.label }.take(32)
    val launchIntent = Intent(Intent.ACTION_MAIN).apply {
      addCategory(Intent.CATEGORY_LAUNCHER)
      component = ComponentName(app.packageName, app.activityName)
      flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED
    }
    val shortcutId = "$SHORTCUT_ID_PREFIX${app.packageName}_$iconId"
    val shortcut = ShortcutInfoCompat.Builder(context, shortcutId)
      .setShortLabel(safeLabel)
      .setLongLabel(safeLabel)
      .setIcon(IconCompat.createWithBitmap(iconBitmap))
      .setIntent(launchIntent)
      .build()

    val pinned = runCatching {
      ShortcutManagerCompat.requestPinShortcut(context, shortcut, null)
    }.getOrDefault(false)

    if (pinned) {
      WidgetPreferences.savePinnedIcon(
        context = context,
        record = PinnedIconRecord(
          shortcutId = shortcutId,
          packageName = app.packageName,
          activityName = app.activityName,
          label = safeLabel,
          iconId = iconId,
        ),
      )
    }
    return pinned
  }

  fun getTrackedPinnedIcons(context: Context): List<PinnedIconRecord> {
    val merged = LinkedHashMap<String, PinnedIconRecord>()
    for (record in WidgetPreferences.getPinnedIcons(context)) {
      merged[record.shortcutId] = record
    }

    val systemPinned = runCatching {
      ShortcutManagerCompat.getShortcuts(context, ShortcutManagerCompat.FLAG_MATCH_PINNED)
    }.getOrDefault(emptyList())

    for (shortcut in systemPinned) {
      val id = shortcut.id
      if (!id.startsWith(SHORTCUT_ID_PREFIX)) continue
      if (merged.containsKey(id)) continue
      val component = shortcut.intent.component ?: continue
      val pkg = component.packageName
      val cls = component.className
      val prefix = "$SHORTCUT_ID_PREFIX${pkg}_"
      val iconId = if (id.startsWith(prefix)) id.removePrefix(prefix).ifEmpty { "auto" } else "auto"
      val label = shortcut.shortLabel.toString().trim().ifEmpty { pkg.substringAfterLast('.') }
      val record = PinnedIconRecord(
        shortcutId = id,
        packageName = pkg,
        activityName = cls,
        label = label,
        iconId = iconId,
      )
      merged[id] = record
      WidgetPreferences.savePinnedIcon(context, record)
    }

    return merged.values.toList()
  }

  /**
   * Re-renders every tracked pinned app shortcut in the active Shape/Theme/Balance
   * and pushes the updated bitmaps to the device launcher via ShortcutManagerCompat.updateShortcuts.
   */
  fun updatePinnedShortcutsStyle(
    context: Context,
    shape: CrayonIconShape,
    settings: WidgetSettings,
  ): Int {
    val records = getTrackedPinnedIcons(context)
    if (records.isEmpty()) return 0

    val updatedShortcuts = buildUpdatedShortcutList(context, records, shape, settings)
    if (updatedShortcuts.isEmpty()) return 0

    val updatedOk = runCatching {
      ShortcutManagerCompat.updateShortcuts(context, updatedShortcuts)
    }.getOrDefault(false)

    return if (updatedOk) updatedShortcuts.size else 0
  }

  internal fun buildUpdatedShortcutList(
    context: Context,
    records: List<PinnedIconRecord>,
    shape: CrayonIconShape,
    settings: WidgetSettings,
  ): List<ShortcutInfoCompat> = records.map { record ->
    val bespokeKind = if (record.iconId != "auto") {
      CrayonIconKind.entries.firstOrNull { it.id == record.iconId }
    } else {
      null
    }
    val launchApp = InstalledLaunchApp(
      label = record.label,
      packageName = record.packageName,
      activityName = record.activityName,
    )
    val iconBitmap = if (bespokeKind != null) {
      CrayonIconPackRenderer.renderIcon(
        kind = bespokeKind,
        shape = shape,
        settings = settings,
        sizePx = 256,
      )
    } else {
      CrayonIconPackRenderer.renderInstalledAppIcon(
        context = context,
        app = launchApp,
        shape = shape,
        settings = settings,
        sizePx = 256,
      )
    }
    val launchIntent = Intent(Intent.ACTION_MAIN).apply {
      addCategory(Intent.CATEGORY_LAUNCHER)
      component = ComponentName(record.packageName, record.activityName)
      flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED
    }
    ShortcutInfoCompat.Builder(context, record.shortcutId)
      .setShortLabel(record.label)
      .setLongLabel(record.label)
      .setIcon(IconCompat.createWithBitmap(iconBitmap))
      .setIntent(launchIntent)
      .build()
  }

  fun componentKey(app: InstalledLaunchApp): String =
    "${app.packageName}/${app.activityName}"

  fun loadAppfilterComponents(context: Context): Set<String> {
    val components = HashSet<String>()
    runCatching {
      val parser = context.resources.getXml(R.xml.appfilter)
      var event = parser.eventType
      while (event != XmlPullParser.END_DOCUMENT) {
        if (event == XmlPullParser.START_TAG && parser.name == "item") {
          val raw = parser.getAttributeValue(null, "component")
          if (!raw.isNullOrBlank()) {
            val cleaned = raw.removePrefix("ComponentInfo{").removeSuffix("}").trim()
            if (cleaned.contains('/')) {
              components.add(cleaned)
            }
          }
        }
        event = parser.next()
      }
    }
    return components
  }
}
