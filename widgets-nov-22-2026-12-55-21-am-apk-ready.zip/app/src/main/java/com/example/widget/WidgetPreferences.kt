package com.example.widget

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

data class PinnedIconRecord(
  val shortcutId: String,
  val packageName: String,
  val activityName: String,
  val label: String,
  val iconId: String,
)

object WidgetPreferences {
  private const val PREFS_NAME = "crayon_glass_widget_prefs"
  private const val KEY_DEFAULT_FONT = "default_font"
  private const val KEY_DEFAULT_THEME = "default_theme"
  private const val KEY_DEFAULT_BALANCE = "default_balance"
  private const val KEY_DEFAULT_ICON_SHAPE = "default_icon_shape"
  private const val KEY_PINNED_ICONS_JSON = "pinned_icons_json"
  private const val KEY_WIDGET_FONT_PREFIX = "widget_font_"
  private const val KEY_WIDGET_THEME_PREFIX = "widget_theme_"
  private const val KEY_WIDGET_BALANCE_PREFIX = "widget_balance_"
  private const val KEY_WIDGET_PAGE_PREFIX = "widget_page_"

  private fun prefs(context: Context): SharedPreferences =
    context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

  fun getDefaultFont(context: Context): CrayonFontOption =
    CrayonFontOption.fromId(prefs(context).getString(KEY_DEFAULT_FONT, null))

  fun getDefaultTheme(context: Context): GlassThemeOption =
    GlassThemeOption.fromId(prefs(context).getString(KEY_DEFAULT_THEME, null))

  fun getDefaultBalance(context: Context): CrayonGlassBalance =
    CrayonGlassBalance.fromId(prefs(context).getString(KEY_DEFAULT_BALANCE, null))

  fun getDefaultIconShape(context: Context): CrayonIconShape =
    CrayonIconShape.fromId(prefs(context).getString(KEY_DEFAULT_ICON_SHAPE, null))

  fun saveDefaultIconShape(context: Context, shape: CrayonIconShape) {
    prefs(context).edit()
      .putString(KEY_DEFAULT_ICON_SHAPE, shape.id)
      .apply()
  }

  fun getPinnedIcons(context: Context): List<PinnedIconRecord> {
    val raw = prefs(context).getString(KEY_PINNED_ICONS_JSON, null) ?: return emptyList()
    return runCatching {
      val array = JSONArray(raw)
      buildList(array.length()) {
        for (i in 0 until array.length()) {
          val obj = array.optJSONObject(i) ?: continue
          val shortcutId = obj.optString("shortcutId").trim()
          val packageName = obj.optString("packageName").trim()
          val activityName = obj.optString("activityName").trim()
          val label = obj.optString("label").trim()
          val iconId = obj.optString("iconId", "auto").trim().ifEmpty { "auto" }
          if (shortcutId.isNotEmpty() && packageName.isNotEmpty() && activityName.isNotEmpty()) {
            add(
              PinnedIconRecord(
                shortcutId = shortcutId,
                packageName = packageName,
                activityName = activityName,
                label = label.ifEmpty { packageName.substringAfterLast('.') },
                iconId = iconId,
              ),
            )
          }
        }
      }
    }.getOrDefault(emptyList())
  }

  fun savePinnedIcon(context: Context, record: PinnedIconRecord) {
    val updated = getPinnedIcons(context)
      .filterNot { it.shortcutId == record.shortcutId }
      .toMutableList()
      .apply { add(record) }
    saveAllPinnedIcons(context, updated)
  }

  private fun saveAllPinnedIcons(context: Context, records: List<PinnedIconRecord>) {
    val array = JSONArray()
    for (record in records) {
      val obj = JSONObject()
        .put("shortcutId", record.shortcutId)
        .put("packageName", record.packageName)
        .put("activityName", record.activityName)
        .put("label", record.label)
        .put("iconId", record.iconId)
      array.put(obj)
    }
    prefs(context).edit()
      .putString(KEY_PINNED_ICONS_JSON, array.toString())
      .apply()
  }

  fun saveDefaultStyle(
    context: Context,
    font: CrayonFontOption,
    theme: GlassThemeOption,
    balance: CrayonGlassBalance = CrayonGlassBalance.CRAYON_80_GLASS_20,
  ) {
    prefs(context).edit()
      .putString(KEY_DEFAULT_FONT, font.id)
      .putString(KEY_DEFAULT_THEME, theme.id)
      .putString(KEY_DEFAULT_BALANCE, balance.id)
      .apply()
  }

  fun getSettingsForWidget(context: Context, appWidgetId: Int): WidgetSettings {
    val p = prefs(context)
    val fontId = p.getString("$KEY_WIDGET_FONT_PREFIX$appWidgetId", null)
      ?: p.getString(KEY_DEFAULT_FONT, null)
    val themeId = p.getString("$KEY_WIDGET_THEME_PREFIX$appWidgetId", null)
      ?: p.getString(KEY_DEFAULT_THEME, null)
    val balanceId = p.getString("$KEY_WIDGET_BALANCE_PREFIX$appWidgetId", null)
      ?: p.getString(KEY_DEFAULT_BALANCE, null)
    val page = p.getInt("$KEY_WIDGET_PAGE_PREFIX$appWidgetId", 0).coerceIn(0, 1)
    return WidgetSettings(
      font = CrayonFontOption.fromId(fontId),
      theme = GlassThemeOption.fromId(themeId),
      balance = CrayonGlassBalance.fromId(balanceId),
      page = page,
    )
  }

  fun saveStyleForWidget(
    context: Context,
    appWidgetId: Int,
    font: CrayonFontOption,
    theme: GlassThemeOption,
    balance: CrayonGlassBalance = CrayonGlassBalance.CRAYON_80_GLASS_20,
  ) {
    prefs(context).edit()
      .putString("$KEY_WIDGET_FONT_PREFIX$appWidgetId", font.id)
      .putString("$KEY_WIDGET_THEME_PREFIX$appWidgetId", theme.id)
      .putString("$KEY_WIDGET_BALANCE_PREFIX$appWidgetId", balance.id)
      .putString(KEY_DEFAULT_FONT, font.id)
      .putString(KEY_DEFAULT_THEME, theme.id)
      .putString(KEY_DEFAULT_BALANCE, balance.id)
      .apply()
  }

  fun applyGlobalStyleToAllWidgets(
    context: Context,
    appWidgetIds: IntArray,
    font: CrayonFontOption,
    theme: GlassThemeOption,
    balance: CrayonGlassBalance = CrayonGlassBalance.CRAYON_80_GLASS_20,
  ) {
    val editor = prefs(context).edit()
      .putString(KEY_DEFAULT_FONT, font.id)
      .putString(KEY_DEFAULT_THEME, theme.id)
      .putString(KEY_DEFAULT_BALANCE, balance.id)
    for (id in appWidgetIds) {
      editor.putString("$KEY_WIDGET_FONT_PREFIX$id", font.id)
      editor.putString("$KEY_WIDGET_THEME_PREFIX$id", theme.id)
      editor.putString("$KEY_WIDGET_BALANCE_PREFIX$id", balance.id)
    }
    editor.apply()
  }

  fun togglePage(context: Context, appWidgetId: Int): Int {
    val p = prefs(context)
    val current = p.getInt("$KEY_WIDGET_PAGE_PREFIX$appWidgetId", 0)
    val next = if (current == 0) 1 else 0
    p.edit().putInt("$KEY_WIDGET_PAGE_PREFIX$appWidgetId", next).apply()
    return next
  }

  fun deleteWidget(context: Context, appWidgetId: Int) {
    prefs(context).edit()
      .remove("$KEY_WIDGET_FONT_PREFIX$appWidgetId")
      .remove("$KEY_WIDGET_THEME_PREFIX$appWidgetId")
      .remove("$KEY_WIDGET_BALANCE_PREFIX$appWidgetId")
      .remove("$KEY_WIDGET_PAGE_PREFIX$appWidgetId")
      .apply()
  }
}
