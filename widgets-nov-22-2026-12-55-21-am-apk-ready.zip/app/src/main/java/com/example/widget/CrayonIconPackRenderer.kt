package com.example.widget

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.ComposePathEffect
import android.graphics.CornerPathEffect
import android.graphics.DiscretePathEffect
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.AdaptiveIconDrawable
import android.graphics.drawable.Drawable
import android.os.Build
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

object CrayonIconPackRenderer {

  fun renderLauncherBackBitmap(
    theme: GlassThemeOption,
    balance: CrayonGlassBalance = CrayonGlassBalance.CRAYON_80_GLASS_20,
    sizePx: Int = 256,
  ): Bitmap {
    val safeSize = sizePx.coerceIn(128, 512)
    val bitmap = Bitmap.createBitmap(safeSize, safeSize, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(bitmap)
    val minDim = safeSize.toFloat()
    val outerMargin = minDim * 0.045f
    val cardRect = RectF(outerMargin, outerMargin, safeSize - outerMargin, safeSize - outerMargin)
    CrayonWidgetRenderer.drawCrayonGlassCardSurface(
      canvas = canvas,
      rect = cardRect,
      cornerRadius = cardRect.width() * 0.28f,
      minDim = minDim,
      theme = theme,
      balance = balance,
    )
    CrayonWidgetRenderer.drawCrayonScribbleWash(
      canvas = canvas,
      cx = cardRect.centerX(),
      cy = cardRect.centerY(),
      spanW = cardRect.width() * 0.48f,
      spanH = cardRect.height() * 0.36f,
      strokeWidth = (minDim * 0.036f).coerceAtLeast(5f),
      colorArgb = CrayonWidgetRenderer.withAlpha(theme.accentArgb, 28),
      minDim = minDim,
    )
    return bitmap
  }

  fun renderLauncherUponBitmap(
    theme: GlassThemeOption,
    sizePx: Int = 256,
  ): Bitmap {
    val safeSize = sizePx.coerceIn(128, 512)
    val bitmap = Bitmap.createBitmap(safeSize, safeSize, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(bitmap)
    val minDim = safeSize.toFloat()
    val outerMargin = minDim * 0.045f
    val cardRect = RectF(outerMargin, outerMargin, safeSize - outerMargin, safeSize - outerMargin)
    val cornerRadius = cardRect.width() * 0.28f

    val glazePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
      style = Paint.Style.FILL
      color = CrayonWidgetRenderer.withAlpha(
        if (theme.isDarkGlass) theme.glassTopArgb else theme.glassMidArgb,
        36,
      )
    }
    canvas.drawRoundRect(cardRect, cornerRadius, cornerRadius, glazePaint)

    val rimInset = minDim * 0.034f
    val innerRect = RectF(cardRect).apply { inset(rimInset, rimInset) }
    val rimPaint = CrayonWidgetRenderer.createWaxPaint(
      colorArgb = CrayonWidgetRenderer.withAlpha(theme.accentArgb, 130),
      heavy = false,
      style = Paint.Style.STROKE,
      strokeWidth = (minDim * 0.012f).coerceAtLeast(2.2f),
      pathEffect = ComposePathEffect(
        CornerPathEffect(cornerRadius * 0.7f),
        DiscretePathEffect(minDim * 0.022f, minDim * 0.0052f),
      ),
    )
    canvas.drawRoundRect(innerRect, cornerRadius * 0.85f, cornerRadius * 0.85f, rimPaint)
    return bitmap
  }

  fun renderIcon(
    kind: CrayonIconKind,
    shape: CrayonIconShape,
    settings: WidgetSettings,
    sizePx: Int = 256,
  ): Bitmap {
    val safeSize = sizePx.coerceIn(128, 512)
    val bitmap = Bitmap.createBitmap(safeSize, safeSize, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(bitmap)
    val minDim = safeSize.toFloat()
    val outerMargin = minDim * 0.045f
    val cardRect = RectF(
      outerMargin,
      outerMargin,
      safeSize - outerMargin,
      safeSize - outerMargin,
    )

    drawCardAndWash(canvas, cardRect, minDim, shape, settings)

    val theme = settings.theme
    val isUltra = settings.balance.isUltraCrayon
    val cx = cardRect.centerX()
    val cy = cardRect.centerY()
    val r = cardRect.width() * 0.26f

    val strokeWidth = (minDim * when (settings.balance) {
      CrayonGlassBalance.CRAYON_90_GLASS_10 -> 0.048f
      CrayonGlassBalance.CRAYON_80_GLASS_20 -> 0.042f
      CrayonGlassBalance.CRAYON_70_GLASS_30 -> 0.036f
    }).coerceAtLeast(4.2f)
    val wobbleEffect = ComposePathEffect(
      CornerPathEffect(minDim * 0.020f),
      DiscretePathEffect(
        minDim * 0.022f,
        minDim * when (settings.balance) {
          CrayonGlassBalance.CRAYON_90_GLASS_10 -> 0.0075f
          CrayonGlassBalance.CRAYON_80_GLASS_20 -> 0.0056f
          CrayonGlassBalance.CRAYON_70_GLASS_30 -> 0.0042f
        },
      ),
    )
    val inkStroke = CrayonWidgetRenderer.createWaxPaint(
      colorArgb = theme.inkPrimaryArgb,
      heavy = false,
      style = Paint.Style.STROKE,
      strokeWidth = strokeWidth,
      pathEffect = wobbleEffect,
    )
    val accentStroke = CrayonWidgetRenderer.createWaxPaint(
      colorArgb = theme.accentArgb,
      heavy = false,
      style = Paint.Style.STROKE,
      strokeWidth = strokeWidth * 0.96f,
      pathEffect = wobbleEffect,
    )
    val inkFill = CrayonWidgetRenderer.createWaxPaint(
      colorArgb = theme.inkPrimaryArgb,
      heavy = false,
      style = Paint.Style.FILL,
    )
    val accentFill = CrayonWidgetRenderer.createWaxPaint(
      colorArgb = CrayonWidgetRenderer.withAlpha(theme.accentArgb, 230),
      heavy = false,
      style = Paint.Style.FILL,
    )
    val accentWash = CrayonWidgetRenderer.createWaxPaint(
      colorArgb = CrayonWidgetRenderer.withAlpha(theme.accentArgb, 58),
      heavy = false,
      style = Paint.Style.FILL,
    )

    drawGlyph(
      canvas = canvas,
      kind = kind,
      cx = cx,
      cy = cy,
      r = r,
      minDim = minDim,
      settings = settings,
      inkStroke = inkStroke,
      accentStroke = accentStroke,
      inkFill = inkFill,
      accentFill = accentFill,
      accentWash = accentWash,
    )

    return bitmap
  }

  /**
   * Renders ANY installed app on the device in the active Crayon x Liquid Glass style:
   * uses our bespoke crayon glyph when matched, otherwise extracts an adaptive/duotone
   * wax-crayon stencil from the app's launcher icon (or falls back to a crayon monogram).
   */
  fun renderInstalledAppIcon(
    context: Context,
    app: InstalledLaunchApp,
    shape: CrayonIconShape,
    settings: WidgetSettings,
    sizePx: Int = 256,
  ): Bitmap {
    val matchedKind = InstalledAppsHelper.matchBespokeIcon(app)
    if (matchedKind != null) {
      return renderIcon(
        kind = matchedKind,
        shape = shape,
        settings = settings,
        sizePx = sizePx,
      )
    }

    val safeSize = sizePx.coerceIn(128, 512)
    val bitmap = Bitmap.createBitmap(safeSize, safeSize, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(bitmap)
    val minDim = safeSize.toFloat()
    val outerMargin = minDim * 0.045f
    val cardRect = RectF(
      outerMargin,
      outerMargin,
      safeSize - outerMargin,
      safeSize - outerMargin,
    )
    drawCardAndWash(canvas, cardRect, minDim, shape, settings)

    val drawable = InstalledAppsHelper.loadAppIconDrawable(context, app.packageName)
    val drewStencil = if (drawable != null) {
      drawAdaptiveCrayonStencil(canvas, drawable, cardRect, minDim, settings)
    } else {
      false
    }

    if (!drewStencil) {
      drawMonogramBadge(canvas, app.label, cardRect, minDim, settings)
    }

    return bitmap
  }

  private fun drawCardAndWash(
    canvas: Canvas,
    cardRect: RectF,
    minDim: Float,
    shape: CrayonIconShape,
    settings: WidgetSettings,
  ) {
    val theme = settings.theme
    val balance = settings.balance
    val isUltra = balance.isUltraCrayon

    when (shape) {
      CrayonIconShape.SQUIRCLE -> CrayonWidgetRenderer.drawCrayonGlassCardSurface(
        canvas = canvas,
        rect = cardRect,
        cornerRadius = cardRect.width() * 0.28f,
        minDim = minDim,
        theme = theme,
        balance = balance,
      )
      CrayonIconShape.CIRCLE -> CrayonWidgetRenderer.drawCircularCrayonGlassSurface(
        canvas = canvas,
        rect = cardRect,
        minDim = minDim,
        theme = theme,
        balance = balance,
        isActive = true,
      )
    }

    val r = cardRect.width() * 0.26f
    CrayonWidgetRenderer.drawCrayonScribbleWash(
      canvas = canvas,
      cx = cardRect.centerX(),
      cy = cardRect.centerY() + r * 0.06f,
      spanW = r * 1.65f,
      spanH = r * 1.15f,
      strokeWidth = (minDim * when (balance) {
        CrayonGlassBalance.CRAYON_90_GLASS_10 -> 0.048f
        CrayonGlassBalance.CRAYON_80_GLASS_20 -> 0.036f
        CrayonGlassBalance.CRAYON_70_GLASS_30 -> 0.028f
      }).coerceAtLeast(5.5f),
      colorArgb = CrayonWidgetRenderer.withAlpha(
        theme.accentArgb,
        when (balance) {
          CrayonGlassBalance.CRAYON_90_GLASS_10 -> 66
          CrayonGlassBalance.CRAYON_80_GLASS_20 -> 42
          CrayonGlassBalance.CRAYON_70_GLASS_30 -> 28
        },
      ),
      minDim = minDim,
    )
  }

  private fun drawAdaptiveCrayonStencil(
    canvas: Canvas,
    drawable: Drawable,
    cardRect: RectF,
    minDim: Float,
    settings: WidgetSettings,
  ): Boolean {
    val theme = settings.theme
    val sampleSize = 144
    val rawBitmap = Bitmap.createBitmap(sampleSize, sampleSize, Bitmap.Config.ARGB_8888)
    val rawCanvas = Canvas(rawBitmap)

    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && drawable is AdaptiveIconDrawable) {
      val fg = drawable.foreground
      if (fg != null) {
        fg.setBounds(
          -sampleSize / 5,
          -sampleSize / 5,
          sampleSize + sampleSize / 5,
          sampleSize + sampleSize / 5,
        )
        fg.draw(rawCanvas)
      } else {
        drawable.setBounds(0, 0, sampleSize, sampleSize)
        drawable.draw(rawCanvas)
      }
    } else {
      drawable.setBounds(0, 0, sampleSize, sampleSize)
      drawable.draw(rawCanvas)
    }

    val totalPixels = sampleSize * sampleSize
    val pixels = IntArray(totalPixels)
    rawBitmap.getPixels(pixels, 0, sampleSize, 0, 0, sampleSize, sampleSize)

    var opaqueCount = 0
    val bucketCounts = IntArray(4096)
    var bestBucket = 0
    var bestBucketCount = 0

    for (p in pixels) {
      val alpha = (p ushr 24) and 0xFF
      if (alpha > 48) {
        opaqueCount++
        val r4 = (p ushr 20) and 0xF
        val g4 = (p ushr 12) and 0xF
        val b4 = (p ushr 4) and 0xF
        val bucket = (r4 shl 8) or (g4 shl 4) or b4
        val count = ++bucketCounts[bucket]
        if (count > bestBucketCount) {
          bestBucketCount = count
          bestBucket = bucket
        }
      }
    }

    if (opaqueCount < 48) {
      rawBitmap.recycle()
      return false
    }

    val hasDominantBadgeBg = bestBucketCount > (opaqueCount * 0.44f)
    val bgR = ((bestBucket ushr 8) and 0xF) * 17
    val bgG = ((bestBucket ushr 4) and 0xF) * 17
    val bgB = (bestBucket and 0xF) * 17
    val bgLum = (0.299f * bgR + 0.587f * bgG + 0.114f * bgB) / 255f

    val stencilBitmap = Bitmap.createBitmap(sampleSize, sampleSize, Bitmap.Config.ARGB_8888)
    val outPixels = IntArray(totalPixels)
    var inkHits = 0

    for (y in 0 until sampleSize) {
      for (x in 0 until sampleSize) {
        val idx = y * sampleSize + x
        val c = pixels[idx]
        val alpha = (c ushr 24) and 0xFF
        if (alpha <= 48) {
          outPixels[idx] = 0
          continue
        }

        val r = (c ushr 16) and 0xFF
        val g = (c ushr 8) and 0xFF
        val b = c and 0xFF
        val lum = (0.299f * r + 0.587f * g + 0.114f * b) / 255f

        if (hasDominantBadgeBg) {
          val colorDist = abs(r - bgR) + abs(g - bgG) + abs(b - bgB)
          val lumDiff = abs(lum - bgLum)
          val isBoundary = if (x in 1 until (sampleSize - 1) && y in 1 until (sampleSize - 1)) {
            val leftAlpha = (pixels[idx - 1] ushr 24) and 0xFF
            val rightAlpha = (pixels[idx + 1] ushr 24) and 0xFF
            val topAlpha = (pixels[idx - sampleSize] ushr 24) and 0xFF
            val bottomAlpha = (pixels[idx + sampleSize] ushr 24) and 0xFF
            leftAlpha <= 48 || rightAlpha <= 48 || topAlpha <= 48 || bottomAlpha <= 48
          } else {
            false
          }

          when {
            // Distinct foreground letterform/symbol inside a colored badge -> crisp primary crayon ink
            colorDist > 78 || lumDiff > 0.18f -> {
              outPixels[idx] = CrayonWidgetRenderer.withAlpha(theme.inkPrimaryArgb, (alpha * 0.96f).toInt())
              inkHits++
            }
            // Outer silhouette border around a non-square colored badge -> accent crayon outline
            isBoundary && opaqueCount < totalPixels * 0.92f -> {
              outPixels[idx] = CrayonWidgetRenderer.withAlpha(theme.accentArgb, 235)
              inkHits++
            }
            // Dominant solid badge fill -> delicate pastel crayon wash (never raw default app color)
            opaqueCount < totalPixels * 0.92f -> {
              outPixels[idx] = CrayonWidgetRenderer.withAlpha(theme.accentArgb, 38)
            }
            else -> {
              outPixels[idx] = 0
            }
          }
        } else {
          // Transparent cutout / multicolor symbol -> strictly duotone theme ink + accent
          val maxCh = max(r, max(g, b))
          val minCh = kotlin.math.min(r, kotlin.math.min(g, b))
          val saturation = if (maxCh == 0) 0f else (maxCh - minCh).toFloat() / maxCh.toFloat()
          val useAccent = lum > 0.58f || (saturation > 0.55f && lum > 0.34f)
          val baseColor = if (useAccent) theme.accentArgb else theme.inkPrimaryArgb
          outPixels[idx] = CrayonWidgetRenderer.withAlpha(baseColor, (alpha * 0.95f).toInt())
          inkHits++
        }
      }
    }

    rawBitmap.recycle()

    if (inkHits < 36) {
      stencilBitmap.recycle()
      return false
    }

    stencilBitmap.setPixels(outPixels, 0, sampleSize, 0, 0, sampleSize, sampleSize)
    CrayonWidgetRenderer.applyWaxGrainMask(stencilBitmap, heavy = settings.balance.isUltraCrayon)

    val iconSpan = cardRect.width() * 0.58f
    val dest = RectF(
      cardRect.centerX() - iconSpan * 0.5f,
      cardRect.centerY() - iconSpan * 0.5f,
      cardRect.centerX() + iconSpan * 0.5f,
      cardRect.centerY() + iconSpan * 0.5f,
    )
    val stencilPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    canvas.drawBitmap(stencilBitmap, null, dest, stencilPaint)
    stencilBitmap.recycle()

    // Subtle crayon contour dot inside card corner to unify auto-themed icons with bespoke art
    val cornerMarker = Paint(Paint.ANTI_ALIAS_FLAG).apply {
      style = Paint.Style.FILL
      color = CrayonWidgetRenderer.withAlpha(theme.accentArgb, 225)
    }
    canvas.drawCircle(
      cardRect.right - cardRect.width() * 0.18f,
      cardRect.bottom - cardRect.height() * 0.18f,
      (minDim * 0.022f).coerceAtLeast(3.5f),
      cornerMarker,
    )
    return true
  }

  private fun drawMonogramBadge(
    canvas: Canvas,
    label: String,
    cardRect: RectF,
    minDim: Float,
    settings: WidgetSettings,
  ) {
    val words = label.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
    val monogram = when {
      words.size >= 2 -> "${words[0].first().uppercaseChar()}${words[1].first().uppercaseChar()}"
      words.size == 1 && words[0].length >= 2 -> words[0].take(2).uppercase()
      words.size == 1 -> words[0].first().uppercaseChar().toString()
      else -> "A"
    }
    val cx = cardRect.centerX()
    val cy = cardRect.centerY()
    val r = cardRect.width() * 0.25f

    val ringPaint = CrayonWidgetRenderer.createWaxPaint(
      colorArgb = CrayonWidgetRenderer.withAlpha(settings.theme.accentArgb, 210),
      heavy = false,
      style = Paint.Style.STROKE,
      strokeWidth = (minDim * 0.036f).coerceAtLeast(3.5f),
      pathEffect = ComposePathEffect(
        CornerPathEffect(minDim * 0.02f),
        DiscretePathEffect(minDim * 0.018f, minDim * 0.005f),
      ),
    )
    canvas.drawRoundRect(
      RectF(cx - r, cy - r, cx + r, cy + r),
      r * 0.42f,
      r * 0.42f,
      ringPaint,
    )

    CrayonWidgetRenderer.drawCrayonText(
      canvas = canvas,
      text = monogram,
      x = cx,
      yCenter = cy,
      textSize = minDim * (if (monogram.length == 2) 0.24f else 0.30f),
      typeface = Typeface.DEFAULT_BOLD,
      colorArgb = settings.theme.inkPrimaryArgb,
      align = Paint.Align.CENTER,
      minDim = minDim,
      roughness = settings.font.waxRoughness,
      heavyGrain = false,
      isBold = true,
      accentSmudgeArgb = settings.theme.accentArgb,
    )
  }

  private fun drawGlyph(
    canvas: Canvas,
    kind: CrayonIconKind,
    cx: Float,
    cy: Float,
    r: Float,
    minDim: Float,
    settings: WidgetSettings,
    inkStroke: Paint,
    accentStroke: Paint,
    inkFill: Paint,
    accentFill: Paint,
    accentWash: Paint,
  ) {
    when (kind) {
      CrayonIconKind.LINKEDIN -> {
        val box = RectF(cx - r * 0.84f, cy - r * 0.84f, cx + r * 0.84f, cy + r * 0.84f)
        canvas.drawRoundRect(box, r * 0.24f, r * 0.24f, accentWash)
        canvas.drawRoundRect(box, r * 0.24f, r * 0.24f, accentStroke)
        CrayonWidgetRenderer.drawCrayonText(
          canvas = canvas,
          text = "in",
          x = cx,
          yCenter = cy + r * 0.04f,
          textSize = minDim * 0.27f,
          typeface = Typeface.DEFAULT_BOLD,
          colorArgb = settings.theme.inkPrimaryArgb,
          align = Paint.Align.CENTER,
          minDim = minDim,
          roughness = 0.85f,
          heavyGrain = false,
          isBold = true,
        )
      }

      CrayonIconKind.GEMINI -> {
        val star = Path().apply {
          moveTo(cx, cy - r * 0.90f)
          quadTo(cx + r * 0.14f, cy - r * 0.14f, cx + r * 0.90f, cy)
          quadTo(cx + r * 0.14f, cy + r * 0.14f, cx, cy + r * 0.90f)
          quadTo(cx - r * 0.14f, cy + r * 0.14f, cx - r * 0.90f, cy)
          quadTo(cx - r * 0.14f, cy - r * 0.14f, cx, cy - r * 0.90f)
          close()
        }
        canvas.drawPath(star, accentWash)
        canvas.drawPath(star, accentStroke)
        canvas.drawCircle(cx + r * 0.62f, cy - r * 0.62f, r * 0.12f, inkFill)
      }

      CrayonIconKind.YT_STUDIO -> {
        val hex = Path()
        for (i in 0 until 6) {
          val angle = Math.toRadians((60 * i - 90).toDouble())
          val px = (cx + cos(angle) * r * 0.88f).toFloat()
          val py = (cy + sin(angle) * r * 0.88f).toFloat()
          if (i == 0) hex.moveTo(px, py) else hex.lineTo(px, py)
        }
        hex.close()
        canvas.drawPath(hex, accentWash)
        canvas.drawPath(hex, inkStroke)
        val innerHex = Path()
        for (i in 0 until 6) {
          val angle = Math.toRadians((60 * i - 90).toDouble())
          val px = (cx + cos(angle) * r * 0.56f).toFloat()
          val py = (cy + sin(angle) * r * 0.56f).toFloat()
          if (i == 0) innerHex.moveTo(px, py) else innerHex.lineTo(px, py)
        }
        innerHex.close()
        canvas.drawPath(innerHex, accentStroke)
        val play = Path().apply {
          moveTo(cx - r * 0.16f, cy - r * 0.24f)
          lineTo(cx + r * 0.28f, cy)
          lineTo(cx - r * 0.16f, cy + r * 0.24f)
          close()
        }
        canvas.drawPath(play, accentFill)
      }

      CrayonIconKind.TEAMS -> {
        val card = RectF(cx - r * 0.78f, cy - r * 0.56f, cx + r * 0.36f, cy + r * 0.66f)
        canvas.drawRoundRect(card, r * 0.20f, r * 0.20f, accentWash)
        canvas.drawRoundRect(card, r * 0.20f, r * 0.20f, inkStroke)
        canvas.drawCircle(cx + r * 0.58f, cy - r * 0.42f, r * 0.24f, accentStroke)
        val person = Path().apply {
          addArc(RectF(cx + r * 0.28f, cy - r * 0.06f, cx + r * 0.88f, cy + r * 0.62f), 190f, 160f)
        }
        canvas.drawPath(person, accentStroke)
        CrayonWidgetRenderer.drawCrayonText(
          canvas = canvas,
          text = "T",
          x = card.centerX(),
          yCenter = card.centerY() + r * 0.04f,
          textSize = minDim * 0.22f,
          typeface = Typeface.DEFAULT_BOLD,
          colorArgb = settings.theme.inkPrimaryArgb,
          align = Paint.Align.CENTER,
          minDim = minDim,
          roughness = 0.8f,
          heavyGrain = false,
          isBold = true,
        )
      }

      CrayonIconKind.OUTLOOK -> {
        val env = RectF(cx - r * 0.34f, cy - r * 0.62f, cx + r * 0.88f, cy + r * 0.56f)
        canvas.drawRoundRect(env, r * 0.16f, r * 0.16f, inkStroke)
        canvas.drawLine(env.left, env.top + r * 0.10f, env.centerX(), env.centerY(), accentStroke)
        canvas.drawLine(env.right, env.top + r * 0.10f, env.centerX(), env.centerY(), accentStroke)
        val tile = RectF(cx - r * 0.90f, cy - r * 0.46f, cx + r * 0.06f, cy + r * 0.60f)
        canvas.drawRoundRect(tile, r * 0.18f, r * 0.18f, accentWash)
        canvas.drawRoundRect(tile, r * 0.18f, r * 0.18f, accentStroke)
        canvas.drawCircle(tile.centerX(), tile.centerY(), r * 0.24f, inkStroke)
      }

      CrayonIconKind.EXCEL -> {
        val sheet = RectF(cx - r * 0.28f, cy - r * 0.72f, cx + r * 0.86f, cy + r * 0.72f)
        canvas.drawRoundRect(sheet, r * 0.16f, r * 0.16f, inkStroke)
        canvas.drawLine(sheet.left + r * 0.30f, sheet.centerY(), sheet.right - r * 0.12f, sheet.centerY(), inkStroke)
        canvas.drawLine(sheet.centerX() + r * 0.10f, sheet.top + r * 0.14f, sheet.centerX() + r * 0.10f, sheet.bottom - r * 0.14f, inkStroke)
        val tile = RectF(cx - r * 0.88f, cy - r * 0.48f, cx + r * 0.10f, cy + r * 0.50f)
        canvas.drawRoundRect(tile, r * 0.18f, r * 0.18f, accentWash)
        canvas.drawRoundRect(tile, r * 0.18f, r * 0.18f, accentStroke)
        canvas.drawLine(tile.left + r * 0.22f, tile.top + r * 0.22f, tile.right - r * 0.22f, tile.bottom - r * 0.22f, inkStroke)
        canvas.drawLine(tile.right - r * 0.22f, tile.top + r * 0.22f, tile.left + r * 0.22f, tile.bottom - r * 0.22f, inkStroke)
      }

      CrayonIconKind.ZOOM -> {
        val badge = RectF(cx - r * 0.86f, cy - r * 0.72f, cx + r * 0.86f, cy + r * 0.72f)
        canvas.drawRoundRect(badge, r * 0.34f, r * 0.34f, accentWash)
        canvas.drawRoundRect(badge, r * 0.34f, r * 0.34f, accentStroke)
        val camBody = RectF(cx - r * 0.56f, cy - r * 0.30f, cx + r * 0.14f, cy + r * 0.30f)
        canvas.drawRoundRect(camBody, r * 0.14f, r * 0.14f, inkStroke)
        val lens = Path().apply {
          moveTo(cx + r * 0.18f, cy - r * 0.08f)
          lineTo(cx + r * 0.58f, cy - r * 0.30f)
          lineTo(cx + r * 0.58f, cy + r * 0.30f)
          lineTo(cx + r * 0.18f, cy + r * 0.08f)
          close()
        }
        canvas.drawPath(lens, accentFill)
        canvas.drawPath(lens, inkStroke)
      }

      CrayonIconKind.GOOGLE -> {
        canvas.drawCircle(cx, cy, r * 0.82f, accentWash)
        val gArc = Path().apply {
          addArc(RectF(cx - r * 0.76f, cy - r * 0.76f, cx + r * 0.76f, cy + r * 0.76f), -35f, -295f)
        }
        canvas.drawPath(gArc, inkStroke)
        canvas.drawLine(cx + r * 0.04f, cy + r * 0.04f, cx + r * 0.76f, cy + r * 0.04f, accentStroke)
        canvas.drawLine(cx + r * 0.74f, cy + r * 0.04f, cx + r * 0.62f, cy + r * 0.44f, accentStroke)
      }

      CrayonIconKind.CLAUDE -> {
        canvas.drawCircle(cx, cy, r * 0.40f, accentWash)
        val rays = 10
        for (i in 0 until rays) {
          val angle = Math.toRadians((i * (360.0 / rays)).toDouble())
          val inner = if (i % 2 == 0) r * 0.22f else r * 0.32f
          val outer = if (i % 2 == 0) r * 0.86f else r * 0.72f
          canvas.drawLine(
            (cx + cos(angle) * inner).toFloat(),
            (cy + sin(angle) * inner).toFloat(),
            (cx + cos(angle) * outer).toFloat(),
            (cy + sin(angle) * outer).toFloat(),
            if (i % 2 == 0) accentStroke else inkStroke,
          )
        }
      }

      CrayonIconKind.CHATGPT -> {
        canvas.drawCircle(cx, cy, r * 0.58f, accentWash)
        val petals = 6
        for (i in 0 until petals) {
          val angle = Math.toRadians((i * 60).toDouble())
          val px = (cx + cos(angle) * r * 0.36f).toFloat()
          val py = (cy + sin(angle) * r * 0.36f).toFloat()
          canvas.drawCircle(px, py, r * 0.36f, if (i % 2 == 0) inkStroke else accentStroke)
        }
        canvas.drawCircle(cx, cy, r * 0.16f, accentFill)
      }

      CrayonIconKind.DEEPSEEK -> {
        val whale = Path().apply {
          moveTo(cx - r * 0.80f, cy + r * 0.22f)
          quadTo(cx - r * 0.30f, cy - r * 0.80f, cx + r * 0.48f, cy - r * 0.38f)
          quadTo(cx + r * 0.86f, cy - r * 0.10f, cx + r * 0.76f, cy + r * 0.44f)
          quadTo(cx, cy + r * 0.76f, cx - r * 0.80f, cy + r * 0.22f)
          close()
        }
        canvas.drawPath(whale, accentWash)
        canvas.drawPath(whale, inkStroke)
        val fin = Path().apply {
          moveTo(cx - r * 0.10f, cy - r * 0.38f)
          quadTo(cx + r * 0.08f, cy - r * 0.88f, cx + r * 0.36f, cy - r * 0.58f)
        }
        canvas.drawPath(fin, accentStroke)
        canvas.drawCircle(cx + r * 0.30f, cy - r * 0.04f, r * 0.11f, accentFill)
      }

      CrayonIconKind.IMOBILE -> {
        val box = RectF(cx - r * 0.80f, cy - r * 0.76f, cx + r * 0.80f, cy + r * 0.76f)
        canvas.drawRoundRect(box, r * 0.26f, r * 0.26f, accentWash)
        canvas.drawRoundRect(box, r * 0.26f, r * 0.26f, inkStroke)
        canvas.drawCircle(cx - r * 0.32f, cy - r * 0.32f, r * 0.11f, accentFill)
        canvas.drawLine(cx - r * 0.32f, cy - r * 0.04f, cx - r * 0.32f, cy + r * 0.44f, accentStroke)
        // Rupee lines
        canvas.drawLine(cx, cy - r * 0.30f, cx + r * 0.46f, cy - r * 0.30f, inkStroke)
        canvas.drawLine(cx, cy - r * 0.04f, cx + r * 0.42f, cy - r * 0.04f, inkStroke)
        val rupeeTail = Path().apply {
          moveTo(cx + r * 0.26f, cy - r * 0.30f)
          quadTo(cx + r * 0.42f, cy + r * 0.02f, cx + r * 0.04f, cy + r * 0.14f)
          lineTo(cx + r * 0.44f, cy + r * 0.46f)
        }
        canvas.drawPath(rupeeTail, inkStroke)
      }

      CrayonIconKind.SBI_CARD -> {
        val card = RectF(cx - r * 0.88f, cy - r * 0.56f, cx + r * 0.88f, cy + r * 0.56f)
        canvas.drawRoundRect(card, r * 0.22f, r * 0.22f, accentWash)
        canvas.drawRoundRect(card, r * 0.22f, r * 0.22f, inkStroke)
        canvas.drawCircle(cx - r * 0.24f, cy, r * 0.28f, accentStroke)
        canvas.drawLine(cx - r * 0.24f, cy + r * 0.10f, cx - r * 0.24f, cy + r * 0.36f, accentStroke)
        canvas.drawLine(cx + r * 0.24f, cy + r * 0.18f, cx + r * 0.60f, cy + r * 0.18f, inkStroke)
      }

      CrayonIconKind.AXIS_MOBILE -> {
        canvas.drawCircle(cx, cy, r * 0.82f, accentWash)
        val outerTri = Path().apply {
          moveTo(cx, cy - r * 0.78f)
          lineTo(cx + r * 0.76f, cy + r * 0.66f)
          lineTo(cx + r * 0.30f, cy + r * 0.66f)
          lineTo(cx, cy + r * 0.02f)
          lineTo(cx - r * 0.30f, cy + r * 0.66f)
          lineTo(cx - r * 0.76f, cy + r * 0.66f)
          close()
        }
        canvas.drawPath(outerTri, accentStroke)
        canvas.drawCircle(cx, cy - r * 0.10f, r * 0.13f, inkFill)
      }

      CrayonIconKind.BHIM -> {
        val arrow1 = Path().apply {
          moveTo(cx - r * 0.56f, cy - r * 0.68f)
          lineTo(cx + r * 0.08f, cy)
          lineTo(cx - r * 0.56f, cy + r * 0.68f)
        }
        val arrow2 = Path().apply {
          moveTo(cx - r * 0.04f, cy - r * 0.68f)
          lineTo(cx + r * 0.62f, cy)
          lineTo(cx - r * 0.04f, cy + r * 0.68f)
        }
        canvas.drawPath(arrow1, inkStroke)
        canvas.drawPath(arrow2, accentStroke)
      }

      CrayonIconKind.RAPIDO -> {
        canvas.drawCircle(cx, cy, r * 0.82f, accentWash)
        canvas.drawCircle(cx, cy, r * 0.82f, accentStroke)
        val bolt = Path().apply {
          moveTo(cx + r * 0.16f, cy - r * 0.54f)
          lineTo(cx - r * 0.28f, cy + r * 0.04f)
          lineTo(cx + r * 0.06f, cy + r * 0.04f)
          lineTo(cx - r * 0.14f, cy + r * 0.56f)
          lineTo(cx + r * 0.36f, cy - r * 0.06f)
          lineTo(cx + r * 0.02f, cy - r * 0.06f)
          close()
        }
        canvas.drawPath(bolt, inkFill)
      }

      CrayonIconKind.RAILONE -> {
        val cab = RectF(cx - r * 0.56f, cy - r * 0.82f, cx + r * 0.56f, cy + r * 0.42f)
        canvas.drawRoundRect(cab, r * 0.24f, r * 0.24f, accentWash)
        canvas.drawRoundRect(cab, r * 0.24f, r * 0.24f, inkStroke)
        canvas.drawLine(cab.left + r * 0.12f, cy - r * 0.20f, cab.right - r * 0.12f, cy - r * 0.20f, accentStroke)
        canvas.drawCircle(cx - r * 0.26f, cy + r * 0.14f, r * 0.10f, accentFill)
        canvas.drawCircle(cx + r * 0.26f, cy + r * 0.14f, r * 0.10f, accentFill)
        canvas.drawLine(cx - r * 0.42f, cy + r * 0.44f, cx - r * 0.66f, cy + r * 0.84f, inkStroke)
        canvas.drawLine(cx + r * 0.42f, cy + r * 0.44f, cx + r * 0.66f, cy + r * 0.84f, inkStroke)
      }

      CrayonIconKind.TENMIN -> {
        canvas.drawCircle(cx, cy + r * 0.08f, r * 0.74f, accentWash)
        canvas.drawCircle(cx, cy + r * 0.08f, r * 0.74f, accentStroke)
        canvas.drawLine(cx - r * 0.22f, cy - r * 0.82f, cx + r * 0.22f, cy - r * 0.82f, inkStroke)
        CrayonWidgetRenderer.drawCrayonText(
          canvas = canvas,
          text = "10",
          x = cx,
          yCenter = cy + r * 0.10f,
          textSize = minDim * 0.21f,
          typeface = Typeface.DEFAULT_BOLD,
          colorArgb = settings.theme.inkPrimaryArgb,
          align = Paint.Align.CENTER,
          minDim = minDim,
          roughness = 0.75f,
          heavyGrain = false,
          isBold = true,
        )
      }

      CrayonIconKind.UNACADEMY -> {
        val cap = Path().apply {
          moveTo(cx, cy - r * 0.68f)
          lineTo(cx + r * 0.86f, cy - r * 0.22f)
          lineTo(cx, cy + r * 0.24f)
          lineTo(cx - r * 0.86f, cy - r * 0.22f)
          close()
        }
        canvas.drawPath(cap, accentWash)
        canvas.drawPath(cap, inkStroke)
        val uArc = Path().apply {
          addArc(RectF(cx - r * 0.44f, cy - r * 0.02f, cx + r * 0.44f, cy + r * 0.74f), 10f, 160f)
        }
        canvas.drawPath(uArc, accentStroke)
      }

      CrayonIconKind.MENTIHUB -> {
        val bars = RectF(cx - r * 0.82f, cy - r * 0.74f, cx + r * 0.82f, cy + r * 0.64f)
        canvas.drawRoundRect(bars, r * 0.20f, r * 0.20f, accentWash)
        canvas.drawRoundRect(bars, r * 0.20f, r * 0.20f, inkStroke)
        canvas.drawLine(cx - r * 0.36f, cy + r * 0.34f, cx - r * 0.36f, cy - r * 0.12f, accentStroke)
        canvas.drawLine(cx, cy + r * 0.34f, cx, cy - r * 0.42f, inkStroke)
        canvas.drawLine(cx + r * 0.36f, cy + r * 0.34f, cx + r * 0.36f, cy - r * 0.22f, accentStroke)
      }

      CrayonIconKind.BLINKIT -> {
        val badge = RectF(cx - r * 0.82f, cy - r * 0.82f, cx + r * 0.82f, cy + r * 0.82f)
        canvas.drawRoundRect(badge, r * 0.30f, r * 0.30f, accentWash)
        canvas.drawRoundRect(badge, r * 0.30f, r * 0.30f, accentStroke)
        canvas.drawLine(cx - r * 0.24f, cy - r * 0.48f, cx - r * 0.24f, cy + r * 0.46f, inkStroke)
        canvas.drawCircle(cx + r * 0.06f, cy + r * 0.18f, r * 0.28f, inkStroke)
        canvas.drawCircle(cx + r * 0.34f, cy - r * 0.34f, r * 0.12f, accentFill)
      }

      CrayonIconKind.DOMINOS -> {
        canvas.save()
        canvas.rotate(-28f, cx, cy)
        val tile = RectF(cx - r * 0.44f, cy - r * 0.84f, cx + r * 0.44f, cy + r * 0.84f)
        canvas.drawRoundRect(tile, r * 0.16f, r * 0.16f, accentWash)
        canvas.drawRoundRect(tile, r * 0.16f, r * 0.16f, inkStroke)
        canvas.drawLine(tile.left, cy, tile.right, cy, accentStroke)
        canvas.drawCircle(cx, cy - r * 0.42f, r * 0.12f, accentFill)
        canvas.drawCircle(cx - r * 0.16f, cy + r * 0.32f, r * 0.10f, inkFill)
        canvas.drawCircle(cx + r * 0.16f, cy + r * 0.52f, r * 0.10f, inkFill)
        canvas.restore()
      }

      CrayonIconKind.MINECRAFT -> {
        val block = RectF(cx - r * 0.82f, cy - r * 0.82f, cx + r * 0.82f, cy + r * 0.82f)
        canvas.drawRoundRect(block, r * 0.12f, r * 0.12f, accentWash)
        canvas.drawRoundRect(block, r * 0.12f, r * 0.12f, inkStroke)
        val eyeSize = r * 0.28f
        canvas.drawRect(cx - r * 0.52f, cy - r * 0.40f, cx - r * 0.52f + eyeSize, cy - r * 0.40f + eyeSize, inkFill)
        canvas.drawRect(cx + r * 0.52f - eyeSize, cy - r * 0.40f, cx + r * 0.52f, cy - r * 0.40f + eyeSize, inkFill)
        val mouth = RectF(cx - r * 0.24f, cy + r * 0.02f, cx + r * 0.24f, cy + r * 0.46f)
        canvas.drawRect(mouth, accentFill)
      }

      CrayonIconKind.PHONE -> {
        val handset = Path().apply {
          moveTo(cx - r * 0.72f, cy - r * 0.56f)
          quadTo(cx - r * 0.85f, cy + r * 0.25f, cx - r * 0.15f, cy + r * 0.65f)
          quadTo(cx + r * 0.45f, cy + r * 0.92f, cx + r * 0.78f, cy + r * 0.55f)
          lineTo(cx + r * 0.52f, cy + r * 0.26f)
          lineTo(cx + r * 0.26f, cy + r * 0.36f)
          quadTo(cx - r * 0.12f, cy + r * 0.18f, cx - r * 0.34f, cy - r * 0.18f)
          lineTo(cx - r * 0.24f, cy - r * 0.46f)
          close()
        }
        canvas.drawPath(handset, accentWash)
        canvas.drawPath(handset, inkStroke)
        val wave = Path().apply {
          addArc(RectF(cx - r * 0.1f, cy - r * 0.88f, cx + r * 0.86f, cy + r * 0.08f), -75f, 65f)
        }
        canvas.drawPath(wave, accentStroke)
      }

      CrayonIconKind.MESSAGES -> {
        val bubble = RectF(cx - r * 0.86f, cy - r * 0.68f, cx + r * 0.86f, cy + r * 0.42f)
        val path = Path().apply {
          addRoundRect(bubble, r * 0.28f, r * 0.28f, Path.Direction.CW)
          moveTo(cx - r * 0.46f, cy + r * 0.40f)
          lineTo(cx - r * 0.64f, cy + r * 0.82f)
          lineTo(cx - r * 0.10f, cy + r * 0.42f)
        }
        canvas.drawPath(path, accentWash)
        canvas.drawPath(path, inkStroke)
        canvas.drawCircle(cx - r * 0.36f, cy - r * 0.12f, r * 0.10f, accentFill)
        canvas.drawCircle(cx, cy - r * 0.12f, r * 0.10f, accentFill)
        canvas.drawCircle(cx + r * 0.36f, cy - r * 0.12f, r * 0.10f, accentFill)
      }

      CrayonIconKind.CAMERA -> {
        val body = RectF(cx - r * 0.90f, cy - r * 0.54f, cx + r * 0.90f, cy + r * 0.68f)
        val topBump = Path().apply {
          moveTo(cx - r * 0.42f, cy - r * 0.54f)
          lineTo(cx - r * 0.26f, cy - r * 0.80f)
          lineTo(cx + r * 0.26f, cy - r * 0.80f)
          lineTo(cx + r * 0.42f, cy - r * 0.54f)
        }
        canvas.drawRoundRect(body, r * 0.22f, r * 0.22f, accentWash)
        canvas.drawRoundRect(body, r * 0.22f, r * 0.22f, inkStroke)
        canvas.drawPath(topBump, inkStroke)
        canvas.drawCircle(cx, cy + r * 0.08f, r * 0.34f, accentStroke)
        canvas.drawCircle(cx + r * 0.56f, cy - r * 0.26f, r * 0.09f, accentFill)
      }

      CrayonIconKind.BROWSER -> {
        canvas.drawCircle(cx, cy, r * 0.86f, accentWash)
        canvas.drawCircle(cx, cy, r * 0.86f, inkStroke)
        val needle = Path().apply {
          moveTo(cx + r * 0.48f, cy - r * 0.48f)
          lineTo(cx + r * 0.12f, cy + r * 0.12f)
          lineTo(cx - r * 0.48f, cy + r * 0.48f)
          lineTo(cx - r * 0.12f, cy - r * 0.12f)
          close()
        }
        canvas.drawPath(needle, accentFill)
        canvas.drawPath(needle, accentStroke)
      }

      CrayonIconKind.PHOTOS -> {
        val frame = RectF(cx - r * 0.84f, cy - r * 0.72f, cx + r * 0.84f, cy + r * 0.72f)
        canvas.drawRoundRect(frame, r * 0.18f, r * 0.18f, accentWash)
        canvas.drawRoundRect(frame, r * 0.18f, r * 0.18f, inkStroke)
        val peaks = Path().apply {
          moveTo(frame.left + r * 0.14f, frame.bottom - r * 0.16f)
          lineTo(cx - r * 0.22f, cy + r * 0.02f)
          lineTo(cx + r * 0.06f, cy + r * 0.34f)
          lineTo(cx + r * 0.34f, cy - r * 0.08f)
          lineTo(frame.right - r * 0.14f, frame.bottom - r * 0.16f)
        }
        canvas.drawPath(peaks, inkStroke)
        canvas.drawCircle(cx - r * 0.36f, cy - r * 0.28f, r * 0.16f, accentFill)
      }

      CrayonIconKind.SETTINGS -> {
        canvas.drawCircle(cx, cy, r * 0.56f, accentWash)
        val teeth = 8
        for (i in 0 until teeth) {
          val angle = (i * (360.0 / teeth)) * Math.PI / 180.0
          val x1 = (cx + cos(angle) * r * 0.56f).toFloat()
          val y1 = (cy + sin(angle) * r * 0.56f).toFloat()
          val x2 = (cx + cos(angle) * r * 0.88f).toFloat()
          val y2 = (cy + sin(angle) * r * 0.88f).toFloat()
          canvas.drawLine(x1, y1, x2, y2, inkStroke)
        }
        canvas.drawCircle(cx, cy, r * 0.56f, inkStroke)
        canvas.drawCircle(cx, cy, r * 0.24f, accentStroke)
      }

      CrayonIconKind.CLOCK -> {
        canvas.drawCircle(cx, cy, r * 0.86f, accentWash)
        canvas.drawCircle(cx, cy, r * 0.86f, inkStroke)
        val hands = Path().apply {
          moveTo(cx, cy - r * 0.48f)
          lineTo(cx, cy)
          lineTo(cx + r * 0.36f, cy + r * 0.24f)
        }
        canvas.drawPath(hands, accentStroke)
        canvas.drawCircle(cx, cy, r * 0.09f, accentFill)
      }

      CrayonIconKind.CALENDAR -> {
        val box = RectF(cx - r * 0.82f, cy - r * 0.64f, cx + r * 0.82f, cy + r * 0.82f)
        canvas.drawRoundRect(box, r * 0.20f, r * 0.20f, accentWash)
        canvas.drawRoundRect(box, r * 0.20f, r * 0.20f, inkStroke)
        canvas.drawLine(box.left, cy - r * 0.20f, box.right, cy - r * 0.20f, inkStroke)
        canvas.drawLine(cx - r * 0.38f, cy - r * 0.84f, cx - r * 0.38f, cy - r * 0.46f, accentStroke)
        canvas.drawLine(cx + r * 0.38f, cy - r * 0.84f, cx + r * 0.38f, cy - r * 0.46f, accentStroke)
        canvas.drawCircle(cx, cy + r * 0.30f, r * 0.20f, accentFill)
      }

      CrayonIconKind.CALCULATOR -> {
        val pad = RectF(cx - r * 0.72f, cy - r * 0.88f, cx + r * 0.72f, cy + r * 0.88f)
        canvas.drawRoundRect(pad, r * 0.20f, r * 0.20f, accentWash)
        canvas.drawRoundRect(pad, r * 0.20f, r * 0.20f, inkStroke)
        canvas.drawLine(pad.left + r * 0.18f, cy - r * 0.36f, pad.right - r * 0.18f, cy - r * 0.36f, inkStroke)
        val dotR = r * 0.11f
        canvas.drawCircle(cx - r * 0.30f, cy + r * 0.04f, dotR, inkFill)
        canvas.drawCircle(cx + r * 0.30f, cy + r * 0.04f, dotR, inkFill)
        canvas.drawCircle(cx - r * 0.30f, cy + r * 0.46f, dotR, inkFill)
        canvas.drawCircle(cx + r * 0.30f, cy + r * 0.46f, dotR * 1.2f, accentFill)
      }

      CrayonIconKind.WEATHER -> {
        canvas.drawCircle(cx + r * 0.28f, cy - r * 0.34f, r * 0.32f, accentFill)
        val cloud = Path().apply {
          moveTo(cx - r * 0.62f, cy + r * 0.56f)
          quadTo(cx - r * 0.92f, cy + r * 0.56f, cx - r * 0.90f, cy + r * 0.18f)
          quadTo(cx - r * 0.84f, cy - r * 0.16f, cx - r * 0.46f, cy - r * 0.12f)
          quadTo(cx - r * 0.26f, cy - r * 0.48f, cx + r * 0.12f, cy - r * 0.34f)
          quadTo(cx + r * 0.42f, cy - r * 0.22f, cx + r * 0.40f, cy + r * 0.12f)
          quadTo(cx + r * 0.78f, cy + r * 0.14f, cx + r * 0.74f, cy + r * 0.46f)
          quadTo(cx + r * 0.72f, cy + r * 0.56f, cx + r * 0.48f, cy + r * 0.56f)
          close()
        }
        canvas.drawPath(cloud, accentWash)
        canvas.drawPath(cloud, inkStroke)
      }

      CrayonIconKind.NOTES -> {
        val page = RectF(cx - r * 0.74f, cy - r * 0.86f, cx + r * 0.74f, cy + r * 0.86f)
        canvas.drawRoundRect(page, r * 0.18f, r * 0.18f, accentWash)
        canvas.drawRoundRect(page, r * 0.18f, r * 0.18f, inkStroke)
        canvas.drawLine(cx - r * 0.42f, cy - r * 0.36f, cx + r * 0.42f, cy - r * 0.36f, accentStroke)
        canvas.drawLine(cx - r * 0.42f, cy, cx + r * 0.42f, cy, inkStroke)
        canvas.drawLine(cx - r * 0.42f, cy + r * 0.36f, cx + r * 0.16f, cy + r * 0.36f, inkStroke)
      }

      CrayonIconKind.FILES -> {
        val folder = Path().apply {
          moveTo(cx - r * 0.84f, cy - r * 0.64f)
          lineTo(cx - r * 0.20f, cy - r * 0.64f)
          lineTo(cx, cy - r * 0.40f)
          lineTo(cx + r * 0.84f, cy - r * 0.40f)
          lineTo(cx + r * 0.84f, cy + r * 0.70f)
          lineTo(cx - r * 0.84f, cy + r * 0.70f)
          close()
        }
        canvas.drawPath(folder, accentWash)
        canvas.drawPath(folder, inkStroke)
        canvas.drawLine(cx - r * 0.46f, cy + r * 0.12f, cx + r * 0.46f, cy + r * 0.12f, accentStroke)
      }

      CrayonIconKind.CONTACTS -> {
        canvas.drawCircle(cx, cy - r * 0.32f, r * 0.34f, accentWash)
        canvas.drawCircle(cx, cy - r * 0.32f, r * 0.34f, accentStroke)
        val shoulders = Path().apply {
          moveTo(cx - r * 0.76f, cy + r * 0.76f)
          quadTo(cx - r * 0.68f, cy + r * 0.16f, cx, cy + r * 0.16f)
          quadTo(cx + r * 0.68f, cy + r * 0.16f, cx + r * 0.76f, cy + r * 0.76f)
        }
        canvas.drawPath(shoulders, inkStroke)
      }

      CrayonIconKind.MAIL -> {
        val env = RectF(cx - r * 0.88f, cy - r * 0.60f, cx + r * 0.88f, cy + r * 0.60f)
        canvas.drawRoundRect(env, r * 0.16f, r * 0.16f, accentWash)
        canvas.drawRoundRect(env, r * 0.16f, r * 0.16f, inkStroke)
        val flap = Path().apply {
          moveTo(env.left + r * 0.08f, env.top + r * 0.10f)
          lineTo(cx, cy + r * 0.12f)
          lineTo(env.right - r * 0.08f, env.top + r * 0.10f)
        }
        canvas.drawPath(flap, accentStroke)
      }

      CrayonIconKind.COMPASS -> {
        canvas.drawCircle(cx, cy, r * 0.86f, accentWash)
        canvas.drawCircle(cx, cy, r * 0.86f, inkStroke)
        val northNeedle = Path().apply {
          moveTo(cx + r * 0.42f, cy - r * 0.42f)
          lineTo(cx + r * 0.14f, cy + r * 0.14f)
          lineTo(cx - r * 0.14f, cy - r * 0.14f)
          close()
        }
        val southNeedle = Path().apply {
          moveTo(cx - r * 0.42f, cy + r * 0.42f)
          lineTo(cx - r * 0.14f, cy - r * 0.14f)
          lineTo(cx + r * 0.14f, cy + r * 0.14f)
          close()
        }
        canvas.drawPath(northNeedle, accentFill)
        canvas.drawPath(northNeedle, accentStroke)
        canvas.drawPath(southNeedle, inkStroke)
        canvas.drawCircle(cx, cy, r * 0.09f, inkFill)
      }

      CrayonIconKind.MAPS -> {
        val pin = Path().apply {
          moveTo(cx, cy + r * 0.88f)
          quadTo(cx - r * 0.74f, cy + r * 0.08f, cx - r * 0.64f, cy - r * 0.34f)
          quadTo(cx - r * 0.56f, cy - r * 0.88f, cx, cy - r * 0.88f)
          quadTo(cx + r * 0.56f, cy - r * 0.88f, cx + r * 0.64f, cy - r * 0.34f)
          quadTo(cx + r * 0.74f, cy + r * 0.08f, cx, cy + r * 0.88f)
          close()
        }
        canvas.drawPath(pin, accentWash)
        canvas.drawPath(pin, inkStroke)
        canvas.drawCircle(cx, cy - r * 0.24f, r * 0.24f, accentFill)
      }

      CrayonIconKind.MUSIC -> {
        val stem = Path().apply {
          moveTo(cx - r * 0.30f, cy + r * 0.44f)
          lineTo(cx - r * 0.30f, cy - r * 0.58f)
          lineTo(cx + r * 0.58f, cy - r * 0.78f)
          lineTo(cx + r * 0.58f, cy + r * 0.28f)
        }
        canvas.drawPath(stem, inkStroke)
        canvas.drawCircle(cx - r * 0.48f, cy + r * 0.52f, r * 0.24f, accentFill)
        canvas.drawCircle(cx + r * 0.40f, cy + r * 0.36f, r * 0.24f, accentFill)
      }

      CrayonIconKind.SPOTIFY -> {
        canvas.drawCircle(cx, cy, r * 0.86f, accentWash)
        canvas.drawCircle(cx, cy, r * 0.86f, inkStroke)
        for (idx in 0..2) {
          val yOff = -r * 0.26f + idx * r * 0.28f
          val span = r * (0.56f - idx * 0.10f)
          val arc = Path().apply {
            moveTo(cx - span, cy + yOff + r * 0.08f)
            quadTo(cx, cy + yOff - r * 0.18f, cx + span, cy + yOff + r * 0.10f)
          }
          canvas.drawPath(arc, accentStroke)
        }
      }

      CrayonIconKind.YOUTUBE -> {
        val box = RectF(cx - r * 0.90f, cy - r * 0.62f, cx + r * 0.90f, cy + r * 0.62f)
        canvas.drawRoundRect(box, r * 0.28f, r * 0.28f, accentWash)
        canvas.drawRoundRect(box, r * 0.28f, r * 0.28f, inkStroke)
        val play = Path().apply {
          moveTo(cx - r * 0.22f, cy - r * 0.32f)
          lineTo(cx + r * 0.36f, cy)
          lineTo(cx - r * 0.22f, cy + r * 0.32f)
          close()
        }
        canvas.drawPath(play, accentFill)
      }

      CrayonIconKind.WHATSAPP -> {
        val bubble = Path().apply {
          addArc(RectF(cx - r * 0.80f, cy - r * 0.80f, cx + r * 0.80f, cy + r * 0.80f), -220f, 305f)
          lineTo(cx - r * 0.78f, cy + r * 0.78f)
          close()
        }
        canvas.drawPath(bubble, accentWash)
        canvas.drawPath(bubble, inkStroke)
        val receiver = Path().apply {
          moveTo(cx - r * 0.28f, cy - r * 0.26f)
          quadTo(cx - r * 0.30f, cy + r * 0.28f, cx + r * 0.28f, cy + r * 0.30f)
        }
        canvas.drawPath(receiver, accentStroke)
      }

      CrayonIconKind.INSTAGRAM -> {
        val box = RectF(cx - r * 0.82f, cy - r * 0.82f, cx + r * 0.82f, cy + r * 0.82f)
        canvas.drawRoundRect(box, r * 0.36f, r * 0.36f, accentWash)
        canvas.drawRoundRect(box, r * 0.36f, r * 0.36f, inkStroke)
        canvas.drawCircle(cx, cy, r * 0.34f, accentStroke)
        canvas.drawCircle(cx + r * 0.46f, cy - r * 0.46f, r * 0.10f, accentFill)
      }

      CrayonIconKind.TELEGRAM -> {
        val plane = Path().apply {
          moveTo(cx - r * 0.86f, cy - r * 0.04f)
          lineTo(cx + r * 0.82f, cy - r * 0.72f)
          lineTo(cx + r * 0.46f, cy + r * 0.76f)
          lineTo(cx - r * 0.08f, cy + r * 0.30f)
          lineTo(cx - r * 0.40f, cy + r * 0.56f)
          lineTo(cx - r * 0.34f, cy + r * 0.14f)
          close()
        }
        canvas.drawPath(plane, accentWash)
        canvas.drawPath(plane, inkStroke)
        canvas.drawLine(cx - r * 0.34f, cy + r * 0.14f, cx + r * 0.82f, cy - r * 0.72f, accentStroke)
      }

      CrayonIconKind.DISCORD -> {
        val visor = Path().apply {
          moveTo(cx - r * 0.62f, cy - r * 0.54f)
          quadTo(cx, cy - r * 0.74f, cx + r * 0.62f, cy - r * 0.54f)
          lineTo(cx + r * 0.86f, cy + r * 0.42f)
          quadTo(cx + r * 0.48f, cy + r * 0.72f, cx + r * 0.24f, cy + r * 0.44f)
          lineTo(cx - r * 0.24f, cy + r * 0.44f)
          quadTo(cx - r * 0.48f, cy + r * 0.72f, cx - r * 0.86f, cy + r * 0.42f)
          close()
        }
        canvas.drawPath(visor, accentWash)
        canvas.drawPath(visor, inkStroke)
        canvas.drawCircle(cx - r * 0.28f, cy, r * 0.13f, accentFill)
        canvas.drawCircle(cx + r * 0.28f, cy, r * 0.13f, accentFill)
      }

      CrayonIconKind.PLAY_STORE -> {
        val tri = Path().apply {
          moveTo(cx - r * 0.66f, cy - r * 0.78f)
          lineTo(cx + r * 0.82f, cy)
          lineTo(cx - r * 0.66f, cy + r * 0.78f)
          close()
        }
        canvas.drawPath(tri, accentWash)
        canvas.drawPath(tri, inkStroke)
        canvas.drawLine(cx - r * 0.66f, cy - r * 0.78f, cx + r * 0.22f, cy + r * 0.30f, accentStroke)
      }

      CrayonIconKind.WALLET -> {
        val wallet = RectF(cx - r * 0.86f, cy - r * 0.60f, cx + r * 0.86f, cy + r * 0.68f)
        canvas.drawRoundRect(wallet, r * 0.22f, r * 0.22f, accentWash)
        canvas.drawRoundRect(wallet, r * 0.22f, r * 0.22f, inkStroke)
        val flap = RectF(cx + r * 0.20f, cy - r * 0.18f, cx + r * 0.90f, cy + r * 0.26f)
        canvas.drawRoundRect(flap, r * 0.14f, r * 0.14f, accentStroke)
        canvas.drawCircle(cx + r * 0.44f, cy + r * 0.04f, r * 0.09f, accentFill)
      }

      CrayonIconKind.RECORDER -> {
        val mic = RectF(cx - r * 0.30f, cy - r * 0.82f, cx + r * 0.30f, cy + r * 0.18f)
        canvas.drawRoundRect(mic, r * 0.30f, r * 0.30f, accentWash)
        canvas.drawRoundRect(mic, r * 0.30f, r * 0.30f, accentStroke)
        val cradle = Path().apply {
          addArc(RectF(cx - r * 0.58f, cy - r * 0.36f, cx + r * 0.58f, cy + r * 0.48f), 0f, 180f)
        }
        canvas.drawPath(cradle, inkStroke)
        canvas.drawLine(cx, cy + r * 0.48f, cx, cy + r * 0.84f, inkStroke)
        canvas.drawLine(cx - r * 0.36f, cy + r * 0.84f, cx + r * 0.36f, cy + r * 0.84f, inkStroke)
      }

      CrayonIconKind.PODCASTS -> {
        canvas.drawCircle(cx, cy - r * 0.08f, r * 0.24f, accentFill)
        val innerArc = Path().apply {
          addArc(RectF(cx - r * 0.52f, cy - r * 0.60f, cx + r * 0.52f, cy + r * 0.44f), 140f, 260f)
        }
        val outerArc = Path().apply {
          addArc(RectF(cx - r * 0.82f, cy - r * 0.90f, cx + r * 0.82f, cy + r * 0.74f), 145f, 250f)
        }
        canvas.drawPath(innerArc, accentStroke)
        canvas.drawPath(outerArc, inkStroke)
        canvas.drawLine(cx, cy + r * 0.24f, cx, cy + r * 0.86f, inkStroke)
      }

      CrayonIconKind.FITNESS -> {
        val heart = Path().apply {
          moveTo(cx, cy + r * 0.76f)
          cubicTo(
            cx - r * 1.04f,
            cy + r * 0.16f,
            cx - r * 0.88f,
            cy - r * 0.78f,
            cx,
            cy - r * 0.28f,
          )
          cubicTo(
            cx + r * 0.88f,
            cy - r * 0.78f,
            cx + r * 1.04f,
            cy + r * 0.16f,
            cx,
            cy + r * 0.76f,
          )
          close()
        }
        canvas.drawPath(heart, accentWash)
        canvas.drawPath(heart, accentStroke)
        val pulse = Path().apply {
          moveTo(cx - r * 0.44f, cy + r * 0.08f)
          lineTo(cx - r * 0.16f, cy + r * 0.08f)
          lineTo(cx, cy - r * 0.18f)
          lineTo(cx + r * 0.18f, cy + r * 0.24f)
          lineTo(cx + r * 0.44f, cy + r * 0.08f)
        }
        canvas.drawPath(pulse, inkStroke)
      }

      CrayonIconKind.SHOPPING -> {
        val bag = RectF(cx - r * 0.74f, cy - r * 0.34f, cx + r * 0.74f, cy + r * 0.82f)
        canvas.drawRoundRect(bag, r * 0.18f, r * 0.18f, accentWash)
        canvas.drawRoundRect(bag, r * 0.18f, r * 0.18f, inkStroke)
        val handle = Path().apply {
          addArc(RectF(cx - r * 0.38f, cy - r * 0.84f, cx + r * 0.38f, cy - r * 0.02f), 180f, 180f)
        }
        canvas.drawPath(handle, accentStroke)
      }

      CrayonIconKind.GAMES -> {
        val pad = RectF(cx - r * 0.90f, cy - r * 0.46f, cx + r * 0.90f, cy + r * 0.56f)
        canvas.drawRoundRect(pad, r * 0.44f, r * 0.44f, accentWash)
        canvas.drawRoundRect(pad, r * 0.44f, r * 0.44f, inkStroke)
        canvas.drawLine(cx - r * 0.42f, cy - r * 0.16f, cx - r * 0.42f, cy + r * 0.24f, inkStroke)
        canvas.drawLine(cx - r * 0.62f, cy + r * 0.04f, cx - r * 0.22f, cy + r * 0.04f, inkStroke)
        canvas.drawCircle(cx + r * 0.34f, cy - r * 0.10f, r * 0.11f, accentFill)
        canvas.drawCircle(cx + r * 0.56f, cy + r * 0.14f, r * 0.11f, accentFill)
      }

      CrayonIconKind.TERMINAL -> {
        val box = RectF(cx - r * 0.86f, cy - r * 0.68f, cx + r * 0.86f, cy + r * 0.68f)
        canvas.drawRoundRect(box, r * 0.20f, r * 0.20f, accentWash)
        canvas.drawRoundRect(box, r * 0.20f, r * 0.20f, inkStroke)
        val chevron = Path().apply {
          moveTo(cx - r * 0.48f, cy - r * 0.28f)
          lineTo(cx - r * 0.12f, cy)
          lineTo(cx - r * 0.48f, cy + r * 0.28f)
        }
        canvas.drawPath(chevron, accentStroke)
        canvas.drawLine(cx + r * 0.06f, cy + r * 0.28f, cx + r * 0.50f, cy + r * 0.28f, inkStroke)
      }

      CrayonIconKind.GPAY -> {
        val arc = Path().apply {
          addArc(RectF(cx - r * 0.78f, cy - r * 0.78f, cx + r * 0.78f, cy + r * 0.78f), 320f, -315f)
          lineTo(cx + r * 0.06f, cy + r * 0.04f)
        }
        canvas.drawCircle(cx, cy, r * 0.74f, accentWash)
        canvas.drawPath(arc, inkStroke)
        // Small inner rupee lines
        canvas.drawLine(cx - r * 0.30f, cy - r * 0.24f, cx + r * 0.18f, cy - r * 0.24f, accentStroke)
        canvas.drawLine(cx - r * 0.30f, cy - r * 0.04f, cx + r * 0.12f, cy - r * 0.04f, accentStroke)
        val leg = Path().apply {
          moveTo(cx - r * 0.14f, cy - r * 0.24f)
          quadTo(cx + r * 0.04f, cy - r * 0.12f, cx - r * 0.14f, cy + r * 0.04f)
          lineTo(cx + r * 0.12f, cy + r * 0.34f)
        }
        canvas.drawPath(leg, accentStroke)
      }

      CrayonIconKind.INSTAMART -> {
        val basket = Path().apply {
          moveTo(cx - r * 0.84f, cy - r * 0.20f)
          lineTo(cx + r * 0.84f, cy - r * 0.20f)
          lineTo(cx + r * 0.66f, cy + r * 0.76f)
          lineTo(cx - r * 0.66f, cy + r * 0.76f)
          close()
        }
        canvas.drawPath(basket, accentWash)
        canvas.drawPath(basket, inkStroke)
        canvas.drawLine(cx - r * 0.44f, cy - r * 0.20f, cx - r * 0.20f, cy - r * 0.72f, inkStroke)
        canvas.drawLine(cx + r * 0.44f, cy - r * 0.20f, cx + r * 0.20f, cy - r * 0.72f, inkStroke)
        val bolt = Path().apply {
          moveTo(cx + r * 0.08f, cy - r * 0.02f)
          lineTo(cx - r * 0.18f, cy + r * 0.30f)
          lineTo(cx + r * 0.10f, cy + r * 0.30f)
          lineTo(cx - r * 0.08f, cy + r * 0.60f)
        }
        canvas.drawPath(bolt, accentStroke)
      }

      CrayonIconKind.SWIGGY -> {
        val pin = Path().apply {
          moveTo(cx, cy + r * 0.86f)
          quadTo(cx - r * 0.78f, cy + r * 0.14f, cx - r * 0.68f, cy - r * 0.30f)
          quadTo(cx - r * 0.60f, cy - r * 0.86f, cx, cy - r * 0.86f)
          quadTo(cx + r * 0.60f, cy - r * 0.86f, cx + r * 0.68f, cy - r * 0.30f)
          quadTo(cx + r * 0.78f, cy + r * 0.14f, cx, cy + r * 0.86f)
          close()
        }
        canvas.drawPath(pin, accentWash)
        canvas.drawPath(pin, accentStroke)
        val swirl = Path().apply {
          moveTo(cx + r * 0.24f, cy - r * 0.42f)
          cubicTo(cx - r * 0.34f, cy - r * 0.50f, cx - r * 0.32f, cy - r * 0.04f, cx + r * 0.04f, cy - r * 0.02f)
          cubicTo(cx + r * 0.34f, cy, cx + r * 0.32f, cy + r * 0.34f, cx - r * 0.24f, cy + r * 0.26f)
        }
        canvas.drawPath(swirl, inkStroke)
      }

      CrayonIconKind.GREYTHR -> {
        canvas.drawCircle(cx, cy, r * 0.78f, accentWash)
        val ring = Path().apply {
          addArc(RectF(cx - r * 0.78f, cy - r * 0.78f, cx + r * 0.78f, cy + r * 0.78f), -45f, 305f)
        }
        canvas.drawPath(ring, accentStroke)
        // Monogram "hr"
        canvas.drawLine(cx - r * 0.38f, cy - r * 0.36f, cx - r * 0.38f, cy + r * 0.38f, inkStroke)
        val hArch = Path().apply {
          moveTo(cx - r * 0.38f, cy)
          quadTo(cx - r * 0.10f, cy - r * 0.16f, cx - r * 0.04f, cy + r * 0.10f)
          lineTo(cx - r * 0.04f, cy + r * 0.38f)
        }
        canvas.drawPath(hArch, inkStroke)
        canvas.drawLine(cx + r * 0.18f, cy - r * 0.08f, cx + r * 0.18f, cy + r * 0.38f, inkStroke)
        val rTip = Path().apply {
          moveTo(cx + r * 0.18f, cy + r * 0.04f)
          quadTo(cx + r * 0.34f, cy - r * 0.14f, cx + r * 0.48f, cy - r * 0.04f)
        }
        canvas.drawPath(rTip, inkStroke)
      }

      CrayonIconKind.FLIPKART -> {
        val bag = RectF(cx - r * 0.72f, cy - r * 0.36f, cx + r * 0.72f, cy + r * 0.80f)
        canvas.drawRoundRect(bag, r * 0.22f, r * 0.22f, accentWash)
        canvas.drawRoundRect(bag, r * 0.22f, r * 0.22f, inkStroke)
        val handle = Path().apply {
          addArc(RectF(cx - r * 0.34f, cy - r * 0.84f, cx + r * 0.34f, cy - r * 0.06f), 180f, 180f)
        }
        canvas.drawPath(handle, inkStroke)
        // Stylized lowercase f
        val stem = Path().apply {
          moveTo(cx + r * 0.20f, cy - r * 0.10f)
          quadTo(cx - r * 0.06f, cy - r * 0.16f, cx - r * 0.06f, cy + r * 0.14f)
          lineTo(cx - r * 0.06f, cy + r * 0.56f)
        }
        canvas.drawPath(stem, accentStroke)
        canvas.drawLine(cx - r * 0.24f, cy + r * 0.20f, cx + r * 0.16f, cy + r * 0.20f, accentStroke)
      }

      CrayonIconKind.CRED -> {
        val shield = Path().apply {
          moveTo(cx - r * 0.68f, cy - r * 0.74f)
          lineTo(cx + r * 0.68f, cy - r * 0.74f)
          lineTo(cx + r * 0.68f, cy + r * 0.10f)
          quadTo(cx + r * 0.64f, cy + r * 0.58f, cx, cy + r * 0.86f)
          quadTo(cx - r * 0.64f, cy + r * 0.58f, cx - r * 0.68f, cy + r * 0.10f)
          close()
        }
        canvas.drawPath(shield, accentWash)
        canvas.drawPath(shield, inkStroke)
        val inner = Path().apply {
          moveTo(cx - r * 0.36f, cy - r * 0.42f)
          lineTo(cx + r * 0.36f, cy - r * 0.42f)
          lineTo(cx + r * 0.36f, cy + r * 0.06f)
          quadTo(cx + r * 0.32f, cy + r * 0.34f, cx, cy + r * 0.52f)
          quadTo(cx - r * 0.32f, cy + r * 0.34f, cx - r * 0.36f, cy + r * 0.06f)
          close()
        }
        canvas.drawPath(inner, accentStroke)
      }

      CrayonIconKind.COINDCX -> {
        canvas.drawCircle(cx - r * 0.14f, cy, r * 0.62f, accentWash)
        canvas.drawCircle(cx - r * 0.14f, cy, r * 0.62f, inkStroke)
        canvas.drawCircle(cx + r * 0.30f, cy, r * 0.44f, accentStroke)
        val cArc = Path().apply {
          addArc(RectF(cx - r * 0.42f, cy - r * 0.28f, cx + r * 0.14f, cy + r * 0.28f), 45f, 270f)
        }
        canvas.drawPath(cArc, inkStroke)
      }

      CrayonIconKind.JIOHOTSTAR -> {
        canvas.drawCircle(cx, cy, r * 0.78f, accentWash)
        val star = Path().apply {
          moveTo(cx, cy - r * 0.86f)
          quadTo(cx + r * 0.18f, cy - r * 0.18f, cx + r * 0.86f, cy - r * 0.14f)
          quadTo(cx + r * 0.24f, cy + r * 0.14f, cx + r * 0.54f, cy + r * 0.78f)
          quadTo(cx, cy + r * 0.30f, cx - r * 0.54f, cy + r * 0.78f)
          quadTo(cx - r * 0.24f, cy + r * 0.14f, cx - r * 0.86f, cy - r * 0.14f)
          quadTo(cx - r * 0.18f, cy - r * 0.18f, cx, cy - r * 0.86f)
          close()
        }
        canvas.drawPath(star, accentStroke)
        canvas.drawCircle(cx, cy + r * 0.04f, r * 0.16f, inkFill)
      }

      CrayonIconKind.CHALO -> {
        val bus = RectF(cx - r * 0.68f, cy - r * 0.72f, cx + r * 0.68f, cy + r * 0.56f)
        canvas.drawRoundRect(bus, r * 0.28f, r * 0.28f, accentWash)
        canvas.drawRoundRect(bus, r * 0.28f, r * 0.28f, accentStroke)
        canvas.drawLine(bus.left + r * 0.14f, cy + r * 0.04f, bus.right - r * 0.14f, cy + r * 0.04f, inkStroke)
        canvas.drawCircle(cx - r * 0.34f, cy + r * 0.34f, r * 0.11f, inkFill)
        canvas.drawCircle(cx + r * 0.34f, cy + r * 0.34f, r * 0.11f, inkFill)
        canvas.drawLine(cx - r * 0.42f, bus.bottom, cx - r * 0.42f, bus.bottom + r * 0.22f, inkStroke)
        canvas.drawLine(cx + r * 0.42f, bus.bottom, cx + r * 0.42f, bus.bottom + r * 0.22f, inkStroke)
      }

      CrayonIconKind.UBER -> {
        val badge = RectF(cx - r * 0.82f, cy - r * 0.82f, cx + r * 0.82f, cy + r * 0.82f)
        canvas.drawRoundRect(badge, r * 0.34f, r * 0.34f, accentWash)
        canvas.drawRoundRect(badge, r * 0.34f, r * 0.34f, inkStroke)
        val uPath = Path().apply {
          moveTo(cx - r * 0.34f, cy - r * 0.38f)
          lineTo(cx - r * 0.34f, cy + r * 0.12f)
          quadTo(cx, cy + r * 0.52f, cx + r * 0.34f, cy + r * 0.12f)
          lineTo(cx + r * 0.34f, cy - r * 0.38f)
        }
        canvas.drawPath(uPath, accentStroke)
      }

      CrayonIconKind.DIGILOCKER -> {
        val cloud = Path().apply {
          moveTo(cx - r * 0.58f, cy + r * 0.46f)
          quadTo(cx - r * 0.88f, cy + r * 0.46f, cx - r * 0.86f, cy + r * 0.08f)
          quadTo(cx - r * 0.80f, cy - r * 0.26f, cx - r * 0.44f, cy - r * 0.22f)
          quadTo(cx - r * 0.22f, cy - r * 0.64f, cx + r * 0.20f, cy - r * 0.48f)
          quadTo(cx + r * 0.50f, cy - r * 0.36f, cx + r * 0.48f, cy - r * 0.04f)
          quadTo(cx + r * 0.84f, cy, cx + r * 0.80f, cy + r * 0.34f)
          quadTo(cx + r * 0.78f, cy + r * 0.46f, cx + r * 0.54f, cy + r * 0.46f)
          close()
        }
        canvas.drawPath(cloud, accentWash)
        canvas.drawPath(cloud, inkStroke)
        val lock = RectF(cx - r * 0.24f, cy + r * 0.12f, cx + r * 0.24f, cy + r * 0.66f)
        canvas.drawRoundRect(lock, r * 0.10f, r * 0.10f, accentFill)
        canvas.drawCircle(cx, cy + r * 0.10f, r * 0.16f, accentStroke)
      }

      CrayonIconKind.AUTHENTICATOR -> {
        canvas.drawCircle(cx, cy, r * 0.82f, accentWash)
        canvas.drawCircle(cx, cy, r * 0.82f, inkStroke)
        canvas.drawLine(cx, cy - r * 0.48f, cx, cy + r * 0.48f, accentStroke)
        canvas.drawLine(cx - r * 0.42f, cy - r * 0.24f, cx + r * 0.42f, cy + r * 0.24f, accentStroke)
        canvas.drawLine(cx + r * 0.42f, cy - r * 0.24f, cx - r * 0.42f, cy + r * 0.24f, inkStroke)
        canvas.drawCircle(cx, cy, r * 0.14f, accentFill)
      }

      CrayonIconKind.DRIVE -> {
        val tri = Path().apply {
          moveTo(cx, cy - r * 0.78f)
          lineTo(cx + r * 0.82f, cy + r * 0.58f)
          lineTo(cx - r * 0.82f, cy + r * 0.58f)
          close()
        }
        canvas.drawPath(tri, accentWash)
        canvas.drawPath(tri, inkStroke)
        canvas.drawLine(cx - r * 0.24f, cy - r * 0.32f, cx + r * 0.44f, cy + r * 0.58f, accentStroke)
        canvas.drawLine(cx - r * 0.52f, cy + r * 0.24f, cx + r * 0.62f, cy + r * 0.24f, accentStroke)
      }

      CrayonIconKind.DOCS -> {
        val doc = RectF(cx - r * 0.68f, cy - r * 0.84f, cx + r * 0.68f, cy + r * 0.84f)
        canvas.drawRoundRect(doc, r * 0.18f, r * 0.18f, accentWash)
        canvas.drawRoundRect(doc, r * 0.18f, r * 0.18f, inkStroke)
        canvas.drawLine(cx - r * 0.36f, cy - r * 0.34f, cx + r * 0.36f, cy - r * 0.34f, accentStroke)
        canvas.drawLine(cx - r * 0.36f, cy, cx + r * 0.36f, cy, inkStroke)
        canvas.drawLine(cx - r * 0.36f, cy + r * 0.34f, cx + r * 0.18f, cy + r * 0.34f, inkStroke)
      }

      CrayonIconKind.WELLBEING -> {
        canvas.drawCircle(cx, cy - r * 0.50f, r * 0.22f, accentFill)
        val cross = Path().apply {
          moveTo(cx - r * 0.68f, cy - r * 0.12f)
          quadTo(cx, cy + r * 0.08f, cx + r * 0.68f, cy - r * 0.12f)
          moveTo(cx, cy - r * 0.08f)
          lineTo(cx, cy + r * 0.42f)
          moveTo(cx, cy + r * 0.40f)
          lineTo(cx - r * 0.34f, cy + r * 0.84f)
          moveTo(cx, cy + r * 0.40f)
          lineTo(cx + r * 0.34f, cy + r * 0.84f)
        }
        canvas.drawPath(cross, inkStroke)
        canvas.drawCircle(cx, cy, r * 0.82f, accentStroke)
      }

      CrayonIconKind.YONO_SBI -> {
        canvas.drawCircle(cx, cy, r * 0.82f, accentWash)
        canvas.drawCircle(cx, cy, r * 0.82f, accentStroke)
        canvas.drawCircle(cx, cy - r * 0.16f, r * 0.20f, inkFill)
        canvas.drawLine(cx, cy - r * 0.06f, cx, cy + r * 0.78f, inkStroke)
      }

      CrayonIconKind.KOTAK_NEO -> {
        val box = RectF(cx - r * 0.80f, cy - r * 0.80f, cx + r * 0.80f, cy + r * 0.80f)
        canvas.drawRoundRect(box, r * 0.26f, r * 0.26f, accentWash)
        canvas.drawRoundRect(box, r * 0.26f, r * 0.26f, inkStroke)
        val kLeft = Path().apply {
          moveTo(cx - r * 0.34f, cy - r * 0.44f)
          lineTo(cx - r * 0.34f, cy + r * 0.44f)
        }
        val kWing = Path().apply {
          moveTo(cx + r * 0.36f, cy - r * 0.42f)
          lineTo(cx - r * 0.24f, cy)
          lineTo(cx + r * 0.38f, cy + r * 0.44f)
        }
        canvas.drawPath(kLeft, inkStroke)
        canvas.drawPath(kWing, accentStroke)
      }

      CrayonIconKind.INDEED -> {
        val arch = Path().apply {
          addArc(RectF(cx - r * 0.62f, cy - r * 0.68f, cx + r * 0.62f, cy + r * 0.56f), 190f, 150f)
        }
        canvas.drawPath(arch, accentStroke)
        canvas.drawCircle(cx + r * 0.08f, cy - r * 0.18f, r * 0.16f, accentFill)
        canvas.drawLine(cx + r * 0.08f, cy + r * 0.12f, cx + r * 0.08f, cy + r * 0.74f, inkStroke)
      }

      CrayonIconKind.COMERA -> {
        val cBubble = Path().apply {
          addArc(RectF(cx - r * 0.78f, cy - r * 0.78f, cx + r * 0.78f, cy + r * 0.78f), 42f, 276f)
        }
        canvas.drawCircle(cx, cy, r * 0.72f, accentWash)
        canvas.drawPath(cBubble, accentStroke)
        canvas.drawCircle(cx + r * 0.20f, cy, r * 0.18f, inkFill)
      }

      CrayonIconKind.VLC -> {
        val cone = Path().apply {
          moveTo(cx - r * 0.16f, cy - r * 0.78f)
          lineTo(cx + r * 0.16f, cy - r * 0.78f)
          lineTo(cx + r * 0.60f, cy + r * 0.58f)
          lineTo(cx - r * 0.60f, cy + r * 0.58f)
          close()
        }
        canvas.drawPath(cone, accentWash)
        canvas.drawPath(cone, accentStroke)
        canvas.drawLine(cx - r * 0.36f, cy - r * 0.08f, cx + r * 0.36f, cy - r * 0.08f, inkStroke)
        canvas.drawLine(cx - r * 0.78f, cy + r * 0.66f, cx + r * 0.78f, cy + r * 0.66f, inkStroke)
      }
    }
  }
}
