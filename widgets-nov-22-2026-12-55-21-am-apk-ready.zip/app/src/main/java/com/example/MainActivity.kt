package com.example

import android.Manifest
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.lifecycleScope
import com.example.ui.PinWidgetTarget
import com.example.ui.WidgetStudioScreen
import com.example.ui.WidgetStudioViewModel
import com.example.ui.theme.MyApplicationTheme
import com.example.widget.CrayonIconPackRenderer
import com.example.widget.InstalledAppsHelper
import com.example.widget.PedometerHelper
import com.example.widget.ToggleTileType
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity(), SensorEventListener {
  private val viewModel: WidgetStudioViewModel by viewModels()
  private var sensorManager: SensorManager? = null
  private var snackbarHostStateRef: SnackbarHostState? = null
  private var stepListenerRegistered = false
  private var pendingPinPedometerAfterPermission = false

  private val stepPermissionLauncher = registerForActivityResult(
    ActivityResultContracts.RequestPermission(),
  ) { granted ->
    val shouldPinAfter = pendingPinPedometerAfterPermission
    pendingPinPedometerAfterPermission = false

    viewModel.onStepPermissionResult(granted)
    if (granted) {
      registerStepSensorIfAllowed()
      if (shouldPinAfter) {
        launchPinWidgetInternal(PinWidgetTarget.PEDOMETER) { msg ->
          snackbarHostStateRef?.let { host ->
            lifecycleScope.launch { host.showSnackbar(msg) }
          }
        }
      }
    } else {
      snackbarHostStateRef?.let { host ->
        lifecycleScope.launch {
          host.showSnackbar(getString(R.string.step_permission_needed))
        }
      }
    }
  }

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    sensorManager = getSystemService(Context.SENSOR_SERVICE) as? SensorManager

    val appWidgetId = intent?.extras?.getInt(
      AppWidgetManager.EXTRA_APPWIDGET_ID,
      AppWidgetManager.INVALID_APPWIDGET_ID,
    ) ?: AppWidgetManager.INVALID_APPWIDGET_ID

    if (appWidgetId != AppWidgetManager.INVALID_APPWIDGET_ID) {
      setResult(RESULT_CANCELED)
    }

    viewModel.initialize(appWidgetId)

    setContent {
      MyApplicationTheme {
        val uiState by viewModel.uiState.collectAsStateWithLifecycle()
        val snackbarHostState = remember { SnackbarHostState() }
        snackbarHostStateRef = snackbarHostState
        val scope = rememberCoroutineScope()

        WidgetStudioScreen(
          uiState = uiState,
          snackbarHostState = snackbarHostState,
          onSelectTab = { tab -> viewModel.selectTab(tab) },
          onSelectIconShape = { shape -> viewModel.selectIconShape(shape) },
          onSelectIconBrowseMode = { mode -> viewModel.selectIconBrowseMode(mode) },
          onSelectIconCategory = { category -> viewModel.selectIconCategory(category) },
          onIconSearchQueryChange = { query -> viewModel.updateIconSearchQuery(query) },
          onToggleUnmappedOnly = { unmapped -> viewModel.setShowUnmappedOnly(unmapped) },
          onSetPreviewDrawerMode = { drawerMode -> viewModel.setPreviewDrawerStaticMode(drawerMode) },
          onSyncPinnedIcons = {
            viewModel.syncPinnedIconsAsync { syncedCount ->
              val msg = if (syncedCount > 0) {
                getString(R.string.icon_pack_synced_msg, syncedCount)
              } else {
                getString(R.string.icon_pack_sync_empty_msg)
              }
              scope.launch {
                snackbarHostState.showSnackbar(msg)
              }
            }
          },
          onPinAppIcon = { iconKind, targetApp, customLabel ->
            val iconBitmap = if (iconKind != null) {
              CrayonIconPackRenderer.renderIcon(
                kind = iconKind,
                shape = uiState.selectedIconShape,
                settings = uiState.currentSettings,
                sizePx = 256,
              )
            } else {
              CrayonIconPackRenderer.renderInstalledAppIcon(
                context = this,
                app = targetApp,
                shape = uiState.selectedIconShape,
                settings = uiState.currentSettings,
                sizePx = 256,
              )
            }
            val pinned = InstalledAppsHelper.pinAppIconShortcut(
              context = this,
              app = targetApp,
              customLabel = customLabel,
              iconBitmap = iconBitmap,
              iconId = iconKind?.id ?: "auto",
            )
            if (pinned) {
              viewModel.refreshPinnedIconState()
            }
            val displayLabel = customLabel.trim().ifEmpty { targetApp.label }
            val message = if (pinned) {
              getString(R.string.icon_pack_pinned_msg, displayLabel)
            } else {
              getString(R.string.icon_pack_pin_unsupported_msg)
            }
            scope.launch {
              snackbarHostState.showSnackbar(message)
            }
          },
          onSelectFont = { font -> viewModel.selectFont(font) },
          onSelectTheme = { theme -> viewModel.selectTheme(theme) },
          onSelectBalance = { balance -> viewModel.selectBalance(balance) },
          onTogglePage = { viewModel.togglePreviewPage() },
          onSelectPage = { page -> viewModel.setPreviewPage(page) },
          onTapPedometer = {
            handlePedometerInteraction { message ->
              scope.launch { snackbarHostState.showSnackbar(message) }
            }
          },
          onToggleWifi = {
            startActivity(
              ConnectivityToggleActivity.createLaunchIntent(this, ToggleTileType.WIFI),
            )
          },
          onToggleMobileData = {
            startActivity(
              ConnectivityToggleActivity.createLaunchIntent(this, ToggleTileType.MOBILE_DATA),
            )
          },
          onApplyToAll = {
            val count = viewModel.applyCurrentStyleToAllWidgets()
            val msg = if (count > 0) {
              getString(R.string.apply_all_synced_msg, count)
            } else {
              getString(R.string.apply_all_default_msg)
            }
            scope.launch {
              snackbarHostState.showSnackbar(msg)
            }
          },
          onApplyConfigure = { applyToAll ->
            if (viewModel.applyForConfigureWidget(applyToAll = applyToAll)) {
              val resultValue = Intent().putExtra(
                AppWidgetManager.EXTRA_APPWIDGET_ID,
                uiState.appWidgetId,
              )
              setResult(RESULT_OK, resultValue)
              finish()
            }
          },
          onPinWidget = { target ->
            requestPinWidget(target) { message ->
              scope.launch {
                snackbarHostState.showSnackbar(message)
              }
            }
          },
        )
      }
    }
  }

  override fun onNewIntent(intent: Intent) {
    super.onNewIntent(intent)
    setIntent(intent)
    val newWidgetId = intent.extras?.getInt(
      AppWidgetManager.EXTRA_APPWIDGET_ID,
      AppWidgetManager.INVALID_APPWIDGET_ID,
    ) ?: AppWidgetManager.INVALID_APPWIDGET_ID
    if (newWidgetId != viewModel.uiState.value.appWidgetId) {
      viewModel.initialize(newWidgetId)
    }
  }

  override fun onResume() {
    super.onResume()
    viewModel.refreshSystemStatusAndWidgets()
    registerStepSensorIfAllowed()

    if (intent?.getBooleanExtra(EXTRA_REQUEST_STEP_PERMISSION, false) == true) {
      intent.removeExtra(EXTRA_REQUEST_STEP_PERMISSION)
      requestStepPermissionIfNeeded()
    }

    window.decorView.postDelayed({
      viewModel.refreshSystemStatusAndWidgets()
    }, 650L)
  }

  override fun onPause() {
    super.onPause()
    if (stepListenerRegistered) {
      sensorManager?.unregisterListener(this)
      stepListenerRegistered = false
    }
  }

  override fun onSensorChanged(event: SensorEvent?) {
    when (event?.sensor?.type) {
      Sensor.TYPE_STEP_COUNTER -> {
        val stepsSinceBoot = event.values.firstOrNull()?.toLong() ?: return
        viewModel.onHardwareStepsUpdated(stepsSinceBoot)
      }

      Sensor.TYPE_STEP_DETECTOR -> {
        val ticks = event.values.size.coerceAtLeast(1)
        viewModel.onStepDetectorTicks(ticks)
      }
    }
  }

  override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit

  private fun handlePedometerInteraction(onFeedback: (String) -> Unit) {
    if (!PedometerHelper.hasActivityPermission(this)) {
      requestStepPermissionIfNeeded()
      return
    }
    if (!PedometerHelper.isStepSensorAvailable(this)) {
      onFeedback(getString(R.string.step_sensor_unavailable))
      return
    }
    PedometerSyncJobService.scheduleIfNeeded(this)
    (application as? WidgetsApplication)?.ensureStepMonitoring()
    viewModel.refreshPedometerNow { latest ->
      val feedback = if (latest.stepsToday > 0) {
        getString(R.string.step_synced_msg, latest.stepsToday, latest.dailyGoal)
      } else {
        getString(R.string.step_ready_zero_msg)
      }
      onFeedback(feedback)
    }
  }

  private fun requestStepPermissionIfNeeded() {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q &&
      !PedometerHelper.hasActivityPermission(this)
    ) {
      stepPermissionLauncher.launch(Manifest.permission.ACTIVITY_RECOGNITION)
    }
  }

  private fun registerStepSensorIfAllowed() {
    if (stepListenerRegistered || !PedometerHelper.hasActivityPermission(this)) return
    val manager = sensorManager ?: return
    val stepSensor = manager.getDefaultSensor(Sensor.TYPE_STEP_COUNTER)
      ?: manager.getDefaultSensor(Sensor.TYPE_STEP_DETECTOR)
      ?: return
    stepListenerRegistered = runCatching {
      manager.registerListener(this, stepSensor, SensorManager.SENSOR_DELAY_UI)
    }.getOrDefault(false)
    if (stepListenerRegistered) {
      runCatching { manager.flush(this) }
    }
  }

  private fun requestPinWidget(
    target: PinWidgetTarget,
    onFeedback: (String) -> Unit,
  ) {
    if (target == PinWidgetTarget.PEDOMETER && !PedometerHelper.hasActivityPermission(this)) {
      pendingPinPedometerAfterPermission = true
      requestStepPermissionIfNeeded()
      return
    }
    launchPinWidgetInternal(target, onFeedback)
  }

  private fun launchPinWidgetInternal(
    target: PinWidgetTarget,
    onFeedback: (String) -> Unit,
  ) {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
      val appWidgetManager = AppWidgetManager.getInstance(this)
      val providerClass = when (target) {
        PinWidgetTarget.CALENDAR -> CrayonCalendarWidgetProvider::class.java
        PinWidgetTarget.PEDOMETER -> PedometerWidgetProvider::class.java
        PinWidgetTarget.WIFI -> WifiToggleWidgetProvider::class.java
        PinWidgetTarget.MOBILE_DATA -> MobileDataToggleWidgetProvider::class.java
      }
      val provider = ComponentName(this, providerClass)
      if (appWidgetManager.isRequestPinAppWidgetSupported) {
        val success = appWidgetManager.requestPinAppWidget(provider, null, null)
        if (success) {
          onFeedback(getString(R.string.pin_requested_msg))
          return
        }
      }
    }
    onFeedback(getString(R.string.pin_fallback_msg))
  }

  companion object {
    const val EXTRA_REQUEST_STEP_PERMISSION = "extra_request_step_permission"
  }
}
