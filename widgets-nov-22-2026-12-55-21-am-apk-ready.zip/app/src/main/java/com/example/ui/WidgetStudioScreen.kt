package com.example.ui

import android.graphics.Bitmap
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.DirectionsWalk
import androidx.compose.material.icons.rounded.Apps
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.CalendarToday
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.DoneAll
import androidx.compose.material.icons.rounded.Flip
import androidx.compose.material.icons.rounded.Layers
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.SwapVert
import androidx.compose.material.icons.rounded.TextFields
import androidx.compose.material.icons.rounded.TouchApp
import androidx.compose.material.icons.rounded.Widgets
import androidx.compose.material.icons.rounded.Wifi
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.widget.CrayonFontOption
import com.example.widget.CrayonGlassBalance
import com.example.widget.CrayonIconCategory
import com.example.widget.CrayonIconKind
import com.example.widget.CrayonIconShape
import com.example.widget.CrayonWidgetRenderer
import com.example.widget.GlassThemeOption
import com.example.widget.IconPackBrowseMode
import com.example.widget.InstalledLaunchApp
import com.example.widget.PedometerSnapshot
import com.example.widget.ToggleTileType
import java.util.Calendar

@Composable
fun WidgetStudioScreen(
  uiState: WidgetStudioUiState,
  snackbarHostState: SnackbarHostState,
  onSelectTab: (StudioTab) -> Unit,
  onSelectIconShape: (CrayonIconShape) -> Unit,
  onSelectIconBrowseMode: (IconPackBrowseMode) -> Unit,
  onSelectIconCategory: (CrayonIconCategory) -> Unit,
  onIconSearchQueryChange: (String) -> Unit,
  onToggleUnmappedOnly: (Boolean) -> Unit,
  onSetPreviewDrawerMode: (Boolean) -> Unit,
  onSyncPinnedIcons: () -> Unit,
  onPinAppIcon: (icon: CrayonIconKind?, targetApp: InstalledLaunchApp, customLabel: String) -> Unit,
  onSelectFont: (CrayonFontOption) -> Unit,
  onSelectTheme: (GlassThemeOption) -> Unit,
  onSelectBalance: (CrayonGlassBalance) -> Unit,
  onTogglePage: () -> Unit,
  onSelectPage: (Int) -> Unit,
  onTapPedometer: () -> Unit,
  onToggleWifi: () -> Unit,
  onToggleMobileData: () -> Unit,
  onApplyToAll: () -> Unit,
  onApplyConfigure: (applyToAll: Boolean) -> Unit,
  onPinWidget: (PinWidgetTarget) -> Unit,
) {
  val context = LocalContext.current
  val backdropTop by animateColorAsState(
    targetValue = uiState.selectedTheme.studioBackdropTop,
    animationSpec = spring(stiffness = Spring.StiffnessLow),
    label = "backdropTop",
  )
  val backdropBottom by animateColorAsState(
    targetValue = uiState.selectedTheme.studioBackdropBottom,
    animationSpec = spring(stiffness = Spring.StiffnessLow),
    label = "backdropBottom",
  )
  val accentColor = remember(uiState.selectedTheme) {
    Color(uiState.selectedTheme.accentArgb)
  }

  val calendarBitmap: Bitmap = remember(
    uiState.selectedFont,
    uiState.selectedTheme,
    uiState.selectedBalance,
    uiState.previewPage,
  ) {
    CrayonWidgetRenderer.render(
      context = context,
      settings = uiState.currentSettings,
      widthPx = 840,
      heightPx = 840,
      calendar = Calendar.getInstance(),
    )
  }

  val pedometerBitmap: Bitmap = remember(
    uiState.selectedFont,
    uiState.selectedTheme,
    uiState.selectedBalance,
    uiState.pedometerSnapshot,
  ) {
    CrayonWidgetRenderer.renderPedometerPill(
      context = context,
      snapshot = uiState.pedometerSnapshot,
      settings = uiState.currentSettings,
      widthPx = 840,
      heightPx = 380,
    )
  }

  val wifiBitmap: Bitmap = remember(
    uiState.selectedFont,
    uiState.selectedTheme,
    uiState.selectedBalance,
    uiState.isWifiEnabled,
  ) {
    CrayonWidgetRenderer.renderToggleTile(
      context = context,
      type = ToggleTileType.WIFI,
      isEnabled = uiState.isWifiEnabled,
      settings = uiState.currentSettings,
      widthPx = 480,
      heightPx = 480,
    )
  }

  val dataBitmap: Bitmap = remember(
    uiState.selectedFont,
    uiState.selectedTheme,
    uiState.selectedBalance,
    uiState.isMobileDataEnabled,
  ) {
    CrayonWidgetRenderer.renderToggleTile(
      context = context,
      type = ToggleTileType.MOBILE_DATA,
      isEnabled = uiState.isMobileDataEnabled,
      settings = uiState.currentSettings,
      widthPx = 480,
      heightPx = 480,
    )
  }

  Box(
    modifier = Modifier
      .fillMaxSize()
      .background(
        brush = Brush.verticalGradient(colors = listOf(backdropTop, backdropBottom)),
      )
      .drawBehind {
        drawCircle(
          brush = Brush.radialGradient(
            colors = listOf(accentColor.copy(alpha = 0.28f), Color.Transparent),
            center = Offset(size.width * 0.85f, size.height * 0.14f),
            radius = size.minDimension * 0.7f,
          ),
          radius = size.minDimension * 0.7f,
          center = Offset(size.width * 0.85f, size.height * 0.14f),
        )
        drawCircle(
          brush = Brush.radialGradient(
            colors = listOf(Color(0xFF68D2FF).copy(alpha = 0.14f), Color.Transparent),
            center = Offset(size.width * 0.12f, size.height * 0.42f),
            radius = size.minDimension * 0.6f,
          ),
          radius = size.minDimension * 0.6f,
          center = Offset(size.width * 0.12f, size.height * 0.42f),
        )
      },
  ) {
    val showWidgetBottomBar = uiState.isConfigureMode || uiState.selectedTab == StudioTab.WIDGETS
    if (!uiState.isConfigureMode && uiState.selectedTab == StudioTab.ICON_PACK) {
      BackHandler { onSelectTab(StudioTab.WIDGETS) }
    }

    Scaffold(
      containerColor = Color.Transparent,
      contentWindowInsets = WindowInsets(0, 0, 0, 0),
      snackbarHost = {
        SnackbarHost(
          hostState = snackbarHostState,
          modifier = Modifier.navigationBarsPadding(),
        )
      },
      bottomBar = {
        if (showWidgetBottomBar) {
          StudioBottomActionBar(
            isConfigureMode = uiState.isConfigureMode,
            accentColor = accentColor,
            onApplyConfigure = onApplyConfigure,
            onPinWidget = onPinWidget,
          )
        }
      },
    ) { innerPadding ->
      Column(
        modifier = Modifier
          .fillMaxSize()
          .padding(innerPadding)
          .statusBarsPadding(),
      ) {
        if (!uiState.isConfigureMode) {
          StudioTopTabBar(
            selectedTab = uiState.selectedTab,
            accentColor = accentColor,
            onSelectTab = onSelectTab,
          )
        }

        if (!uiState.isConfigureMode && uiState.selectedTab == StudioTab.ICON_PACK) {
          IconPackTabContent(
            uiState = uiState,
            accentColor = accentColor,
            backdropTop = backdropTop,
            backdropBottom = backdropBottom,
            onSelectShape = onSelectIconShape,
            onSelectBrowseMode = onSelectIconBrowseMode,
            onSelectCategory = onSelectIconCategory,
            onSearchQueryChange = onIconSearchQueryChange,
            onToggleUnmappedOnly = onToggleUnmappedOnly,
            onSetPreviewDrawerMode = onSetPreviewDrawerMode,
            onSelectTheme = onSelectTheme,
            onSelectBalance = onSelectBalance,
            onSyncPinnedIcons = onSyncPinnedIcons,
            onPinAppIcon = onPinAppIcon,
            modifier = Modifier.weight(1f),
          )
        } else {
          BoxWithConstraints(
            modifier = Modifier
              .weight(1f)
              .fillMaxWidth(),
          ) {
            val isWideLayout = maxWidth >= 700.dp
            if (isWideLayout) {
              Row(
                modifier = Modifier
                  .fillMaxSize()
                  .padding(horizontal = 24.dp, vertical = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(24.dp),
              ) {
                Column(
                  modifier = Modifier
                    .weight(0.48f)
                    .fillMaxHeight(),
                  verticalArrangement = Arrangement.Center,
                  horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                  StudioHeader(uiState = uiState, accentColor = accentColor)
                  Spacer(modifier = Modifier.height(14.dp))
                  LiveHomeClusterPreviewCard(
                    calendarBitmap = calendarBitmap,
                    pedometerBitmap = pedometerBitmap,
                    wifiBitmap = wifiBitmap,
                    dataBitmap = dataBitmap,
                    previewPage = uiState.previewPage,
                    selectedBalance = uiState.selectedBalance,
                    isWifiEnabled = uiState.isWifiEnabled,
                    isMobileDataEnabled = uiState.isMobileDataEnabled,
                    pedometerSnapshot = uiState.pedometerSnapshot,
                    accentColor = accentColor,
                    onTogglePage = onTogglePage,
                    onSelectPage = onSelectPage,
                    onTapPedometer = onTapPedometer,
                    onToggleWifi = onToggleWifi,
                    onToggleMobileData = onToggleMobileData,
                  )
                }
                LazyColumn(
                  modifier = Modifier
                    .weight(0.52f)
                    .fillMaxHeight()
                    .background(Brush.verticalGradient(colors = listOf(backdropTop, backdropBottom))),
                  contentPadding = PaddingValues(vertical = 8.dp),
                  verticalArrangement = Arrangement.spacedBy(20.dp),
                ) {
                  item {
                    BalancePickerSection(
                      selectedBalance = uiState.selectedBalance,
                      accentColor = accentColor,
                      onSelectBalance = onSelectBalance,
                    )
                  }
                  item {
                    FontPickerSection(
                      selectedFont = uiState.selectedFont,
                      selectedTheme = uiState.selectedTheme,
                      accentColor = accentColor,
                      onSelectFont = onSelectFont,
                    )
                  }
                  item {
                    ThemePickerSection(
                      selectedTheme = uiState.selectedTheme,
                      activeWidgetCount = uiState.activeWidgetCount,
                      onSelectTheme = onSelectTheme,
                      onApplyToAll = onApplyToAll,
                    )
                  }
                  item {
                    HomeScreenGuideCard()
                  }
                }
              }
            } else {
              LazyColumn(
                modifier = Modifier
                  .fillMaxSize()
                  .background(Brush.verticalGradient(colors = listOf(backdropTop, backdropBottom)))
                  .widthIn(max = 580.dp)
                  .align(Alignment.TopCenter),
                contentPadding = PaddingValues(horizontal = 20.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(20.dp),
              ) {
                item {
                  StudioHeader(uiState = uiState, accentColor = accentColor)
                }
                item {
                  LiveHomeClusterPreviewCard(
                    calendarBitmap = calendarBitmap,
                    pedometerBitmap = pedometerBitmap,
                    wifiBitmap = wifiBitmap,
                    dataBitmap = dataBitmap,
                    previewPage = uiState.previewPage,
                    selectedBalance = uiState.selectedBalance,
                    isWifiEnabled = uiState.isWifiEnabled,
                    isMobileDataEnabled = uiState.isMobileDataEnabled,
                    pedometerSnapshot = uiState.pedometerSnapshot,
                    accentColor = accentColor,
                    onTogglePage = onTogglePage,
                    onSelectPage = onSelectPage,
                    onTapPedometer = onTapPedometer,
                    onToggleWifi = onToggleWifi,
                    onToggleMobileData = onToggleMobileData,
                  )
                }
                item {
                  BalancePickerSection(
                    selectedBalance = uiState.selectedBalance,
                    accentColor = accentColor,
                    onSelectBalance = onSelectBalance,
                  )
                }
                item {
                  FontPickerSection(
                    selectedFont = uiState.selectedFont,
                    selectedTheme = uiState.selectedTheme,
                    accentColor = accentColor,
                    onSelectFont = onSelectFont,
                  )
                }
                item {
                  ThemePickerSection(
                    selectedTheme = uiState.selectedTheme,
                    activeWidgetCount = uiState.activeWidgetCount,
                    onSelectTheme = onSelectTheme,
                    onApplyToAll = onApplyToAll,
                  )
                }
                item {
                  HomeScreenGuideCard()
                }
              }
            }
          }
        }
      }
    }
  }
}

@Composable
private fun StudioTopTabBar(
  selectedTab: StudioTab,
  accentColor: Color,
  onSelectTab: (StudioTab) -> Unit,
) {
  Box(
    modifier = Modifier
      .fillMaxWidth()
      .padding(horizontal = 20.dp, vertical = 8.dp),
    contentAlignment = Alignment.Center,
  ) {
    Surface(
      modifier = Modifier
        .fillMaxWidth()
        .widthIn(max = 420.dp),
      shape = RoundedCornerShape(50),
      color = Color.White.copy(alpha = 0.08f),
      border = BorderStroke(1.dp, Color.White.copy(alpha = 0.16f)),
    ) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(4.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
      ) {
        StudioTabPill(
          label = stringResource(R.string.tab_widgets),
          icon = Icons.Rounded.Widgets,
          selected = selectedTab == StudioTab.WIDGETS,
          accentColor = accentColor,
          testTag = "studio_tab_widgets",
          onClick = { onSelectTab(StudioTab.WIDGETS) },
          modifier = Modifier.weight(1f),
        )
        StudioTabPill(
          label = stringResource(R.string.tab_icon_pack),
          icon = Icons.Rounded.Apps,
          selected = selectedTab == StudioTab.ICON_PACK,
          accentColor = accentColor,
          testTag = "studio_tab_icon_pack",
          onClick = { onSelectTab(StudioTab.ICON_PACK) },
          modifier = Modifier.weight(1f),
        )
      }
    }
  }
}

@Composable
private fun StudioTabPill(
  label: String,
  icon: ImageVector,
  selected: Boolean,
  accentColor: Color,
  testTag: String,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
) {
  Surface(
    modifier = modifier
      .minimumInteractiveComponentSize()
      .clip(RoundedCornerShape(50))
      .clickable(onClick = onClick)
      .testTag(testTag),
    shape = RoundedCornerShape(50),
    color = if (selected) accentColor.copy(alpha = 0.28f) else Color.Transparent,
    border = if (selected) BorderStroke(1.2.dp, accentColor) else null,
  ) {
    Row(
      modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
      horizontalArrangement = Arrangement.Center,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Icon(
        imageVector = icon,
        contentDescription = null,
        tint = if (selected) accentColor else MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.size(17.dp),
      )
      Spacer(modifier = Modifier.width(6.dp))
      Text(
        text = label,
        style = MaterialTheme.typography.labelLarge,
        color = if (selected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
      )
    }
  }
}

@Composable
private fun StudioHeader(
  uiState: WidgetStudioUiState,
  accentColor: Color,
) {
  Row(
    modifier = Modifier.fillMaxWidth(),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.CenterVertically,
  ) {
    Column(modifier = Modifier.weight(1f)) {
      Text(
        text = stringResource(R.string.app_name),
        style = MaterialTheme.typography.headlineMedium,
        color = MaterialTheme.colorScheme.onBackground,
      )
      Spacer(modifier = Modifier.height(2.dp))
      Text(
        text = stringResource(R.string.widget_description),
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
      )
    }
    Surface(
      shape = RoundedCornerShape(50),
      color = accentColor.copy(alpha = 0.18f),
      border = BorderStroke(1.dp, accentColor.copy(alpha = 0.55f)),
    ) {
      Row(
        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp),
      ) {
        Icon(
          imageVector = Icons.Rounded.AutoAwesome,
          contentDescription = null,
          tint = accentColor,
          modifier = Modifier.size(14.dp),
        )
        Text(
          text = if (uiState.isConfigureMode) {
            "Widget #${uiState.appWidgetId}"
          } else {
            uiState.selectedBalance.displayName
          },
          style = MaterialTheme.typography.labelSmall,
          color = MaterialTheme.colorScheme.onBackground,
        )
      }
    }
  }
}

@Composable
private fun LiveHomeClusterPreviewCard(
  calendarBitmap: Bitmap,
  pedometerBitmap: Bitmap,
  wifiBitmap: Bitmap,
  dataBitmap: Bitmap,
  previewPage: Int,
  selectedBalance: CrayonGlassBalance,
  isWifiEnabled: Boolean,
  isMobileDataEnabled: Boolean,
  pedometerSnapshot: PedometerSnapshot,
  accentColor: Color,
  onTogglePage: () -> Unit,
  onSelectPage: (Int) -> Unit,
  onTapPedometer: () -> Unit,
  onToggleWifi: () -> Unit,
  onToggleMobileData: () -> Unit,
) {
  val haptic = LocalHapticFeedback.current
  val scale by animateFloatAsState(
    targetValue = if (previewPage == 0) 1f else 0.99f,
    animationSpec = spring(
      dampingRatio = Spring.DampingRatioMediumBouncy,
      stiffness = Spring.StiffnessMedium,
    ),
    label = "previewScale",
  )

  Surface(
    modifier = Modifier.fillMaxWidth(),
    shape = RoundedCornerShape(30.dp),
    color = Color(0xE6151925),
    border = BorderStroke(1.dp, Color.White.copy(alpha = 0.16f)),
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(16.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Text(
          text = stringResource(R.string.preview_section_title),
          style = MaterialTheme.typography.titleMedium,
          color = MaterialTheme.colorScheme.onBackground,
        )

        Row(
          horizontalArrangement = Arrangement.spacedBy(6.dp),
          verticalAlignment = Alignment.CenterVertically,
        ) {
          PagePillButton(
            label = stringResource(R.string.page_one_label),
            selected = previewPage == 0,
            accentColor = accentColor,
            testTag = "page_one_chip",
            onClick = { onSelectPage(0) },
          )
          PagePillButton(
            label = stringResource(R.string.page_two_label),
            selected = previewPage == 1,
            accentColor = accentColor,
            testTag = "page_two_chip",
            onClick = { onSelectPage(1) },
          )
        }
      }

      Spacer(modifier = Modifier.height(14.dp))

      // Home-screen cluster stage:
      // Row 1-2: 2x2 Calendar + two circular 1x1 Wi-Fi / Mobile Data orbs
      // Row 3: 2x1 Pill Pedometer + live balance/permission pill
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .widthIn(max = 360.dp)
          .clip(RoundedCornerShape(28.dp)),
        contentAlignment = Alignment.Center,
      ) {
        WallpaperMeshBackdrop(
          accentColor = accentColor,
          modifier = Modifier.matchParentSize(),
        )

        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(12.dp),
          verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .height(IntrinsicSize.Min),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Box(
              modifier = Modifier
                .weight(2f)
                .aspectRatio(1f)
                .scale(scale)
                .clip(RoundedCornerShape(24.dp))
                .clickable(
                  interactionSource = remember { MutableInteractionSource() },
                  indication = null,
                  onClick = {
                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                    onTogglePage()
                  },
                )
                .testTag("widget_live_preview"),
              contentAlignment = Alignment.Center,
            ) {
              AnimatedContent(
                targetState = calendarBitmap,
                transitionSpec = {
                  (fadeIn(animationSpec = spring(stiffness = Spring.StiffnessMediumLow)) +
                    scaleIn(initialScale = 0.96f)) togetherWith
                    fadeOut(animationSpec = spring(stiffness = Spring.StiffnessMedium))
                },
                label = "widgetBitmapFlip",
              ) { rendered ->
                Image(
                  bitmap = rendered.asImageBitmap(),
                  contentDescription = stringResource(R.string.calendar_widget_label),
                  modifier = Modifier.fillMaxSize(),
                )
              }
            }

            Column(
              modifier = Modifier
                .weight(1f)
                .fillMaxHeight(),
              verticalArrangement = Arrangement.spacedBy(10.dp, Alignment.CenterVertically),
              horizontalAlignment = Alignment.CenterHorizontally,
            ) {
              Box(
                modifier = Modifier
                  .fillMaxWidth()
                  .aspectRatio(1f)
                  .clip(CircleShape)
                  .clickable(
                    onClick = {
                      haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                      onToggleWifi()
                    },
                  )
                  .testTag("wifi_preview_tile"),
                contentAlignment = Alignment.Center,
              ) {
                Image(
                  bitmap = wifiBitmap.asImageBitmap(),
                  contentDescription = stringResource(R.string.wifi_widget_label),
                  modifier = Modifier.fillMaxSize(),
                )
              }

              Box(
                modifier = Modifier
                  .fillMaxWidth()
                  .aspectRatio(1f)
                  .clip(CircleShape)
                  .clickable(
                    onClick = {
                      haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                      onToggleMobileData()
                    },
                  )
                  .testTag("mobile_data_preview_tile"),
                contentAlignment = Alignment.Center,
              ) {
                Image(
                  bitmap = dataBitmap.asImageBitmap(),
                  contentDescription = stringResource(R.string.mobile_data_widget_label),
                  modifier = Modifier.fillMaxSize(),
                )
              }
            }
          }

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Box(
              modifier = Modifier
                .weight(2f)
                .aspectRatio(2.21f)
                .clip(CircleShape)
                .clickable(
                  onClick = {
                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                    onTapPedometer()
                  },
                )
                .testTag("pedometer_preview_pill"),
              contentAlignment = Alignment.Center,
            ) {
              Image(
                bitmap = pedometerBitmap.asImageBitmap(),
                contentDescription = stringResource(R.string.pedometer_widget_label),
                modifier = Modifier.fillMaxSize(),
              )
            }

            Surface(
              modifier = Modifier
                .weight(1f)
                .aspectRatio(1.10f)
                .clip(RoundedCornerShape(22.dp))
                .clickable(
                  enabled = !pedometerSnapshot.hasPermission,
                  onClick = onTapPedometer,
                ),
              shape = RoundedCornerShape(22.dp),
              color = if (!pedometerSnapshot.hasPermission) {
                accentColor.copy(alpha = 0.24f)
              } else {
                Color.White.copy(alpha = 0.10f)
              },
              border = BorderStroke(
                width = 1.dp,
                color = if (!pedometerSnapshot.hasPermission) {
                  accentColor.copy(alpha = 0.72f)
                } else {
                  Color.White.copy(alpha = 0.20f)
                },
              ),
            ) {
              Column(
                modifier = Modifier
                  .fillMaxSize()
                  .padding(8.dp),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally,
              ) {
                Icon(
                  imageVector = Icons.AutoMirrored.Rounded.DirectionsWalk,
                  contentDescription = null,
                  tint = accentColor,
                  modifier = Modifier.size(18.dp),
                )
                Spacer(modifier = Modifier.height(3.dp))
                Text(
                  text = if (!pedometerSnapshot.hasPermission) {
                    stringResource(R.string.step_permission_grant_cta)
                  } else {
                    selectedBalance.shortLabel
                  },
                  style = MaterialTheme.typography.labelSmall,
                  color = Color.White,
                  maxLines = 1,
                  overflow = TextOverflow.Ellipsis,
                )
              }
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(10.dp))

      val pedometerCaption = when {
        !pedometerSnapshot.hasPermission -> "Steps: Allow Activity"
        !pedometerSnapshot.isSensorAvailable -> "Steps: No sensor"
        else -> "Steps: ${pedometerSnapshot.stepsToday}"
      }
      Text(
        text = "Wi-Fi: ${if (isWifiEnabled) "ON" else "OFF"}  ·  Data: ${if (isMobileDataEnabled) "ON" else "OFF"}  ·  $pedometerCaption",
        style = MaterialTheme.typography.labelSmall,
        color = accentColor,
      )

      Spacer(modifier = Modifier.height(4.dp))

      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp),
      ) {
        Icon(
          imageVector = Icons.Rounded.Flip,
          contentDescription = null,
          tint = MaterialTheme.colorScheme.onSurfaceVariant,
          modifier = Modifier.size(15.dp),
        )
        Text(
          text = stringResource(R.string.preview_tap_hint),
          style = MaterialTheme.typography.bodyMedium,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
      }
    }
  }
}

@Composable
private fun WallpaperMeshBackdrop(
  accentColor: Color,
  modifier: Modifier = Modifier,
) {
  Canvas(modifier = modifier) {
    drawRect(
      brush = Brush.linearGradient(
        colors = listOf(
          Color(0xFF1D2233),
          Color(0xFF283149),
          Color(0xFF1A2538),
        ),
        start = Offset.Zero,
        end = Offset(size.width, size.height),
      ),
    )
    drawCircle(
      brush = Brush.radialGradient(
        colors = listOf(accentColor.copy(alpha = 0.25f), Color.Transparent),
        center = Offset(size.width * 0.80f, size.height * 0.25f),
        radius = size.minDimension * 0.65f,
      ),
      radius = size.minDimension * 0.65f,
      center = Offset(size.width * 0.80f, size.height * 0.25f),
    )
    drawCircle(
      brush = Brush.radialGradient(
        colors = listOf(Color(0xFF68D2FF).copy(alpha = 0.18f), Color.Transparent),
        center = Offset(size.width * 0.20f, size.height * 0.80f),
        radius = size.minDimension * 0.55f,
      ),
      radius = size.minDimension * 0.55f,
      center = Offset(size.width * 0.20f, size.height * 0.80f),
    )
  }
}

@Composable
private fun BalancePickerSection(
  selectedBalance: CrayonGlassBalance,
  accentColor: Color,
  onSelectBalance: (CrayonGlassBalance) -> Unit,
) {
  Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
    Row(
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
      Icon(
        imageVector = Icons.Rounded.Layers,
        contentDescription = null,
        tint = accentColor,
        modifier = Modifier.size(20.dp),
      )
      Text(
        text = stringResource(R.string.balance_section_title),
        style = MaterialTheme.typography.titleMedium,
        color = MaterialTheme.colorScheme.onBackground,
      )
    }

    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
      CrayonGlassBalance.entries.forEach { balance ->
        val selected = balance == selectedBalance
        Surface(
          modifier = Modifier
            .weight(1f)
            .minimumInteractiveComponentSize()
            .clip(RoundedCornerShape(18.dp))
            .clickable { onSelectBalance(balance) }
            .testTag("balance_card_${balance.id}"),
          shape = RoundedCornerShape(18.dp),
          color = if (selected) accentColor.copy(alpha = 0.24f) else Color(0xE6151925),
          border = BorderStroke(
            width = if (selected) 1.6.dp else 1.dp,
            color = if (selected) accentColor else Color.White.copy(alpha = 0.18f),
          ),
        ) {
          Column(
            modifier = Modifier
              .fillMaxWidth()
              .padding(horizontal = 10.dp, vertical = 11.dp),
            verticalArrangement = Arrangement.spacedBy(3.dp),
          ) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Text(
                text = balance.shortLabel,
                style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.onBackground,
                maxLines = 1,
              )
              if (selected) {
                Icon(
                  imageVector = Icons.Rounded.Check,
                  contentDescription = "Selected",
                  tint = accentColor,
                  modifier = Modifier.size(15.dp),
                )
              }
            }
            Text(
              text = "${balance.crayonPercent}% Crayon",
              style = MaterialTheme.typography.labelSmall,
              color = if (selected) accentColor else MaterialTheme.colorScheme.onSurfaceVariant,
              maxLines = 1,
              overflow = TextOverflow.Ellipsis,
            )
            Text(
              text = "${balance.glassPercent}% Glass",
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
              maxLines = 1,
              overflow = TextOverflow.Ellipsis,
            )
          }
        }
      }
    }
  }
}

@Composable
private fun PagePillButton(
  label: String,
  selected: Boolean,
  accentColor: Color,
  testTag: String,
  onClick: () -> Unit,
) {
  Surface(
    modifier = Modifier
      .minimumInteractiveComponentSize()
      .clip(RoundedCornerShape(50))
      .clickable(onClick = onClick)
      .testTag(testTag),
    shape = RoundedCornerShape(50),
    color = if (selected) accentColor.copy(alpha = 0.24f) else Color.White.copy(alpha = 0.08f),
    border = BorderStroke(
      width = 1.dp,
      color = if (selected) accentColor.copy(alpha = 0.78f) else Color.White.copy(alpha = 0.16f),
    ),
  ) {
    Text(
      text = label,
      style = MaterialTheme.typography.labelSmall,
      color = if (selected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
      modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
    )
  }
}

@Composable
private fun FontPickerSection(
  selectedFont: CrayonFontOption,
  selectedTheme: GlassThemeOption,
  accentColor: Color,
  onSelectFont: (CrayonFontOption) -> Unit,
) {
  Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
    Row(
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
      Icon(
        imageVector = Icons.Rounded.TextFields,
        contentDescription = null,
        tint = accentColor,
        modifier = Modifier.size(20.dp),
      )
      Text(
        text = stringResource(R.string.fonts_section_title),
        style = MaterialTheme.typography.titleMedium,
        color = MaterialTheme.colorScheme.onBackground,
      )
    }

    val rows = CrayonFontOption.entries.chunked(2)
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
      rows.forEach { pair ->
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
          pair.forEach { fontOption ->
            FontSpecimenCard(
              option = fontOption,
              selectedTheme = selectedTheme,
              selected = fontOption == selectedFont,
              accentColor = accentColor,
              onClick = { onSelectFont(fontOption) },
              modifier = Modifier.weight(1f),
            )
          }
        }
      }
    }
  }
}

@Composable
private fun FontSpecimenCard(
  option: CrayonFontOption,
  selectedTheme: GlassThemeOption,
  selected: Boolean,
  accentColor: Color,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val context = LocalContext.current
  val fontFamily = remember(option.fontResId) {
    FontFamily(Font(option.fontResId, FontWeight.Normal))
  }
  val specimenBitmap = remember(option, selectedTheme) {
    CrayonWidgetRenderer.renderFontSpecimen(
      context = context,
      fontOption = option,
      inkArgb = selectedTheme.inkPrimaryArgb,
      accentArgb = selectedTheme.accentArgb,
      sizePx = 128,
    )
  }

  Surface(
    modifier = modifier
      .minimumInteractiveComponentSize()
      .clip(RoundedCornerShape(22.dp))
      .clickable(onClick = onClick)
      .testTag("font_card_${option.id}"),
    shape = RoundedCornerShape(22.dp),
    color = if (selected) accentColor.copy(alpha = 0.24f) else Color(0xE6151925),
    border = BorderStroke(
      width = if (selected) 1.6.dp else 1.dp,
      color = if (selected) accentColor else Color.White.copy(alpha = 0.18f),
    ),
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 12.dp, vertical = 10.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
      Box(
        modifier = Modifier
          .size(48.dp)
          .clip(RoundedCornerShape(15.dp))
          .background(
            Brush.linearGradient(
              colors = listOf(
                Color(selectedTheme.glassTopArgb),
                Color(selectedTheme.glassBottomArgb),
              ),
            ),
          )
          .border(1.1.dp, Color(selectedTheme.rimHighlightArgb), RoundedCornerShape(15.dp)),
        contentAlignment = Alignment.Center,
      ) {
        Image(
          bitmap = specimenBitmap.asImageBitmap(),
          contentDescription = option.displayName,
          modifier = Modifier.size(42.dp),
        )
      }

      Column(modifier = Modifier.weight(1f)) {
        Text(
          text = option.displayName,
          fontFamily = fontFamily,
          fontSize = 16.sp,
          color = MaterialTheme.colorScheme.onBackground,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
        )
        Text(
          text = option.subtitle,
          style = MaterialTheme.typography.labelSmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
        )
      }
    }
  }
}

@Composable
private fun ThemePickerSection(
  selectedTheme: GlassThemeOption,
  activeWidgetCount: Int,
  onSelectTheme: (GlassThemeOption) -> Unit,
  onApplyToAll: () -> Unit,
) {
  val accentColor = remember(selectedTheme) { Color(selectedTheme.accentArgb) }
  Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween,
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.weight(1f),
      ) {
        Icon(
          imageVector = Icons.Rounded.Palette,
          contentDescription = null,
          tint = accentColor,
          modifier = Modifier.size(20.dp),
        )
        Text(
          text = stringResource(R.string.themes_section_title),
          style = MaterialTheme.typography.titleMedium,
          color = MaterialTheme.colorScheme.onBackground,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
        )
      }

      Surface(
        modifier = Modifier
          .minimumInteractiveComponentSize()
          .clip(RoundedCornerShape(50))
          .clickable(onClick = onApplyToAll)
          .testTag("apply_all_widgets_button"),
        shape = RoundedCornerShape(50),
        color = accentColor.copy(alpha = 0.22f),
        border = BorderStroke(1.dp, accentColor.copy(alpha = 0.72f)),
      ) {
        Row(
          modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(5.dp),
        ) {
          Icon(
            imageVector = Icons.Rounded.DoneAll,
            contentDescription = null,
            tint = accentColor,
            modifier = Modifier.size(15.dp),
          )
          Text(
            text = if (activeWidgetCount > 0) {
              "${stringResource(R.string.apply_to_all_widgets)} ($activeWidgetCount)"
            } else {
              stringResource(R.string.apply_to_all_widgets)
            },
            style = MaterialTheme.typography.labelSmall,
            color = Color.White,
          )
        }
      }
    }

    val rows = GlassThemeOption.entries.chunked(2)
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
      rows.forEach { pair ->
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
          pair.forEach { themeOption ->
            ThemeSwatchCard(
              option = themeOption,
              selected = themeOption == selectedTheme,
              onClick = { onSelectTheme(themeOption) },
              modifier = Modifier.weight(1f),
            )
          }
        }
      }
    }
  }
}

@Composable
private fun ThemeSwatchCard(
  option: GlassThemeOption,
  selected: Boolean,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val accentColor = remember(option) { Color(option.accentArgb) }
  val primaryCrayonColor = remember(option) { Color(option.inkPrimaryArgb) }
  val secondaryCrayonColor = remember(option) { Color(option.inkSecondaryArgb) }
  val glassBrush = remember(option) {
    Brush.linearGradient(
      colors = listOf(Color(option.glassTopArgb), Color(option.glassBottomArgb)),
    )
  }

  Surface(
    modifier = modifier
      .minimumInteractiveComponentSize()
      .clip(RoundedCornerShape(22.dp))
      .clickable(onClick = onClick)
      .testTag("theme_card_${option.id}"),
    shape = RoundedCornerShape(22.dp),
    color = if (selected) accentColor.copy(alpha = 0.24f) else Color(0xE6151925),
    border = BorderStroke(
      width = if (selected) 1.6.dp else 1.dp,
      color = if (selected) accentColor else Color.White.copy(alpha = 0.18f),
    ),
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 12.dp, vertical = 12.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
      Box(
        modifier = Modifier
          .size(46.dp)
          .clip(RoundedCornerShape(14.dp))
          .background(glassBrush)
          .border(1.4.dp, Color(option.rimHighlightArgb), RoundedCornerShape(14.dp)),
        contentAlignment = Alignment.Center,
      ) {
        Row(
          horizontalArrangement = Arrangement.spacedBy((-5).dp),
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Box(
            modifier = Modifier
              .size(13.dp)
              .clip(CircleShape)
              .background(primaryCrayonColor)
              .border(1.dp, Color.White.copy(alpha = 0.65f), CircleShape),
          )
          Box(
            modifier = Modifier
              .size(13.dp)
              .clip(CircleShape)
              .background(secondaryCrayonColor)
              .border(1.dp, Color.White.copy(alpha = 0.65f), CircleShape),
          )
          Box(
            modifier = Modifier
              .size(13.dp)
              .clip(CircleShape)
              .background(accentColor)
              .border(1.dp, Color.White.copy(alpha = 0.75f), CircleShape),
          )
        }
      }

      Column(modifier = Modifier.weight(1f)) {
        Text(
          text = option.displayName,
          style = MaterialTheme.typography.labelLarge,
          color = MaterialTheme.colorScheme.onBackground,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
        )
        Text(
          text = option.subtitle,
          style = MaterialTheme.typography.labelSmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
        )
      }

      if (selected) {
        Icon(
          imageVector = Icons.Rounded.Check,
          contentDescription = "Selected",
          tint = accentColor,
          modifier = Modifier.size(18.dp),
        )
      }
    }
  }
}

@Composable
private fun HomeScreenGuideCard() {
  Surface(
    modifier = Modifier.fillMaxWidth(),
    shape = RoundedCornerShape(22.dp),
    color = Color(0xE6151925),
    border = BorderStroke(1.dp, Color.White.copy(alpha = 0.14f)),
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(16.dp),
      horizontalArrangement = Arrangement.spacedBy(12.dp),
      verticalAlignment = Alignment.Top,
    ) {
      Icon(
        imageVector = Icons.Rounded.TouchApp,
        contentDescription = null,
        tint = MaterialTheme.colorScheme.secondary,
        modifier = Modifier.size(22.dp),
      )
      Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(
          text = stringResource(R.string.setup_guide_title),
          style = MaterialTheme.typography.titleMedium,
          color = MaterialTheme.colorScheme.onBackground,
        )
        Text(
          text = stringResource(R.string.setup_guide_body),
          style = MaterialTheme.typography.bodyMedium,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
      }
    }
  }
}

@Composable
private fun StudioBottomActionBar(
  isConfigureMode: Boolean,
  accentColor: Color,
  onApplyConfigure: (applyToAll: Boolean) -> Unit,
  onPinWidget: (PinWidgetTarget) -> Unit,
) {
  val onAccentColor = remember(accentColor) {
    if (accentColor.luminance() > 0.52f) Color(0xFF1A1614) else Color.White
  }
  Surface(
    color = Color(0xCC0D1220),
    border = BorderStroke(1.dp, Color.White.copy(alpha = 0.14f)),
  ) {
    Box(
      modifier = Modifier
        .fillMaxWidth()
        .navigationBarsPadding()
        .padding(horizontal = 16.dp, vertical = 12.dp),
      contentAlignment = Alignment.Center,
    ) {
      if (isConfigureMode) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .widthIn(max = 560.dp),
          horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
          OutlinedButton(
            onClick = { onApplyConfigure(false) },
            modifier = Modifier
              .weight(1f)
              .height(52.dp)
              .testTag("apply_widget_button"),
            shape = RoundedCornerShape(18.dp),
            border = BorderStroke(1.2.dp, Color.White.copy(alpha = 0.28f)),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
          ) {
            Icon(
              imageVector = Icons.Rounded.Check,
              contentDescription = null,
              modifier = Modifier.size(18.dp),
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = stringResource(R.string.apply_to_widget),
              style = MaterialTheme.typography.labelLarge,
              maxLines = 1,
              overflow = TextOverflow.Ellipsis,
            )
          }
          Button(
            onClick = { onApplyConfigure(true) },
            modifier = Modifier
              .weight(1.15f)
              .height(52.dp)
              .testTag("apply_all_configure_button"),
            shape = RoundedCornerShape(18.dp),
            colors = ButtonDefaults.buttonColors(
              containerColor = accentColor,
              contentColor = onAccentColor,
            ),
          ) {
            Icon(
              imageVector = Icons.Rounded.DoneAll,
              contentDescription = null,
              modifier = Modifier.size(18.dp),
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = stringResource(R.string.apply_to_all_widgets),
              style = MaterialTheme.typography.labelLarge,
              maxLines = 1,
              overflow = TextOverflow.Ellipsis,
            )
          }
        }
      } else {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .widthIn(max = 580.dp),
          horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
          PinTileButton(
            label = stringResource(R.string.pin_calendar_short),
            icon = Icons.Rounded.CalendarToday,
            accentColor = accentColor,
            isPrimary = true,
            testTag = "pin_calendar_button",
            onClick = { onPinWidget(PinWidgetTarget.CALENDAR) },
            modifier = Modifier.weight(1.05f),
          )
          PinTileButton(
            label = stringResource(R.string.pin_pedometer_short),
            icon = Icons.AutoMirrored.Rounded.DirectionsWalk,
            accentColor = accentColor,
            isPrimary = false,
            testTag = "pin_pedometer_button",
            onClick = { onPinWidget(PinWidgetTarget.PEDOMETER) },
            modifier = Modifier.weight(1.1f),
          )
          PinTileButton(
            label = stringResource(R.string.pin_wifi_short),
            icon = Icons.Rounded.Wifi,
            accentColor = accentColor,
            isPrimary = false,
            testTag = "pin_wifi_button",
            onClick = { onPinWidget(PinWidgetTarget.WIFI) },
            modifier = Modifier.weight(0.92f),
          )
          PinTileButton(
            label = stringResource(R.string.pin_data_short),
            icon = Icons.Rounded.SwapVert,
            accentColor = accentColor,
            isPrimary = false,
            testTag = "pin_data_button",
            onClick = { onPinWidget(PinWidgetTarget.MOBILE_DATA) },
            modifier = Modifier.weight(0.92f),
          )
        }
      }
    }
  }
}

@Composable
private fun PinTileButton(
  label: String,
  icon: ImageVector,
  accentColor: Color,
  isPrimary: Boolean,
  testTag: String,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
) {
  Surface(
    modifier = modifier
      .height(50.dp)
      .clip(RoundedCornerShape(16.dp))
      .clickable(onClick = onClick)
      .testTag(testTag),
    shape = RoundedCornerShape(16.dp),
    color = if (isPrimary) accentColor else Color.White.copy(alpha = 0.11f),
    border = if (isPrimary) null else BorderStroke(1.dp, Color.White.copy(alpha = 0.20f)),
  ) {
    Row(
      modifier = Modifier
        .fillMaxSize()
        .padding(horizontal = 8.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(5.dp, Alignment.CenterHorizontally),
    ) {
      Icon(
        imageVector = icon,
        contentDescription = null,
        tint = Color.White,
        modifier = Modifier.size(16.dp),
      )
      Text(
        text = label,
        style = MaterialTheme.typography.labelSmall,
        color = Color.White,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
      )
    }
  }
}
