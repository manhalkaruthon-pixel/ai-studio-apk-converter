package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val StudioObsidian = Color(0xFF0E1320)
val StudioSurface = Color(0xFF171E31)
val StudioSurfaceVariant = Color(0xFF222B45)
val StudioCoralAccent = Color(0xFFFF6A5E)
val StudioSkySecondary = Color(0xFF68D2FF)
val StudioLilacTertiary = Color(0xFFB89CFF)
val StudioTextPrimary = Color(0xFFF4F7FF)
val StudioTextMuted = Color(0xFFA7B3CE)
val StudioGlassBorder = Color(0x38FFFFFF)
