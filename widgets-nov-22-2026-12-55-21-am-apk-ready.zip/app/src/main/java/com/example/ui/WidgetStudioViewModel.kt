package com.example.ui

import android.app.Application
import android.appwidget.AppWidgetManager
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.CrayonCalendarWidgetProvider
import com.example.MobileDataToggleWidgetProvider
import com.example.PedometerSyncJobService
import com.example.PedometerWidgetProvider
import com.example.WidgetsApplication
import com.example.WifiToggleWidgetProvider
import com.example.widget.ConnectivityHelper
import com.example.widget.CrayonFontOption
import com.example.widget.CrayonGlassBalance
import com.example.widget.CrayonIconCategory
import com.example.widget.CrayonIconShape
import com.example.widget.GlassThemeOption
import com.example.widget.IconPackBrowseMode
import com.example.widget.InstalledAppsHelper
import com.example.widget.InstalledLaunchApp
import com.example.widget.PedometerHelper
import com.example.widget.PedometerSnapshot
import com.example.widget.WidgetPreferences
import com.example.widget.WidgetSettings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

enum class PinWidgetTarget {
  CALENDAR,
  PEDOMETER,
  WIFI,
  MOBILE_DATA,
}

enum class StudioTab {
  WIDGETS,
  ICON_PACK,
}

data class WidgetStudioUiState(
  val appWidgetId: Int = AppWidgetManager.INVALID_APPWIDGET_ID,
  val isConfigureMode: Boolean = false,
  val selectedTab: StudioTab = StudioTab.WIDGETS,
  val selectedFont: CrayonFontOption = CrayonFontOption.FINGER_PAINT,
  val selectedTheme: GlassThemeOption = GlassThemeOption.WARM_VERMILION,
  val selectedBalance: CrayonGlassBalance = CrayonGlassBalance.CRAYON_80_GLASS_20,
  val selectedIconShape: CrayonIconShape = CrayonIconShape.SQUIRCLE,
  val iconBrowseMode: IconPackBrowseMode = IconPackBrowseMode.INSTALLED_APPS,
  val selectedIconCategory: CrayonIconCategory = CrayonIconCategory.ALL,
  val iconSearchQuery: String = "",
  val installedApps: List<InstalledLaunchApp> = emptyList(),
  val appfilterComponents: Set<String> = emptySet(),
  val showUnmappedOnly: Boolean = false,
  val previewDrawerStaticMode: Boolean = false,
  val isLoadingApps: Boolean = false,
  val pinnedIconCount: Int = 0,
  val pinnedPackageNames: Set<String> = emptySet(),
  val previewPage: Int = 0,
  val activeWidgetCount: Int = 0,
  val isWifiEnabled: Boolean = true,
  val isMobileDataEnabled: Boolean = true,
  val pedometerSnapshot: PedometerSnapshot = PedometerSnapshot(),
  val stepPermissionDenied: Boolean = false,
) {
  val currentSettings: WidgetSettings
    get() = WidgetSettings(
      font = selectedFont,
      theme = selectedTheme,
      balance = selectedBalance,
      page = previewPage,
    )
}

class WidgetStudioViewModel(application: Application) : AndroidViewModel(application) {
  private val _uiState = MutableStateFlow(WidgetStudioUiState())
  val uiState: StateFlow<WidgetStudioUiState> = _uiState.asStateFlow()
  private var iconSyncJob: Job? = null

  fun initialize(appWidgetId: Int) {
    val context = getApplication<Application>()
    val isConfigure = appWidgetId != AppWidgetManager.INVALID_APPWIDGET_ID
    val initialFont: CrayonFontOption
    val initialTheme: GlassThemeOption
    val initialBalance: CrayonGlassBalance
    val initialPage: Int

    if (isConfigure) {
      val existing = WidgetPreferences.getSettingsForWidget(context, appWidgetId)
      initialFont = existing.font
      initialTheme = existing.theme
      initialBalance = existing.balance
      initialPage = existing.page
    } else {
      initialFont = WidgetPreferences.getDefaultFont(context)
      initialTheme = WidgetPreferences.getDefaultTheme(context)
      initialBalance = WidgetPreferences.getDefaultBalance(context)
      initialPage = 0
    }

    val snapshot = PedometerHelper.getStepSnapshot(context)
    val initialIconShape = WidgetPreferences.getDefaultIconShape(context)
    val current = _uiState.value
    _uiState.value = WidgetStudioUiState(
      appWidgetId = appWidgetId,
      isConfigureMode = isConfigure,
      selectedTab = if (isConfigure) StudioTab.WIDGETS else current.selectedTab,
      selectedFont = initialFont,
      selectedTheme = initialTheme,
      selectedBalance = initialBalance,
      selectedIconShape = initialIconShape,
      iconBrowseMode = current.iconBrowseMode,
      selectedIconCategory = current.selectedIconCategory,
      iconSearchQuery = current.iconSearchQuery,
      installedApps = current.installedApps,
      appfilterComponents = current.appfilterComponents,
      showUnmappedOnly = current.showUnmappedOnly,
      previewDrawerStaticMode = current.previewDrawerStaticMode,
      isLoadingApps = current.installedApps.isEmpty(),
      pinnedIconCount = current.pinnedIconCount,
      pinnedPackageNames = current.pinnedPackageNames,
      previewPage = initialPage,
      activeWidgetCount = getAllActiveWidgetIds().size,
      isWifiEnabled = ConnectivityHelper.isWifiEnabled(context),
      isMobileDataEnabled = ConnectivityHelper.isMobileDataEnabled(context),
      pedometerSnapshot = snapshot,
    )
    if (snapshot.hasPermission && snapshot.isSensorAvailable) {
      PedometerSyncJobService.scheduleIfNeeded(context)
      (context as? WidgetsApplication)?.ensureStepMonitoring()
      refreshPedometerNow()
    }
    if (!isConfigure) {
      loadInstalledApps()
      refreshPinnedIconState()
    }
  }

  fun loadInstalledApps() {
    val context = getApplication<Application>()
    _uiState.update { it.copy(isLoadingApps = it.installedApps.isEmpty()) }
    viewModelScope.launch(Dispatchers.IO) {
      val apps = InstalledAppsHelper.loadLaunchableApps(context)
      val components = InstalledAppsHelper.loadAppfilterComponents(context)
      _uiState.update {
        it.copy(
          installedApps = apps,
          appfilterComponents = components,
          isLoadingApps = false,
        )
      }
    }
  }

  fun refreshPinnedIconState() {
    val context = getApplication<Application>()
    viewModelScope.launch(Dispatchers.IO) {
      val tracked = InstalledAppsHelper.getTrackedPinnedIcons(context)
      val pkgs = tracked.map { it.packageName }.toSet()
      _uiState.update {
        it.copy(
          pinnedIconCount = tracked.size,
          pinnedPackageNames = pkgs,
        )
      }
    }
  }

  fun refreshSystemStatusAndWidgets() {
    val context = getApplication<Application>()
    val count = getAllActiveWidgetIds().size
    val wifi = ConnectivityHelper.isWifiEnabled(context)
    val data = ConnectivityHelper.isMobileDataEnabled(context)
    val snapshot = PedometerHelper.getStepSnapshot(context)
    _uiState.update {
      it.copy(
        activeWidgetCount = count,
        isWifiEnabled = wifi,
        isMobileDataEnabled = data,
        pedometerSnapshot = snapshot,
        stepPermissionDenied = if (snapshot.hasPermission) false else it.stepPermissionDenied,
      )
    }
    if (snapshot.hasPermission && snapshot.isSensorAvailable) {
      PedometerSyncJobService.scheduleIfNeeded(context)
      (context as? WidgetsApplication)?.ensureStepMonitoring()
    }
    updateAllProviders(snapshot)
    refreshPinnedIconState()
  }

  fun refreshPedometerNow(onResult: ((PedometerSnapshot) -> Unit)? = null) {
    val context = getApplication<Application>()
    PedometerHelper.refreshStepsFromSensor(context, timeoutMs = 2200L) { latest ->
      _uiState.update { it.copy(pedometerSnapshot = latest) }
      PedometerWidgetProvider.updateAllWidgets(context, latest)
      onResult?.invoke(latest)
    }
  }

  fun onHardwareStepsUpdated(stepsSinceBoot: Long) {
    val context = getApplication<Application>()
    val snapshot = PedometerHelper.recordHardwareStepCount(context, stepsSinceBoot)
    _uiState.update { it.copy(pedometerSnapshot = snapshot) }
    PedometerWidgetProvider.updateAllWidgets(context, snapshot)
  }

  fun onStepDetectorTicks(deltaSteps: Int) {
    val context = getApplication<Application>()
    val snapshot = PedometerHelper.recordStepDetectorSteps(context, deltaSteps)
    _uiState.update { it.copy(pedometerSnapshot = snapshot) }
    PedometerWidgetProvider.updateAllWidgets(context, snapshot)
  }

  fun onStepPermissionResult(granted: Boolean) {
    val context = getApplication<Application>()
    _uiState.update {
      it.copy(
        stepPermissionDenied = !granted,
        pedometerSnapshot = PedometerHelper.getStepSnapshot(context),
      )
    }
    if (granted) {
      PedometerSyncJobService.scheduleIfNeeded(context)
      (context as? WidgetsApplication)?.ensureStepMonitoring()
      refreshPedometerNow()
    } else {
      PedometerWidgetProvider.updateAllWidgets(context)
    }
  }

  fun selectTab(tab: StudioTab) {
    _uiState.update { it.copy(selectedTab = tab) }
    if (tab == StudioTab.ICON_PACK) {
      if (_uiState.value.installedApps.isEmpty()) {
        loadInstalledApps()
      }
      refreshPinnedIconState()
    }
  }

  fun selectIconShape(shape: CrayonIconShape) {
    val context = getApplication<Application>()
    WidgetPreferences.saveDefaultIconShape(context, shape)
    _uiState.update { it.copy(selectedIconShape = shape) }
    syncPinnedIconsAsync()
  }

  fun setShowUnmappedOnly(unmappedOnly: Boolean) {
    _uiState.update { it.copy(showUnmappedOnly = unmappedOnly) }
  }

  fun setPreviewDrawerStaticMode(drawerOnly: Boolean) {
    _uiState.update { it.copy(previewDrawerStaticMode = drawerOnly) }
  }

  fun selectIconBrowseMode(mode: IconPackBrowseMode) {
    _uiState.update { it.copy(iconBrowseMode = mode) }
    if (mode == IconPackBrowseMode.INSTALLED_APPS && _uiState.value.installedApps.isEmpty()) {
      loadInstalledApps()
    }
  }

  fun selectIconCategory(category: CrayonIconCategory) {
    _uiState.update { it.copy(selectedIconCategory = category) }
  }

  fun updateIconSearchQuery(query: String) {
    _uiState.update { it.copy(iconSearchQuery = query) }
  }

  fun selectFont(font: CrayonFontOption) {
    _uiState.update { it.copy(selectedFont = font) }
    persistLiveIfLauncherMode()
  }

  fun selectTheme(theme: GlassThemeOption) {
    _uiState.update { it.copy(selectedTheme = theme) }
    persistLiveIfLauncherMode()
  }

  fun selectBalance(balance: CrayonGlassBalance) {
    _uiState.update { it.copy(selectedBalance = balance) }
    persistLiveIfLauncherMode()
  }

  fun togglePreviewPage() {
    _uiState.update { it.copy(previewPage = if (it.previewPage == 0) 1 else 0) }
  }

  fun setPreviewPage(page: Int) {
    _uiState.update { it.copy(previewPage = page.coerceIn(0, 1)) }
  }

  fun syncPinnedIconsAsync(onComplete: ((Int) -> Unit)? = null) {
    val context = getApplication<Application>()
    val state = _uiState.value
    val shape = state.selectedIconShape
    val settings = state.currentSettings
    iconSyncJob?.cancel()
    iconSyncJob = viewModelScope.launch(Dispatchers.IO) {
      val tracked = InstalledAppsHelper.getTrackedPinnedIcons(context)
      val pkgs = tracked.map { it.packageName }.toSet()
      val syncedCount = if (tracked.isNotEmpty()) {
        InstalledAppsHelper.updatePinnedShortcutsStyle(context, shape, settings)
      } else {
        0
      }
      _uiState.update {
        it.copy(
          pinnedIconCount = tracked.size,
          pinnedPackageNames = pkgs,
        )
      }
      if (onComplete != null) {
        withContext(Dispatchers.Main) {
          onComplete(syncedCount)
        }
      }
    }
  }

  fun applyCurrentStyleToAllWidgets(): Int {
    val state = _uiState.value
    val context = getApplication<Application>()
    val activeIds = getAllActiveWidgetIds()
    WidgetPreferences.applyGlobalStyleToAllWidgets(
      context = context,
      appWidgetIds = activeIds,
      font = state.selectedFont,
      theme = state.selectedTheme,
      balance = state.selectedBalance,
    )
    updateAllProviders(state.pedometerSnapshot)
    syncPinnedIconsAsync()
    _uiState.update { it.copy(activeWidgetCount = activeIds.size) }
    return activeIds.size
  }

  fun applyForConfigureWidget(applyToAll: Boolean = false): Boolean {
    val state = _uiState.value
    val context = getApplication<Application>()
    if (state.appWidgetId == AppWidgetManager.INVALID_APPWIDGET_ID) return false

    if (applyToAll) {
      applyCurrentStyleToAllWidgets()
      return true
    }

    WidgetPreferences.saveStyleForWidget(
      context = context,
      appWidgetId = state.appWidgetId,
      font = state.selectedFont,
      theme = state.selectedTheme,
      balance = state.selectedBalance,
    )

    val appWidgetManager = AppWidgetManager.getInstance(context)
    when {
      CrayonCalendarWidgetProvider.getActiveWidgetIds(context, appWidgetManager)
        .contains(state.appWidgetId) ->
        CrayonCalendarWidgetProvider.updateWidget(context, appWidgetManager, state.appWidgetId)

      PedometerWidgetProvider.getActiveWidgetIds(context, appWidgetManager)
        .contains(state.appWidgetId) ->
        PedometerWidgetProvider.updateWidget(
          context,
          appWidgetManager,
          state.appWidgetId,
          state.pedometerSnapshot,
        )

      WifiToggleWidgetProvider.getActiveWidgetIds(context, appWidgetManager)
        .contains(state.appWidgetId) ->
        WifiToggleWidgetProvider.updateWidget(context, appWidgetManager, state.appWidgetId)

      MobileDataToggleWidgetProvider.getActiveWidgetIds(context, appWidgetManager)
        .contains(state.appWidgetId) ->
        MobileDataToggleWidgetProvider.updateWidget(context, appWidgetManager, state.appWidgetId)

      else -> updateAllProviders(state.pedometerSnapshot)
    }
    return true
  }

  private fun persistLiveIfLauncherMode() {
    val state = _uiState.value
    if (state.isConfigureMode) return

    val context = getApplication<Application>()
    val activeIds = getAllActiveWidgetIds()
    WidgetPreferences.applyGlobalStyleToAllWidgets(
      context = context,
      appWidgetIds = activeIds,
      font = state.selectedFont,
      theme = state.selectedTheme,
      balance = state.selectedBalance,
    )
    updateAllProviders(state.pedometerSnapshot)
    syncPinnedIconsAsync()
    _uiState.update { it.copy(activeWidgetCount = activeIds.size) }
  }

  private fun getAllActiveWidgetIds(): IntArray {
    val context = getApplication<Application>()
    val manager = AppWidgetManager.getInstance(context)
    return CrayonCalendarWidgetProvider.getActiveWidgetIds(context, manager) +
      PedometerWidgetProvider.getActiveWidgetIds(context, manager) +
      WifiToggleWidgetProvider.getActiveWidgetIds(context, manager) +
      MobileDataToggleWidgetProvider.getActiveWidgetIds(context, manager)
  }

  private fun updateAllProviders(
    pedometerSnapshot: PedometerSnapshot = _uiState.value.pedometerSnapshot,
  ) {
    val context = getApplication<Application>()
    CrayonCalendarWidgetProvider.updateAllWidgets(context)
    PedometerWidgetProvider.updateAllWidgets(context, pedometerSnapshot)
    WifiToggleWidgetProvider.updateAllWidgets(context)
    MobileDataToggleWidgetProvider.updateAllWidgets(context)
  }
}
