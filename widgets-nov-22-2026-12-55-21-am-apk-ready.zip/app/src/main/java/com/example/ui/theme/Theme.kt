package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val StudioDarkColorScheme = darkColorScheme(
  primary = StudioCoralAccent,
  onPrimary = StudioObsidian,
  secondary = StudioSkySecondary,
  onSecondary = StudioObsidian,
  tertiary = StudioLilacTertiary,
  background = StudioObsidian,
  onBackground = StudioTextPrimary,
  surface = StudioSurface,
  onSurface = StudioTextPrimary,
  surfaceVariant = StudioSurfaceVariant,
  onSurfaceVariant = StudioTextMuted,
  outline = StudioGlassBorder,
)

@Composable
fun MyApplicationTheme(
  content: @Composable () -> Unit,
) {
  MaterialTheme(
    colorScheme = StudioDarkColorScheme,
    typography = Typography,
    content = content,
  )
}
