package com.example.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.res.Configuration
import android.graphics.Bitmap
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Apps
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.PhoneAndroid
import androidx.compose.material.icons.rounded.PushPin
import androidx.compose.material.icons.rounded.RoundedCorner
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Sync
import androidx.compose.material.icons.rounded.TouchApp
import androidx.compose.material.icons.rounded.WarningAmber
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.widget.CrayonGlassBalance
import com.example.widget.CrayonIconCategory
import com.example.widget.CrayonIconKind
import com.example.widget.CrayonIconPackRenderer
import com.example.widget.CrayonIconShape
import com.example.widget.GlassThemeOption
import com.example.widget.IconPackBrowseMode
import com.example.widget.InstalledAppsHelper
import com.example.widget.InstalledLaunchApp
import com.example.widget.WidgetSettings
import java.util.Locale

@Composable
fun IconPackTabContent(
  uiState: WidgetStudioUiState,
  accentColor: Color,
  backdropTop: Color,
  backdropBottom: Color,
  onSelectShape: (CrayonIconShape) -> Unit,
  onSelectBrowseMode: (IconPackBrowseMode) -> Unit,
  onSelectCategory: (CrayonIconCategory) -> Unit,
  onSearchQueryChange: (String) -> Unit,
  onToggleUnmappedOnly: (Boolean) -> Unit,
  onSetPreviewDrawerMode: (Boolean) -> Unit,
  onSelectTheme: (GlassThemeOption) -> Unit,
  onSelectBalance: (CrayonGlassBalance) -> Unit,
  onSyncPinnedIcons: () -> Unit,
  onPinAppIcon: (icon: CrayonIconKind?, targetApp: InstalledLaunchApp, customLabel: String) -> Unit,
  modifier: Modifier = Modifier,
) {
  val context = LocalContext.current
  var selectedIconForPin by remember { mutableStateOf<CrayonIconKind?>(null) }
  var selectedAppForPin by remember { mutableStateOf<InstalledLaunchApp?>(null) }
  var copiedAllMissing by remember { mutableStateOf(false) }

  val isSystemNight = (context.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
    Configuration.UI_MODE_NIGHT_YES
  val effectiveShape = if (uiState.previewDrawerStaticMode) {
    CrayonIconShape.SQUIRCLE
  } else {
    uiState.selectedIconShape
  }
  val effectiveSettings = remember(uiState.previewDrawerStaticMode, isSystemNight, uiState.currentSettings) {
    if (uiState.previewDrawerStaticMode) {
      uiState.currentSettings.copy(
        theme = if (isSystemNight) GlassThemeOption.OBSIDIAN_AMBER else GlassThemeOption.WARM_VERMILION,
        balance = CrayonGlassBalance.CRAYON_90_GLASS_10,
      )
    } else {
      uiState.currentSettings
    }
  }

  val unmappedApps = remember(uiState.installedApps, uiState.appfilterComponents) {
    if (uiState.appfilterComponents.isEmpty()) {
      emptyList()
    } else {
      uiState.installedApps.filter { app ->
        InstalledAppsHelper.componentKey(app) !in uiState.appfilterComponents
      }
    }
  }

  val filteredApps = remember(
    uiState.installedApps,
    uiState.iconSearchQuery,
    uiState.showUnmappedOnly,
    uiState.appfilterComponents,
  ) {
    val q = uiState.iconSearchQuery.trim().lowercase(Locale.getDefault())
    uiState.installedApps.filter { app ->
      val unmappedMatch = !uiState.showUnmappedOnly ||
        uiState.appfilterComponents.isEmpty() ||
        InstalledAppsHelper.componentKey(app) !in uiState.appfilterComponents
      val queryMatch = q.isEmpty() ||
        app.label.lowercase(Locale.getDefault()).contains(q) ||
        app.packageName.lowercase(Locale.getDefault()).contains(q)
      unmappedMatch && queryMatch
    }
  }

  val filteredIcons = remember(uiState.selectedIconCategory, uiState.iconSearchQuery) {
    val q = uiState.iconSearchQuery.trim().lowercase(Locale.getDefault())
    CrayonIconKind.entries.filter { kind ->
      val catMatch = uiState.selectedIconCategory == CrayonIconCategory.ALL ||
        kind.category == uiState.selectedIconCategory
      val queryMatch = q.isEmpty() ||
        kind.label.lowercase(Locale.getDefault()).contains(q) ||
        kind.packageKeywords.any { it.contains(q) }
      catMatch && queryMatch
    }
  }

  BoxWithConstraints(
    modifier = modifier.fillMaxSize(),
  ) {
    val columns = when {
      maxWidth >= 820.dp -> 5
      maxWidth >= 600.dp -> 4
      else -> 3
    }
    val appRows = remember(filteredApps, columns) { filteredApps.chunked(columns) }
    val iconRows = remember(filteredIcons, columns) { filteredIcons.chunked(columns) }

    LazyColumn(
      modifier = Modifier
        .fillMaxSize()
        .background(Brush.verticalGradient(colors = listOf(backdropTop, backdropBottom)))
        .widthIn(max = 760.dp)
        .align(Alignment.TopCenter),
      contentPadding = PaddingValues(
        start = 20.dp,
        end = 20.dp,
        top = 8.dp,
        bottom = 28.dp,
      ),
      verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
      item {
        IconPackLauncherGuideCard(accentColor = accentColor)
      }

      item {
        IconPackStyleControlsCard(
          selectedShape = uiState.selectedIconShape,
          selectedTheme = uiState.selectedTheme,
          selectedBalance = uiState.selectedBalance,
          previewDrawerStaticMode = uiState.previewDrawerStaticMode,
          isSystemNight = isSystemNight,
          pinnedIconCount = uiState.pinnedIconCount,
          accentColor = accentColor,
          onSelectShape = onSelectShape,
          onSetPreviewDrawerMode = onSetPreviewDrawerMode,
          onSelectTheme = onSelectTheme,
          onSelectBalance = onSelectBalance,
          onSyncPinnedIcons = onSyncPinnedIcons,
        )
      }

      item {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
          // Mode Toggle: Your Apps (All Installed) vs Icon Library (53 Bespoke)
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
          ) {
            IconPackBrowseMode.entries.forEach { mode ->
              val active = mode == uiState.iconBrowseMode
              val countText = if (mode == IconPackBrowseMode.INSTALLED_APPS) {
                if (uiState.installedApps.isNotEmpty()) "${mode.displayName} (${uiState.installedApps.size})" else mode.displayName
              } else {
                "${mode.displayName} (${CrayonIconKind.entries.size})"
              }
              Surface(
                modifier = Modifier
                  .weight(1f)
                  .minimumInteractiveComponentSize()
                  .clip(RoundedCornerShape(16.dp))
                  .clickable { onSelectBrowseMode(mode) }
                  .testTag("icon_browse_mode_${mode.name.lowercase()}"),
                shape = RoundedCornerShape(16.dp),
                color = if (active) accentColor.copy(alpha = 0.25f) else Color.White.copy(alpha = 0.06f),
                border = BorderStroke(
                  width = if (active) 1.5.dp else 1.dp,
                  color = if (active) accentColor else Color.White.copy(alpha = 0.16f),
                ),
              ) {
                Row(
                  modifier = Modifier.padding(horizontal = 10.dp, vertical = 10.dp),
                  horizontalArrangement = Arrangement.Center,
                  verticalAlignment = Alignment.CenterVertically,
                ) {
                  Icon(
                    imageVector = if (mode == IconPackBrowseMode.INSTALLED_APPS) {
                      Icons.Rounded.PhoneAndroid
                    } else {
                      Icons.Rounded.AutoAwesome
                    },
                    contentDescription = null,
                    tint = if (active) accentColor else MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(16.dp),
                  )
                  Spacer(modifier = Modifier.width(6.dp))
                  Text(
                    text = countText,
                    style = MaterialTheme.typography.labelLarge,
                    color = if (active) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                  )
                }
              }
            }
          }

          OutlinedTextField(
            value = uiState.iconSearchQuery,
            onValueChange = onSearchQueryChange,
            modifier = Modifier
              .fillMaxWidth()
              .testTag("icon_search_input"),
            singleLine = true,
            shape = RoundedCornerShape(18.dp),
            placeholder = {
              Text(
                text = stringResource(R.string.icon_pack_search_hint),
                color = MaterialTheme.colorScheme.onSurfaceVariant,
              )
            },
            leadingIcon = {
              Icon(
                imageVector = Icons.Rounded.Search,
                contentDescription = null,
                tint = accentColor,
              )
            },
            trailingIcon = {
              if (uiState.iconSearchQuery.isNotEmpty()) {
                IconButton(onClick = { onSearchQueryChange("") }) {
                  Icon(
                    imageVector = Icons.Rounded.Close,
                    contentDescription = "Clear search",
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                  )
                }
              }
            },
            colors = OutlinedTextFieldDefaults.colors(
              focusedBorderColor = accentColor,
              unfocusedBorderColor = Color.White.copy(alpha = 0.22f),
              focusedTextColor = Color.White,
              unfocusedTextColor = Color.White,
              cursorColor = accentColor,
              focusedContainerColor = Color(0xE6151925),
              unfocusedContainerColor = Color(0xE6151925),
            ),
          )

          if (uiState.iconBrowseMode == IconPackBrowseMode.INSTALLED_APPS && uiState.installedApps.isNotEmpty()) {
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
              horizontalArrangement = Arrangement.spacedBy(8.dp),
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Surface(
                modifier = Modifier
                  .minimumInteractiveComponentSize()
                  .clip(RoundedCornerShape(50))
                  .clickable { onToggleUnmappedOnly(false) },
                shape = RoundedCornerShape(50),
                color = if (!uiState.showUnmappedOnly) accentColor.copy(alpha = 0.24f) else Color.White.copy(alpha = 0.06f),
                border = BorderStroke(
                  width = if (!uiState.showUnmappedOnly) 1.4.dp else 1.dp,
                  color = if (!uiState.showUnmappedOnly) accentColor else Color.White.copy(alpha = 0.16f),
                ),
              ) {
                Text(
                  text = "All (${uiState.installedApps.size})",
                  style = MaterialTheme.typography.labelSmall,
                  color = if (!uiState.showUnmappedOnly) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                  modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                )
              }

              if (unmappedApps.isNotEmpty()) {
                Surface(
                  modifier = Modifier
                    .minimumInteractiveComponentSize()
                    .clip(RoundedCornerShape(50))
                    .clickable { onToggleUnmappedOnly(true) }
                    .testTag("filter_missing_drawer_chip"),
                  shape = RoundedCornerShape(50),
                  color = if (uiState.showUnmappedOnly) accentColor.copy(alpha = 0.24f) else Color.White.copy(alpha = 0.06f),
                  border = BorderStroke(
                    width = if (uiState.showUnmappedOnly) 1.4.dp else 1.dp,
                    color = if (uiState.showUnmappedOnly) accentColor else Color.White.copy(alpha = 0.16f),
                  ),
                ) {
                  Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(5.dp),
                    verticalAlignment = Alignment.CenterVertically,
                  ) {
                    Icon(
                      imageVector = Icons.Rounded.WarningAmber,
                      contentDescription = null,
                      tint = accentColor,
                      modifier = Modifier.size(14.dp),
                    )
                    Text(
                      text = "Missing in Drawer (${unmappedApps.size})",
                      style = MaterialTheme.typography.labelSmall,
                      color = if (uiState.showUnmappedOnly) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                  }
                }

                Surface(
                  modifier = Modifier
                    .minimumInteractiveComponentSize()
                    .clip(RoundedCornerShape(50))
                    .clickable {
                      val report = unmappedApps.joinToString("\n") { app ->
                        "${app.label}: ComponentInfo{${app.packageName}/${app.activityName}}"
                      }
                      val clipboard = context.getSystemService(ClipboardManager::class.java)
                      clipboard?.setPrimaryClip(ClipData.newPlainText("Missing AppFilter Components", report))
                      copiedAllMissing = true
                    }
                    .testTag("copy_missing_components_chip"),
                  shape = RoundedCornerShape(50),
                  color = Color.White.copy(alpha = 0.06f),
                  border = BorderStroke(1.dp, Color.White.copy(alpha = 0.18f)),
                ) {
                  Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(5.dp),
                    verticalAlignment = Alignment.CenterVertically,
                  ) {
                    Icon(
                      imageVector = if (copiedAllMissing) Icons.Rounded.Check else Icons.Rounded.ContentCopy,
                      contentDescription = null,
                      tint = if (copiedAllMissing) accentColor else Color.White,
                      modifier = Modifier.size(13.dp),
                    )
                    Text(
                      text = if (copiedAllMissing) "Copied ${unmappedApps.size} IDs" else "Copy Missing IDs",
                      style = MaterialTheme.typography.labelSmall,
                      color = if (copiedAllMissing) accentColor else Color.White,
                    )
                  }
                }
              }
            }
          }

          if (uiState.iconBrowseMode == IconPackBrowseMode.ICON_LIBRARY) {
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
              horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
              CrayonIconCategory.entries.forEach { category ->
                val selected = category == uiState.selectedIconCategory
                Surface(
                  modifier = Modifier
                    .minimumInteractiveComponentSize()
                    .clip(RoundedCornerShape(50))
                    .clickable { onSelectCategory(category) }
                    .testTag("icon_category_${category.name.lowercase()}"),
                  shape = RoundedCornerShape(50),
                  color = if (selected) accentColor.copy(alpha = 0.24f) else Color.White.copy(alpha = 0.06f),
                  border = BorderStroke(
                    width = if (selected) 1.4.dp else 1.dp,
                    color = if (selected) accentColor else Color.White.copy(alpha = 0.16f),
                  ),
                ) {
                  Text(
                    text = category.displayName,
                    style = MaterialTheme.typography.labelMedium,
                    color = if (selected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 9.dp),
                  )
                }
              }
            }
          }
        }
      }

      if (uiState.iconBrowseMode == IconPackBrowseMode.INSTALLED_APPS) {
        if (uiState.isLoadingApps && appRows.isEmpty()) {
          item {
            EmptyIconPackMessage(
              text = "Scanning installed apps on your device…",
              modifier = Modifier.fillMaxWidth(),
            )
          }
        } else if (appRows.isEmpty()) {
          item {
            EmptyIconPackMessage(
              text = if (uiState.showUnmappedOnly) "All installed apps are mapped in Drawer!" else stringResource(R.string.icon_pack_no_results),
              modifier = Modifier.fillMaxWidth(),
            )
          }
        } else {
          items(appRows, key = { row -> row.joinToString("|") { it.packageName } }) { rowApps ->
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
              rowApps.forEach { app ->
                val isMissingInDrawer = uiState.appfilterComponents.isNotEmpty() &&
                  InstalledAppsHelper.componentKey(app) !in uiState.appfilterComponents
                InstalledAppCrayonTile(
                  app = app,
                  shape = effectiveShape,
                  settings = effectiveSettings,
                  isPinned = app.packageName in uiState.pinnedPackageNames,
                  isMissingInDrawer = isMissingInDrawer,
                  accentColor = accentColor,
                  onClick = { selectedAppForPin = app },
                  modifier = Modifier.weight(1f),
                )
              }
              repeat(columns - rowApps.size) {
                Spacer(modifier = Modifier.weight(1f))
              }
            }
          }
        }
      } else {
        if (iconRows.isEmpty()) {
          item {
            EmptyIconPackMessage(
              text = stringResource(R.string.icon_pack_no_results),
              modifier = Modifier.fillMaxWidth(),
            )
          }
        } else {
          items(iconRows) { rowIcons ->
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
              rowIcons.forEach { kind ->
                CrayonIconTile(
                  kind = kind,
                  shape = effectiveShape,
                  settings = effectiveSettings,
                  accentColor = accentColor,
                  onClick = { selectedIconForPin = kind },
                  modifier = Modifier.weight(1f),
                )
              }
              repeat(columns - rowIcons.size) {
                Spacer(modifier = Modifier.weight(1f))
              }
            }
          }
        }
      }

      item {
        Spacer(modifier = Modifier.navigationBarsPadding())
      }
    }
  }

  val activeApp = selectedAppForPin
  if (activeApp != null) {
    PinInstalledAppDialog(
      app = activeApp,
      isMappedInDrawer = uiState.appfilterComponents.isEmpty() ||
        InstalledAppsHelper.componentKey(activeApp) in uiState.appfilterComponents,
      shape = uiState.selectedIconShape,
      settings = uiState.currentSettings,
      accentColor = accentColor,
      onSelectShape = onSelectShape,
      onDismiss = { selectedAppForPin = null },
      onConfirmPin = { customIconOverride, customLabel ->
        selectedAppForPin = null
        onPinAppIcon(customIconOverride, activeApp, customLabel)
      },
    )
  }

  val activeIcon = selectedIconForPin
  if (activeIcon != null) {
    PinIconAppDialog(
      iconKind = activeIcon,
      shape = uiState.selectedIconShape,
      settings = uiState.currentSettings,
      accentColor = accentColor,
      installedApps = uiState.installedApps,
      isLoadingApps = uiState.isLoadingApps,
      onSelectShape = onSelectShape,
      onDismiss = { selectedIconForPin = null },
      onConfirmPin = { app, customLabel ->
        selectedIconForPin = null
        onPinAppIcon(activeIcon, app, customLabel)
      },
    )
  }
}

@Composable
private fun EmptyIconPackMessage(
  text: String,
  modifier: Modifier = Modifier,
) {
  Surface(
    modifier = modifier,
    shape = RoundedCornerShape(22.dp),
    color = Color(0xE6151925),
    border = BorderStroke(1.dp, Color.White.copy(alpha = 0.14f)),
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(28.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
      Icon(
        imageVector = Icons.Rounded.Apps,
        contentDescription = null,
        tint = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.size(32.dp),
      )
      Text(
        text = text,
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        textAlign = TextAlign.Center,
      )
    }
  }
}

@Composable
private fun IconPackLauncherGuideCard(accentColor: Color) {
  Surface(
    modifier = Modifier.fillMaxWidth(),
    shape = RoundedCornerShape(24.dp),
    color = Color(0xE6151925),
    border = BorderStroke(1.dp, Color.White.copy(alpha = 0.16f)),
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(16.dp),
      horizontalArrangement = Arrangement.spacedBy(12.dp),
      verticalAlignment = Alignment.Top,
    ) {
      Surface(
        shape = RoundedCornerShape(14.dp),
        color = accentColor.copy(alpha = 0.20f),
        border = BorderStroke(1.dp, accentColor.copy(alpha = 0.55f)),
      ) {
        Icon(
          imageVector = Icons.Rounded.TouchApp,
          contentDescription = null,
          tint = accentColor,
          modifier = Modifier
            .padding(9.dp)
            .size(20.dp),
        )
      }
      Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(
          text = stringResource(R.string.icon_pack_guide_title),
          style = MaterialTheme.typography.titleMedium,
          color = MaterialTheme.colorScheme.onBackground,
        )
        Text(
          text = stringResource(R.string.icon_pack_guide_body),
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
      }
    }
  }
}

@Composable
private fun IconPackStyleControlsCard(
  selectedShape: CrayonIconShape,
  selectedTheme: GlassThemeOption,
  selectedBalance: CrayonGlassBalance,
  previewDrawerStaticMode: Boolean,
  isSystemNight: Boolean,
  pinnedIconCount: Int,
  accentColor: Color,
  onSelectShape: (CrayonIconShape) -> Unit,
  onSetPreviewDrawerMode: (Boolean) -> Unit,
  onSelectTheme: (GlassThemeOption) -> Unit,
  onSelectBalance: (CrayonGlassBalance) -> Unit,
  onSyncPinnedIcons: () -> Unit,
) {
  Surface(
    modifier = Modifier.fillMaxWidth(),
    shape = RoundedCornerShape(24.dp),
    color = Color(0xE6151925),
    border = BorderStroke(1.dp, Color.White.copy(alpha = 0.16f)),
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(14.dp),
      verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        Surface(
          modifier = Modifier
            .weight(1f)
            .minimumInteractiveComponentSize()
            .clip(RoundedCornerShape(14.dp))
            .clickable { onSetPreviewDrawerMode(false) }
            .testTag("preview_mode_pinned"),
          shape = RoundedCornerShape(14.dp),
          color = if (!previewDrawerStaticMode) accentColor.copy(alpha = 0.24f) else Color.White.copy(alpha = 0.05f),
          border = BorderStroke(
            width = if (!previewDrawerStaticMode) 1.4.dp else 1.dp,
            color = if (!previewDrawerStaticMode) accentColor else Color.White.copy(alpha = 0.16f),
          ),
        ) {
          Text(
            text = "Pinned Icons (6 Themes)",
            style = MaterialTheme.typography.labelSmall,
            color = if (!previewDrawerStaticMode) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 9.dp),
          )
        }

        Surface(
          modifier = Modifier
            .weight(1f)
            .minimumInteractiveComponentSize()
            .clip(RoundedCornerShape(14.dp))
            .clickable { onSetPreviewDrawerMode(true) }
            .testTag("preview_mode_drawer"),
          shape = RoundedCornerShape(14.dp),
          color = if (previewDrawerStaticMode) accentColor.copy(alpha = 0.24f) else Color.White.copy(alpha = 0.05f),
          border = BorderStroke(
            width = if (previewDrawerStaticMode) 1.4.dp else 1.dp,
            color = if (previewDrawerStaticMode) accentColor else Color.White.copy(alpha = 0.16f),
          ),
        ) {
          Text(
            text = if (isSystemNight) "Drawer Pack (Dark Only)" else "Drawer Pack (Light Only)",
            style = MaterialTheme.typography.labelSmall,
            color = if (previewDrawerStaticMode) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 9.dp),
          )
        }
      }

      if (previewDrawerStaticMode) {
        Text(
          text = "Nothing Launcher Drawer renders static APK icons (${if (isSystemNight) "Obsidian Amber in Dark Mode" else "Warm Vermilion in Light Mode"}). Switch back to Pinned Icons to customize all 6 themes & shapes.",
          style = MaterialTheme.typography.labelSmall,
          color = accentColor,
        )
      }

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically,
      ) {
        CrayonIconShape.entries.forEach { shape ->
          val active = shape == selectedShape
          Surface(
            modifier = Modifier
              .weight(1f)
              .minimumInteractiveComponentSize()
              .clip(RoundedCornerShape(16.dp))
              .clickable { onSelectShape(shape) }
              .testTag("icon_shape_${shape.id}"),
            shape = RoundedCornerShape(16.dp),
            color = if (active) accentColor.copy(alpha = 0.24f) else Color.White.copy(alpha = 0.05f),
            border = BorderStroke(
              width = if (active) 1.5.dp else 1.dp,
              color = if (active) accentColor else Color.White.copy(alpha = 0.16f),
            ),
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 10.dp, vertical = 9.dp),
              horizontalArrangement = Arrangement.Center,
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Icon(
                imageVector = Icons.Rounded.RoundedCorner,
                contentDescription = null,
                tint = if (active) accentColor else MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(16.dp),
              )
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                text = shape.displayName,
                style = MaterialTheme.typography.labelMedium,
                color = if (active) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
              )
            }
          }
        }
      }

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically,
      ) {
        CrayonGlassBalance.entries.forEach { balance ->
          val active = balance == selectedBalance
          Surface(
            modifier = Modifier
              .weight(1f)
              .minimumInteractiveComponentSize()
              .clip(RoundedCornerShape(16.dp))
              .clickable { onSelectBalance(balance) }
              .testTag("icon_balance_${balance.id}"),
            shape = RoundedCornerShape(16.dp),
            color = if (active) accentColor.copy(alpha = 0.24f) else Color.White.copy(alpha = 0.05f),
            border = BorderStroke(
              width = if (active) 1.5.dp else 1.dp,
              color = if (active) accentColor else Color.White.copy(alpha = 0.16f),
            ),
          ) {
            Box(
              modifier = Modifier.padding(horizontal = 8.dp, vertical = 9.dp),
              contentAlignment = Alignment.Center,
            ) {
              Text(
                text = balance.shortLabel,
                style = MaterialTheme.typography.labelMedium,
                color = if (active) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
              )
            }
          }
        }
      }

      Row(
        modifier = Modifier
          .fillMaxWidth()
          .horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalAlignment = Alignment.CenterVertically,
      ) {
        GlassThemeOption.entries.forEach { option ->
          val active = option == selectedTheme
          val dotAccent = Color(option.accentArgb)
          val dotBase = Color(option.glassTopArgb)
          Surface(
            modifier = Modifier
              .minimumInteractiveComponentSize()
              .clip(RoundedCornerShape(50))
              .clickable { onSelectTheme(option) }
              .testTag("icon_theme_${option.id}"),
            shape = RoundedCornerShape(50),
            color = if (active) dotAccent.copy(alpha = 0.22f) else Color.White.copy(alpha = 0.05f),
            border = BorderStroke(
              width = if (active) 1.5.dp else 1.dp,
              color = if (active) dotAccent else Color.White.copy(alpha = 0.15f),
            ),
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
              Box(
                modifier = Modifier
                  .size(16.dp)
                  .clip(CircleShape)
                  .background(dotBase)
                  .border(2.5.dp, dotAccent, CircleShape),
              )
              Text(
                text = option.displayName.substringBefore(" &"),
                style = MaterialTheme.typography.labelSmall,
                color = if (active) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
              )
            }
          }
        }
      }

      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
      ) {
        Text(
          text = if (pinnedIconCount > 0) {
            "$pinnedIconCount pinned home icon${if (pinnedIconCount == 1) "" else "s"} auto-sync live"
          } else {
            "Pin any app below for live shape & color sync"
          },
          style = MaterialTheme.typography.labelSmall,
          color = if (pinnedIconCount > 0) accentColor else MaterialTheme.colorScheme.onSurfaceVariant,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
          modifier = Modifier.weight(1f),
        )
        if (pinnedIconCount > 0) {
          Spacer(modifier = Modifier.width(8.dp))
          Surface(
            modifier = Modifier
              .minimumInteractiveComponentSize()
              .clip(RoundedCornerShape(50))
              .clickable(onClick = onSyncPinnedIcons)
              .testTag("sync_pinned_icons_button"),
            shape = RoundedCornerShape(50),
            color = accentColor.copy(alpha = 0.22f),
            border = BorderStroke(1.dp, accentColor.copy(alpha = 0.72f)),
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(4.dp),
            ) {
              Icon(
                imageVector = Icons.Rounded.Sync,
                contentDescription = null,
                tint = accentColor,
                modifier = Modifier.size(14.dp),
              )
              Text(
                text = stringResource(R.string.icon_pack_sync_cta),
                style = MaterialTheme.typography.labelSmall,
                color = Color.White,
              )
            }
          }
        }
      }
    }
  }
}

@Composable
private fun InstalledAppCrayonTile(
  app: InstalledLaunchApp,
  shape: CrayonIconShape,
  settings: WidgetSettings,
  isPinned: Boolean,
  isMissingInDrawer: Boolean,
  accentColor: Color,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val context = LocalContext.current
  val iconBitmap: Bitmap = remember(app.packageName, app.activityName, shape, settings.theme, settings.balance) {
    CrayonIconPackRenderer.renderInstalledAppIcon(
      context = context,
      app = app,
      shape = shape,
      settings = settings,
      sizePx = 220,
    )
  }

  Surface(
    modifier = modifier
      .minimumInteractiveComponentSize()
      .clip(RoundedCornerShape(22.dp))
      .clickable(onClick = onClick)
      .testTag("installed_app_tile_${app.packageName}"),
    shape = RoundedCornerShape(22.dp),
    color = Color(0xE6151925),
    border = BorderStroke(
      width = if (isPinned) 1.4.dp else 1.dp,
      color = if (isPinned) accentColor.copy(alpha = 0.72f) else accentColor.copy(alpha = 0.24f),
    ),
  ) {
    Box(modifier = Modifier.fillMaxWidth()) {
      if (isMissingInDrawer) {
        Icon(
          imageVector = Icons.Rounded.WarningAmber,
          contentDescription = "Missing in Drawer appfilter",
          tint = accentColor,
          modifier = Modifier
            .align(Alignment.TopStart)
            .padding(8.dp)
            .size(13.dp),
        )
      }
      if (isPinned) {
        Icon(
          imageVector = Icons.Rounded.PushPin,
          contentDescription = "Pinned to home screen",
          tint = accentColor,
          modifier = Modifier
            .align(Alignment.TopEnd)
            .padding(8.dp)
            .size(13.dp),
        )
      }
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 8.dp, vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        Image(
          bitmap = iconBitmap.asImageBitmap(),
          contentDescription = "${app.label} crayon icon",
          contentScale = ContentScale.Fit,
          modifier = Modifier
            .fillMaxWidth(0.76f)
            .aspectRatio(1f),
        )
        Text(
          text = app.label,
          style = MaterialTheme.typography.labelMedium,
          color = Color(0xFFF3F6FF),
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
          textAlign = TextAlign.Center,
        )
      }
    }
  }
}

@Composable
private fun CrayonIconTile(
  kind: CrayonIconKind,
  shape: CrayonIconShape,
  settings: WidgetSettings,
  accentColor: Color,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val iconBitmap: Bitmap = remember(kind, shape, settings.theme, settings.balance) {
    CrayonIconPackRenderer.renderIcon(
      kind = kind,
      shape = shape,
      settings = settings,
      sizePx = 220,
    )
  }

  Surface(
    modifier = modifier
      .minimumInteractiveComponentSize()
      .clip(RoundedCornerShape(22.dp))
      .clickable(onClick = onClick)
      .testTag("icon_pack_item_${kind.id}"),
    shape = RoundedCornerShape(22.dp),
    color = Color(0xE6151925),
    border = BorderStroke(1.dp, accentColor.copy(alpha = 0.24f)),
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 8.dp, vertical = 12.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
      Image(
        bitmap = iconBitmap.asImageBitmap(),
        contentDescription = "${kind.label} crayon icon",
        contentScale = ContentScale.Fit,
        modifier = Modifier
          .fillMaxWidth(0.76f)
          .aspectRatio(1f),
      )
      Text(
        text = kind.label,
        style = MaterialTheme.typography.labelMedium,
        color = Color(0xFFF3F6FF),
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
        textAlign = TextAlign.Center,
      )
    }
  }
}

@Composable
private fun PinInstalledAppDialog(
  app: InstalledLaunchApp,
  isMappedInDrawer: Boolean,
  shape: CrayonIconShape,
  settings: WidgetSettings,
  accentColor: Color,
  onSelectShape: (CrayonIconShape) -> Unit,
  onDismiss: () -> Unit,
  onConfirmPin: (customIconOverride: CrayonIconKind?, customLabel: String) -> Unit,
) {
  val context = LocalContext.current
  val matchedKind = remember(app) { InstalledAppsHelper.matchBespokeIcon(app) }
  var selectedOverride by remember(app) { mutableStateOf<CrayonIconKind?>(matchedKind) }
  var shortcutLabel by remember(app) { mutableStateOf(app.label) }
  val previewBitmap = remember(app, selectedOverride, shape, settings.theme, settings.balance) {
    if (selectedOverride != null) {
      CrayonIconPackRenderer.renderIcon(
        kind = selectedOverride!!,
        shape = shape,
        settings = settings,
        sizePx = 256,
      )
    } else {
      CrayonIconPackRenderer.renderInstalledAppIcon(
        context = context,
        app = app,
        shape = shape,
        settings = settings,
        sizePx = 256,
      )
    }
  }
  val onAccent = remember(accentColor) {
    if (accentColor.luminance() > 0.52f) Color(0xFF1A1614) else Color.White
  }

  AlertDialog(
    onDismissRequest = onDismiss,
    containerColor = Color(0xFF181B24),
    titleContentColor = Color.White,
    textContentColor = Color(0xFFD5DAE5),
    title = {
      Text(
        text = stringResource(R.string.icon_pack_pin_dialog_title),
        style = MaterialTheme.typography.titleLarge,
      )
    },
    text = {
      Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(12.dp),
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(14.dp),
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Image(
            bitmap = previewBitmap.asImageBitmap(),
            contentDescription = "${app.label} preview",
            modifier = Modifier.size(72.dp),
          )
          Column(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(6.dp),
          ) {
            Text(
              text = app.label,
              style = MaterialTheme.typography.titleMedium,
              color = Color.White,
              maxLines = 1,
              overflow = TextOverflow.Ellipsis,
            )
            Text(
              text = app.packageName,
              style = MaterialTheme.typography.labelSmall,
              color = Color(0xFF9AA3B5),
              maxLines = 1,
              overflow = TextOverflow.Ellipsis,
            )
            Text(
              text = if (isMappedInDrawer) "System Drawer: Matched ✓" else "System Drawer: Missing ComponentInfo",
              style = MaterialTheme.typography.labelSmall,
              color = if (isMappedInDrawer) Color(0xFF81C784) else accentColor,
            )
            var copiedComponent by remember(app) { mutableStateOf(false) }
            val componentSpec = "ComponentInfo{${app.packageName}/${app.activityName}}"
            Row(
              modifier = Modifier
                .clip(RoundedCornerShape(8.dp))
                .clickable {
                  val clipboard = context.getSystemService(ClipboardManager::class.java)
                  clipboard?.setPrimaryClip(
                    ClipData.newPlainText("App Component", componentSpec),
                  )
                  copiedComponent = true
                }
                .padding(vertical = 2.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(4.dp),
            ) {
              Text(
                text = if (copiedComponent) "Copied ComponentInfo" else app.activityName.substringAfterLast('.'),
                style = MaterialTheme.typography.labelSmall,
                color = if (copiedComponent) accentColor else Color(0xFF7D879A),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f, fill = false),
              )
              Icon(
                imageVector = if (copiedComponent) Icons.Rounded.Check else Icons.Rounded.ContentCopy,
                contentDescription = "Copy app component",
                tint = if (copiedComponent) accentColor else Color(0xFF7D879A),
                modifier = Modifier.size(12.dp),
              )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
              CrayonIconShape.entries.forEach { s ->
                val isCurrent = s == shape
                Surface(
                  modifier = Modifier
                    .clip(RoundedCornerShape(50))
                    .clickable { onSelectShape(s) },
                  shape = RoundedCornerShape(50),
                  color = if (isCurrent) accentColor.copy(alpha = 0.25f) else Color.White.copy(alpha = 0.08f),
                  border = BorderStroke(
                    width = 1.dp,
                    color = if (isCurrent) accentColor else Color.White.copy(alpha = 0.2f),
                  ),
                ) {
                  Text(
                    text = s.displayName,
                    style = MaterialTheme.typography.labelSmall,
                    color = Color.White,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                  )
                }
              }
            }
          }
        }

        OutlinedTextField(
          value = shortcutLabel,
          onValueChange = { shortcutLabel = it.take(32) },
          modifier = Modifier
            .fillMaxWidth()
            .testTag("icon_label_input"),
          singleLine = true,
          label = { Text(stringResource(R.string.icon_pack_shortcut_label_hint)) },
          colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = accentColor,
            unfocusedBorderColor = Color.White.copy(alpha = 0.25f),
            focusedTextColor = Color.White,
            unfocusedTextColor = Color.White,
            focusedLabelColor = accentColor,
            unfocusedLabelColor = Color(0xFFA0A8B8),
          ),
        )

        Text(
          text = "Icon Style",
          style = MaterialTheme.typography.labelLarge,
          color = Color.White,
        )
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState()),
          horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          val autoSelected = selectedOverride == null
          Surface(
            modifier = Modifier
              .clip(RoundedCornerShape(50))
              .clickable { selectedOverride = null },
            shape = RoundedCornerShape(50),
            color = if (autoSelected) accentColor.copy(alpha = 0.25f) else Color.White.copy(alpha = 0.08f),
            border = BorderStroke(1.dp, if (autoSelected) accentColor else Color.White.copy(alpha = 0.2f)),
          ) {
            Text(
              text = "App Stencil",
              style = MaterialTheme.typography.labelSmall,
              color = Color.White,
              modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
            )
          }
          CrayonIconKind.entries.forEach { kind ->
            val picked = selectedOverride == kind
            Surface(
              modifier = Modifier
                .clip(RoundedCornerShape(50))
                .clickable { selectedOverride = kind },
              shape = RoundedCornerShape(50),
              color = if (picked) accentColor.copy(alpha = 0.25f) else Color.White.copy(alpha = 0.08f),
              border = BorderStroke(1.dp, if (picked) accentColor else Color.White.copy(alpha = 0.2f)),
            ) {
              Text(
                text = kind.label,
                style = MaterialTheme.typography.labelSmall,
                color = Color.White,
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
              )
            }
          }
        }
      }
    },
    confirmButton = {
      Button(
        onClick = { onConfirmPin(selectedOverride, shortcutLabel) },
        modifier = Modifier.testTag("confirm_pin_icon_button"),
        colors = ButtonDefaults.buttonColors(
          containerColor = accentColor,
          contentColor = onAccent,
        ),
      ) {
        Icon(
          imageVector = Icons.Rounded.PushPin,
          contentDescription = null,
          modifier = Modifier.size(16.dp),
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(text = stringResource(R.string.icon_pack_pin_cta))
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) {
        Text(text = "Cancel", color = Color(0xFFD5DAE5))
      }
    },
  )
}

@Composable
private fun PinIconAppDialog(
  iconKind: CrayonIconKind,
  shape: CrayonIconShape,
  settings: WidgetSettings,
  accentColor: Color,
  installedApps: List<InstalledLaunchApp>,
  isLoadingApps: Boolean,
  onSelectShape: (CrayonIconShape) -> Unit,
  onDismiss: () -> Unit,
  onConfirmPin: (app: InstalledLaunchApp, customLabel: String) -> Unit,
) {
  val matchedApp = remember(iconKind, installedApps) {
    InstalledAppsHelper.findBestMatch(iconKind, installedApps) ?: installedApps.firstOrNull()
  }
  var selectedApp by remember(iconKind, installedApps) { mutableStateOf(matchedApp) }
  var shortcutLabel by remember(iconKind, matchedApp) {
    mutableStateOf(matchedApp?.label ?: iconKind.label)
  }
  var appFilterQuery by remember(iconKind) { mutableStateOf("") }

  val filteredApps = remember(installedApps, appFilterQuery) {
    val q = appFilterQuery.trim().lowercase(Locale.getDefault())
    if (q.isEmpty()) {
      installedApps
    } else {
      installedApps.filter {
        it.label.lowercase(Locale.getDefault()).contains(q) ||
          it.packageName.lowercase(Locale.getDefault()).contains(q)
      }
    }
  }

  val previewBitmap = remember(iconKind, shape, settings.theme, settings.balance) {
    CrayonIconPackRenderer.renderIcon(
      kind = iconKind,
      shape = shape,
      settings = settings,
      sizePx = 256,
    )
  }
  val onAccent = remember(accentColor) {
    if (accentColor.luminance() > 0.52f) Color(0xFF1A1614) else Color.White
  }

  AlertDialog(
    onDismissRequest = onDismiss,
    containerColor = Color(0xFF181B24),
    titleContentColor = Color.White,
    textContentColor = Color(0xFFD5DAE5),
    title = {
      Text(
        text = stringResource(R.string.icon_pack_pin_dialog_title),
        style = MaterialTheme.typography.titleLarge,
      )
    },
    text = {
      Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(12.dp),
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(14.dp),
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Image(
            bitmap = previewBitmap.asImageBitmap(),
            contentDescription = "${iconKind.label} preview",
            modifier = Modifier.size(72.dp),
          )
          Column(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(6.dp),
          ) {
            Text(
              text = iconKind.label,
              style = MaterialTheme.typography.titleMedium,
              color = Color.White,
            )
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
              CrayonIconShape.entries.forEach { s ->
                val isCurrent = s == shape
                Surface(
                  modifier = Modifier
                    .clip(RoundedCornerShape(50))
                    .clickable { onSelectShape(s) },
                  shape = RoundedCornerShape(50),
                  color = if (isCurrent) accentColor.copy(alpha = 0.25f) else Color.White.copy(alpha = 0.08f),
                  border = BorderStroke(
                    width = 1.dp,
                    color = if (isCurrent) accentColor else Color.White.copy(alpha = 0.2f),
                  ),
                ) {
                  Text(
                    text = s.displayName,
                    style = MaterialTheme.typography.labelSmall,
                    color = Color.White,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                  )
                }
              }
            }
          }
        }

        OutlinedTextField(
          value = shortcutLabel,
          onValueChange = { shortcutLabel = it.take(32) },
          modifier = Modifier
            .fillMaxWidth()
            .testTag("icon_label_input"),
          singleLine = true,
          label = { Text(stringResource(R.string.icon_pack_shortcut_label_hint)) },
          colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = accentColor,
            unfocusedBorderColor = Color.White.copy(alpha = 0.25f),
            focusedTextColor = Color.White,
            unfocusedTextColor = Color.White,
            focusedLabelColor = accentColor,
            unfocusedLabelColor = Color(0xFFA0A8B8),
          ),
        )

        Text(
          text = stringResource(R.string.icon_pack_pick_app),
          style = MaterialTheme.typography.labelLarge,
          color = Color.White,
        )

        OutlinedTextField(
          value = appFilterQuery,
          onValueChange = { appFilterQuery = it },
          modifier = Modifier.fillMaxWidth(),
          singleLine = true,
          placeholder = { Text(stringResource(R.string.icon_pack_search_apps_hint)) },
          leadingIcon = {
            Icon(
              imageVector = Icons.Rounded.Search,
              contentDescription = null,
              tint = accentColor,
            )
          },
          colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = accentColor,
            unfocusedBorderColor = Color.White.copy(alpha = 0.22f),
            focusedTextColor = Color.White,
            unfocusedTextColor = Color.White,
          ),
        )

        if (isLoadingApps) {
          Text(
            text = "Loading installed apps…",
            style = MaterialTheme.typography.bodySmall,
            color = Color(0xFFA0A8B8),
          )
        } else if (filteredApps.isEmpty()) {
          Text(
            text = stringResource(R.string.icon_pack_no_apps_found),
            style = MaterialTheme.typography.bodySmall,
            color = Color(0xFFA0A8B8),
          )
        } else {
          LazyColumn(
            modifier = Modifier
              .fillMaxWidth()
              .heightIn(max = 200.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
          ) {
            items(filteredApps, key = { "${it.packageName}/${it.activityName}" }) { app ->
              val isPicked = selectedApp == app
              Surface(
                modifier = Modifier
                  .fillMaxWidth()
                  .minimumInteractiveComponentSize()
                  .clip(RoundedCornerShape(14.dp))
                  .clickable {
                    selectedApp = app
                    shortcutLabel = app.label
                  },
                shape = RoundedCornerShape(14.dp),
                color = if (isPicked) accentColor.copy(alpha = 0.20f) else Color.White.copy(alpha = 0.05f),
                border = BorderStroke(
                  width = if (isPicked) 1.4.dp else 1.dp,
                  color = if (isPicked) accentColor else Color.White.copy(alpha = 0.12f),
                ),
              ) {
                Row(
                  modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                  verticalAlignment = Alignment.CenterVertically,
                  horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                  Column(modifier = Modifier.weight(1f)) {
                    Text(
                      text = app.label,
                      style = MaterialTheme.typography.labelLarge,
                      color = Color.White,
                      maxLines = 1,
                      overflow = TextOverflow.Ellipsis,
                    )
                    Text(
                      text = app.packageName,
                      style = MaterialTheme.typography.labelSmall,
                      color = Color(0xFF9AA3B5),
                      maxLines = 1,
                      overflow = TextOverflow.Ellipsis,
                    )
                  }
                  if (isPicked) {
                    Icon(
                      imageVector = Icons.Rounded.Check,
                      contentDescription = "Selected app",
                      tint = accentColor,
                      modifier = Modifier.size(18.dp),
                    )
                  }
                }
              }
            }
          }
        }
      }
    },
    confirmButton = {
      Button(
        onClick = {
          val picked = selectedApp ?: return@Button
          onConfirmPin(picked, shortcutLabel)
        },
        enabled = selectedApp != null,
        modifier = Modifier.testTag("confirm_pin_icon_button"),
        colors = ButtonDefaults.buttonColors(
          containerColor = accentColor,
          contentColor = onAccent,
        ),
      ) {
        Icon(
          imageVector = Icons.Rounded.PushPin,
          contentDescription = null,
          modifier = Modifier.size(16.dp),
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(text = stringResource(R.string.icon_pack_pin_cta))
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) {
        Text(text = "Cancel", color = Color(0xFFD5DAE5))
      }
    },
  )
}

