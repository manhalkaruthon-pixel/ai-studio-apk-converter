# Widgets (Android 16 — Crayon × Liquid Glass Calendar)

## How to Install on Your Android 16 Phone
1. Extract `Widgets_Android16.zip` and open the `Widgets` folder in **Android Studio**.
2. Connect your Android 16 phone via USB (with **USB Debugging** enabled) and click **Run** (or **Build → Build APK(s)** and install the APK on your phone).
3. On your Android 16 home screen, **long-press an empty space → Widgets → Widgets**.
4. Drag the **Widgets** calendar onto your home screen:
   - **Tap the widget** to flip cleanly between **Page 1** (Month, Date, Day) and **Page 2** (Month Calendar) — zero scrollbars or extra buttons.
   - **Open the Widgets app** (or long-press the widget → **Settings**) to switch between the **6 Custom Crayon Fonts** and **6 Colour Themes**.
